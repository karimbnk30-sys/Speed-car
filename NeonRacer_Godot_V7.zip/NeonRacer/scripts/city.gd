extends Node3D
## Premium architecture: glass towers, hotels, apartment blocks, commercial buildings, modern villas and
## Mediterranean boutique buildings. ~12 detailed archetypes are built once and instanced (MultiMesh,
## chunked, with visibility ranges) over the OSM footprints and along the whole route.
const TexGen := preload("res://scripts/texgen.gd")
const S_FACADE := 0
const S_GLASS := 1
const S_TRIM_L := 2
const S_TRIM_D := 3
const S_LED := 4
const S_RAIL := 5
const FLOOR_H := 3.4
const CHUNK := 700.0
const VIS_RANGE := 1000.0
const TW := 7.0

var algiers
var rng := RandomNumberGenerator.new()
var variants: Array = []             # {mesh, w, d, h, cat}
var by_cat := {}                     # cat -> Array of variant indices
var chunks := {}                     # Vector2i -> {variant index -> Array of [Transform3D, Color]}
var foot := {}                       # Vector2i (60 m cells) -> Array of Vector3(x, z, r)
var window_mats: Array = []          # facade / glass materials with night-lit windows
var led_mats: Array = []
var m_glass: StandardMaterial3D        # untinted glass (lobbies, storefronts)
var m_glass_t: StandardMaterial3D      # tinted curtain wall (towers)
var m_stone: StandardMaterial3D
var m_plaster: StandardMaterial3D
var m_metal: StandardMaterial3D
var m_trim_l: StandardMaterial3D
var m_trim_d: StandardMaterial3D
var m_rail: StandardMaterial3D
var led_cyan: StandardMaterial3D
var led_magenta: StandardMaterial3D
var led_amber: StandardMaterial3D
var _sts: Array = []
var _counts: Array = []
var placed := 0

const FACADE_TINTS := [
    Color(0.97, 0.93, 0.85), Color(0.94, 0.85, 0.7), Color(0.88, 0.62, 0.5), Color(0.93, 0.76, 0.72),
    Color(0.76, 0.83, 0.74), Color(0.72, 0.85, 0.92), Color(0.62, 0.64, 0.68), Color(0.92, 0.78, 0.5),
    Color(1.0, 1.0, 1.0), Color(0.58, 0.76, 0.78), Color(0.68, 0.74, 0.88)]
const GLASS_TINTS := [
    Color(0.85, 1.0, 1.0), Color(0.78, 0.9, 1.0), Color(1.0, 0.88, 0.7), Color(0.72, 0.78, 0.9), Color(0.85, 0.95, 0.88)]

# ---------------------------------------------------------------- materials
func _window_material(kind: int, seed_value: int, rough: float, metal: float, tinted := true) -> StandardMaterial3D:
    var t: Dictionary = TexGen.window_tile(kind, seed_value)
    var m := StandardMaterial3D.new()
    m.albedo_texture = t["albedo"]
    m.emission_enabled = true
    m.emission_texture = t["emission"]
    m.emission_energy_multiplier = 0.0
    m.vertex_color_use_as_albedo = tinted
    m.uv1_triplanar = true
    m.uv1_world_triplanar = true
    m.uv1_scale = Vector3(1.0 / 12.0, 1.0 / 13.6, 1.0 / 12.0)
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    m.roughness = rough
    m.metallic = metal
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    window_mats.append(m)
    return m

func _plain(c: Color, rough: float, metal: float) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    m.metallic = metal
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    return m

func _led(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.emission_enabled = true
    m.emission = c
    m.emission_energy_multiplier = 2.0
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    led_mats.append(m)
    return m

func _make_materials() -> void:
    m_glass = _window_material(0, 11, 0.1, 0.45, false)
    m_glass_t = _window_material(0, 15, 0.1, 0.45, true)
    m_stone = _window_material(1, 12, 0.85, 0.0)
    m_plaster = _window_material(2, 13, 0.9, 0.0)
    m_metal = _window_material(3, 14, 0.45, 0.35)
    m_trim_l = _plain(Color(0.84, 0.83, 0.8), 0.85, 0.0)
    m_trim_d = _plain(Color(0.14, 0.14, 0.16), 0.45, 0.6)
    m_rail = _plain(Color(0.7, 0.86, 0.95, 0.3), 0.05, 0.0)
    m_rail.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    led_cyan = _led(Color(0.2, 0.9, 1.0))
    led_magenta = _led(Color(1.0, 0.25, 0.75))
    led_amber = _led(Color(1.0, 0.75, 0.25))

func set_night(on: bool) -> void:
    for m in window_mats:
        (m as StandardMaterial3D).emission_energy_multiplier = 1.7 if on else 0.0
    for m in led_mats:
        (m as StandardMaterial3D).emission_energy_multiplier = 4.0 if on else 1.6

# ---------------------------------------------------------------- mesh building helpers
func _begin() -> void:
    _sts.clear()
    _counts.clear()
    for k in 6:
        var st := SurfaceTool.new()
        st.begin(Mesh.PRIMITIVE_TRIANGLES)
        st.set_smooth_group(-1)
        _sts.append(st)
        _counts.append(0)

func _tri(surf: int, a: Vector3, b: Vector3, c: Vector3) -> void:
    var st: SurfaceTool = _sts[surf]
    st.add_vertex(a)
    st.add_vertex(b)
    st.add_vertex(c)
    _counts[surf] = int(_counts[surf]) + 3

func _quad(surf: int, a: Vector3, b: Vector3, c: Vector3, d: Vector3) -> void:
    _tri(surf, a, b, c)
    _tri(surf, a, c, d)

# box without a bottom face: 4 walls on `wall`, top on `roof`
func _box(wall: int, roof: int, c: Vector3, s: Vector3) -> void:
    var x0: float = c.x - s.x * 0.5
    var x1: float = c.x + s.x * 0.5
    var y0: float = c.y - s.y * 0.5
    var y1: float = c.y + s.y * 0.5
    var z0: float = c.z - s.z * 0.5
    var z1: float = c.z + s.z * 0.5
    _quad(wall, Vector3(x1, y0, z0), Vector3(x1, y0, z1), Vector3(x1, y1, z1), Vector3(x1, y1, z0))
    _quad(wall, Vector3(x0, y0, z0), Vector3(x0, y1, z0), Vector3(x0, y1, z1), Vector3(x0, y0, z1))
    _quad(wall, Vector3(x0, y0, z1), Vector3(x0, y1, z1), Vector3(x1, y1, z1), Vector3(x1, y0, z1))
    _quad(wall, Vector3(x0, y0, z0), Vector3(x1, y0, z0), Vector3(x1, y1, z0), Vector3(x0, y1, z0))
    _quad(roof, Vector3(x0, y1, z0), Vector3(x0, y1, z1), Vector3(x1, y1, z1), Vector3(x1, y1, z0))

# hip roof over a w x d rectangle (ridge along x)
func _hip(surf: int, base: Vector3, w: float, d: float, h: float) -> void:
    var rw: float = maxf(w - d, 0.0) * 0.5
    var y1: float = base.y + h
    var a := Vector3(base.x - w * 0.5, base.y, base.z - d * 0.5)
    var b := Vector3(base.x + w * 0.5, base.y, base.z - d * 0.5)
    var c := Vector3(base.x + w * 0.5, base.y, base.z + d * 0.5)
    var e := Vector3(base.x - w * 0.5, base.y, base.z + d * 0.5)
    var r0 := Vector3(base.x - rw, y1, base.z)
    var r1 := Vector3(base.x + rw, y1, base.z)
    _quad(surf, e, c, r1, r0)
    _quad(surf, b, a, r0, r1)
    _tri(surf, a, e, r0)
    _tri(surf, c, b, r1)

# balcony projecting from a face at z = zface (zs = +1 front / -1 back): slab + glass rail
func _balcony(x: float, y: float, zface: float, w: float, depth: float, zs: float) -> void:
    _box(S_TRIM_L, S_TRIM_L, Vector3(x, y, zface + zs * depth * 0.5), Vector3(w, 0.18, depth))
    _box(S_RAIL, S_RAIL, Vector3(x, y + 0.6, zface + zs * depth), Vector3(w, 1.05, 0.04))

func _finish(facade: Material, glass: Material, led: Material) -> ArrayMesh:
    var mesh := ArrayMesh.new()
    var slots: Array = [facade, glass, m_trim_l, m_trim_d, led, m_rail]
    for k in 6:
        if int(_counts[k]) == 0:
            continue
        var st: SurfaceTool = _sts[k]
        st.generate_normals()
        st.commit(mesh)
        mesh.surface_set_material(mesh.get_surface_count() - 1, slots[k])
    return mesh

func _add_variant(cat: String, w: float, d: float, h: float, facade: Material, led: Material) -> void:
    var glass: Material = m_glass_t if cat == "tower" else m_glass
    var mesh: ArrayMesh = _finish(facade, glass, led)
    variants.append({"mesh": mesh, "w": w, "d": d, "h": h, "cat": cat})
    if not by_cat.has(cat):
        by_cat[cat] = []
    by_cat[cat].append(variants.size() - 1)

# ---------------------------------------------------------------- archetypes
func _g_tower(w: float, d: float, floors: int, crown_floors: int) -> float:
    var h: float = float(floors) * FLOOR_H
    var pod: float = 2.0 * FLOOR_H
    _box(S_FACADE, S_TRIM_D, Vector3(0, pod * 0.5, 0), Vector3(w * 1.3, pod, d * 1.3))
    _box(S_TRIM_L, S_TRIM_L, Vector3(0, 4.6, d * 0.65 + 1.4), Vector3(w * 0.7, 0.3, 3.2))
    _box(S_GLASS, S_GLASS, Vector3(0, 2.3, d * 0.65 + 0.05), Vector3(w * 0.62, 4.4, 0.1))
    var crown: float = float(crown_floors) * FLOOR_H
    var shaft: float = h - pod - crown
    _box(S_GLASS, S_TRIM_D, Vector3(0, pod + shaft * 0.5, 0), Vector3(w, shaft, d))
    for k in 5:
        var fx: float = -w * 0.5 + w * (float(k) + 0.5) / 5.0
        for zs in [-1.0, 1.0]:
            _box(S_TRIM_L, S_TRIM_L, Vector3(fx, pod + shaft * 0.5, float(zs) * (d * 0.5 + 0.2)), Vector3(0.3, shaft, 0.5))
    _box(S_GLASS, S_TRIM_D, Vector3(0, pod + shaft + crown * 0.5, 0), Vector3(w * 0.72, crown, d * 0.72))
    _box(S_LED, S_LED, Vector3(0, pod + shaft + 0.2, 0), Vector3(w * 1.02, 0.35, d * 1.02))
    _box(S_LED, S_LED, Vector3(0, h + 0.2, 0), Vector3(w * 0.75, 0.3, d * 0.75))
    _box(S_TRIM_D, S_TRIM_D, Vector3(0, h + 7.0, 0), Vector3(0.5, 14.0, 0.5))
    _box(S_LED, S_LED, Vector3(0, h + 14.2, 0), Vector3(0.7, 0.7, 0.7))
    return h + 14.0

func _g_stepped(w: float, d: float) -> float:
    var y: float = 0.0
    var fl: Array = [10, 8, 6]
    var sc: Array = [1.0, 0.74, 0.5]
    for k in 3:
        var hh: float = float(fl[k]) * FLOOR_H
        var ww: float = w * float(sc[k])
        var dd: float = d * float(sc[k])
        if k == 0:
            _box(S_FACADE, S_TRIM_D, Vector3(0, y + hh * 0.5, 0), Vector3(ww, hh, dd))
        else:
            _box(S_GLASS, S_TRIM_D, Vector3(0, y + hh * 0.5, 0), Vector3(ww, hh, dd))
        _box(S_LED, S_LED, Vector3(0, y + hh + 0.15, 0), Vector3(ww * 1.03, 0.3, dd * 1.03))
        for sx in [-1.0, 1.0]:
            _box(S_TRIM_D, S_TRIM_D, Vector3(float(sx) * ww * 0.5, y + hh * 0.5, dd * 0.5), Vector3(0.5, hh, 0.5))
        y += hh
    _box(S_TRIM_D, S_TRIM_D, Vector3(0, y + 6.0, 0), Vector3(0.45, 12.0, 0.45))
    return y + 12.0

func _g_hotel(w: float, d: float, floors: int) -> float:
    var h: float = float(floors) * FLOOR_H
    var pod: float = 2.0 * FLOOR_H
    _box(S_FACADE, S_TRIM_D, Vector3(0, pod * 0.5, 0), Vector3(w * 1.08, pod, d * 1.08))
    _box(S_FACADE, S_TRIM_D, Vector3(0, pod + (h - pod) * 0.5, 0), Vector3(w, h - pod, d))
    _box(S_GLASS, S_GLASS, Vector3(0, 2.5, d * 0.54 + 0.05), Vector3(w * 0.5, 4.6, 0.1))
    _box(S_TRIM_L, S_TRIM_L, Vector3(0, 5.2, d * 0.54 + 1.6), Vector3(w * 0.5, 0.3, 3.6))
    for f in range(2, floors):
        for k in 3:
            var x: float = -w * 0.5 + w * (float(k) + 0.5) / 3.0
            _balcony(x, float(f) * FLOOR_H, d * 0.5, w / 3.0 - 0.8, 1.5, 1.0)
    _box(S_TRIM_L, S_TRIM_L, Vector3(0, h + 0.4, 0), Vector3(w * 1.02, 0.8, d * 1.02))
    _box(S_GLASS, S_GLASS, Vector3(w * 0.2, h + 0.85, d * 0.15), Vector3(w * 0.4, 0.1, d * 0.3))
    _box(S_TRIM_D, S_TRIM_D, Vector3(-w * 0.25, h + 1.4, -d * 0.2), Vector3(w * 0.25, 1.4, d * 0.25))
    _box(S_LED, S_LED, Vector3(0, h + 0.85, d * 0.51), Vector3(w * 0.9, 0.12, 0.12))
    return h + 2.0

func _g_apt(w: float, d: float, floors: int, step: int) -> float:
    var h: float = float(floors) * FLOOR_H
    _box(S_FACADE, S_TRIM_D, Vector3(0, h * 0.5, 0), Vector3(w, h, d))
    _box(S_GLASS, S_GLASS, Vector3(0, 2.0, d * 0.5 + 0.05), Vector3(w * 0.86, 3.4, 0.1))
    for f in range(1, floors):
        for k in 3:
            if (f + k + step) % 2 == 0:
                var x: float = -w * 0.5 + w * (float(k) + 0.5) / 3.0
                _balcony(x, float(f) * FLOOR_H, d * 0.5, w / 3.0 - 1.2, 1.3, 1.0)
    _box(S_TRIM_D, S_TRIM_D, Vector3(w * 0.5 - 0.5, h * 0.5, d * 0.5 + 0.1), Vector3(1.0, h, 0.3))
    _box(S_TRIM_L, S_TRIM_L, Vector3(0, h + 0.3, 0), Vector3(w + 0.4, 0.6, d + 0.4))
    _box(S_TRIM_D, S_TRIM_D, Vector3(0, h + 1.0, -d * 0.2), Vector3(w * 0.3, 1.2, d * 0.25))
    return h + 1.6

func _g_commercial(w: float, d: float, floors: int) -> float:
    var h: float = float(floors) * FLOOR_H
    _box(S_GLASS, S_TRIM_D, Vector3(0, 2.2, 0), Vector3(w, 4.4, d))
    _box(S_LED, S_LED, Vector3(0, 4.7, d * 0.5 + 0.12), Vector3(w * 0.8, 0.45, 0.1))
    _box(S_FACADE, S_TRIM_D, Vector3(0, 4.4 + (h - 4.4) * 0.5, 0), Vector3(w * 0.96, h - 4.4, d * 0.96))
    _box(S_TRIM_L, S_TRIM_L, Vector3(0, 4.55, d * 0.5 + 1.2), Vector3(w * 0.9, 0.25, 2.4))
    _box(S_LED, S_LED, Vector3(0, h + 0.15, d * 0.48), Vector3(w * 0.9, 0.12, 0.12))
    _box(S_TRIM_D, S_TRIM_D, Vector3(w * 0.25, h + 0.9, 0), Vector3(w * 0.2, 1.4, d * 0.3))
    return h + 1.6

func _g_villa(w: float, d: float) -> float:
    _box(S_FACADE, S_TRIM_L, Vector3(0, 1.7, 0), Vector3(w, 3.4, d))
    _box(S_FACADE, S_TRIM_L, Vector3(-w * 0.1, 5.0, -d * 0.1), Vector3(w * 0.66, 3.2, d * 0.8))
    _box(S_GLASS, S_GLASS, Vector3(-w * 0.1, 5.0, d * 0.3 + 0.05), Vector3(w * 0.5, 2.4, 0.1))
    _box(S_GLASS, S_GLASS, Vector3(w * 0.15, 1.7, d * 0.5 + 0.05), Vector3(w * 0.5, 2.6, 0.1))
    _box(S_TRIM_L, S_TRIM_L, Vector3(-w * 0.1, 6.75, -d * 0.1), Vector3(w * 0.66 + 1.4, 0.3, d * 0.8 + 1.4))
    _box(S_TRIM_L, S_TRIM_L, Vector3(w * 0.28, 3.5, 0.0), Vector3(w * 0.44, 0.25, d))
    _box(S_RAIL, S_RAIL, Vector3(w * 0.28, 4.1, d * 0.5), Vector3(w * 0.44, 1.0, 0.04))
    _box(S_TRIM_D, S_TRIM_D, Vector3(-w * 0.1 - w * 0.33, 5.0, d * 0.3 + 0.1), Vector3(0.5, 3.2, 0.2))
    _box(S_LED, S_LED, Vector3(-w * 0.1, 6.55, d * 0.3 + 0.7), Vector3(w * 0.6, 0.08, 0.08))
    _box(S_TRIM_L, S_TRIM_L, Vector3(0, 0.05, d * 0.5 + 4.5), Vector3(w * 0.6 + 1.6, 0.1, 5.2))
    _box(S_GLASS, S_GLASS, Vector3(0, 0.12, d * 0.5 + 4.5), Vector3(w * 0.6, 0.1, 3.6))
    return 7.2

func _g_boutique(w: float, d: float, floors: int) -> float:
    var h: float = float(floors) * FLOOR_H
    _box(S_FACADE, S_TRIM_D, Vector3(0, h * 0.5, 0), Vector3(w, h, d))
    _box(S_TRIM_L, S_TRIM_L, Vector3(0, h - 0.2, 0), Vector3(w + 0.8, 0.5, d + 0.8))
    _hip(S_TRIM_D, Vector3(0, h + 0.05, 0), w + 1.0, d + 1.0, 2.8)
    for f in range(1, floors):
        for k in 2:
            var x: float = -w * 0.25 + w * 0.5 * float(k)
            _balcony(x, float(f) * FLOOR_H, d * 0.5, 3.0, 1.1, 1.0)
    _box(S_GLASS, S_GLASS, Vector3(0, 1.9, d * 0.5 + 0.05), Vector3(w * 0.7, 3.2, 0.1))
    _box(S_TRIM_L, S_TRIM_L, Vector3(0, 3.7, d * 0.5 + 0.9), Vector3(w * 0.72, 0.18, 1.8))
    _box(S_TRIM_L, S_TRIM_L, Vector3(w * 0.3, h + 2.0, 0), Vector3(0.9, 2.4, 0.9))
    return h + 2.9

func _build_variants() -> void:
    # glass towers
    _begin()
    var h1: float = _g_tower(24.0, 24.0, 30, 3)
    _add_variant("tower", 24.0, 24.0, h1, m_stone, led_cyan)
    _begin()
    var h2: float = _g_tower(16.0, 26.0, 24, 2)
    _add_variant("tower", 16.0, 26.0, h2, m_plaster, led_magenta)
    _begin()
    var h3: float = _g_stepped(28.0, 28.0)
    _add_variant("tower", 28.0, 28.0, h3, m_stone, led_amber)
    # hotels
    _begin()
    var h4: float = _g_hotel(42.0, 20.0, 12)
    _add_variant("hotel", 42.0, 20.0, h4, m_stone, led_cyan)
    _begin()
    var h5: float = _g_hotel(34.0, 18.0, 9)
    _add_variant("hotel", 34.0, 18.0, h5, m_plaster, led_amber)
    # apartments
    _begin()
    var h6: float = _g_apt(30.0, 16.0, 8, 0)
    _add_variant("apt", 30.0, 16.0, h6, m_plaster, led_amber)
    _begin()
    var h7: float = _g_apt(24.0, 24.0, 6, 1)
    _add_variant("apt", 24.0, 24.0, h7, m_stone, led_cyan)
    _begin()
    var h8: float = _g_apt(36.0, 15.0, 10, 1)
    _add_variant("apt", 36.0, 15.0, h8, m_plaster, led_magenta)
    # commercial
    _begin()
    var h9: float = _g_commercial(38.0, 24.0, 5)
    _add_variant("comm", 38.0, 24.0, h9, m_metal, led_magenta)
    # villas
    _begin()
    var h10: float = _g_villa(18.0, 14.0)
    _add_variant("villa", 18.0, 24.0, h10, m_plaster, led_cyan)
    # boutique / mediterranean
    _begin()
    var h11: float = _g_boutique(18.0, 13.0, 4)
    _add_variant("boutique", 18.0, 13.0, h11, m_stone, led_amber)
    _begin()
    var h12: float = _g_boutique(22.0, 14.0, 5)
    _add_variant("boutique", 22.0, 14.0, h12, m_plaster, led_amber)

# ---------------------------------------------------------------- placement
func _fkey(x: float, z: float) -> Vector2i:
    return Vector2i(int(floorf(x / 60.0)), int(floorf(z / 60.0)))

func _register(p: Vector2, r: float) -> void:
    var k: Vector2i = _fkey(p.x, p.y)
    if not foot.has(k):
        foot[k] = []
    foot[k].append(Vector3(p.x, p.y, r))

# true if a circle (p, r) touches a building that is already placed (also used by nature.gd)
func overlaps(p: Vector2, r: float) -> bool:
    var k: Vector2i = _fkey(p.x, p.y)
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            var kk := Vector2i(k.x + dx, k.y + dz)
            if foot.has(kk):
                for f in foot[kk]:
                    var fv: Vector3 = f
                    if p.distance_to(Vector2(fv.x, fv.y)) < r + fv.z:
                        return true
    return false

func _add_instance(vi: int, center: Vector2, yaw: float, sx: float, sy: float, sz: float, tint: Color) -> void:
    var rot := Basis(Vector3.UP, yaw).scaled(Vector3(sx, sy, sz))
    var xf := Transform3D(rot, Vector3(center.x, 0.0, center.y))
    var key := Vector2i(int(floorf(center.x / CHUNK)), int(floorf(center.y / CHUNK)))
    if not chunks.has(key):
        chunks[key] = {}
    var ch: Dictionary = chunks[key]
    if not ch.has(vi):
        ch[vi] = []
    ch[vi].append([xf, tint])
    var vr: Dictionary = variants[vi]
    var w: float = float(vr["w"]) * sx
    var d: float = float(vr["d"]) * sz
    _register(center, 0.5 * sqrt(w * d) * 1.1)
    placed += 1

func _pick_cat(names: Array, weights: Array) -> String:
    var total: float = 0.0
    for wv in weights:
        total += float(wv)
    var r: float = rng.randf() * total
    for k in names.size():
        r -= float(weights[k])
        if r <= 0.0:
            return str(names[k])
    return str(names[names.size() - 1])

func _random_variant(cat: String) -> int:
    var list: Array = by_cat[cat]
    return int(list[rng.randi_range(0, list.size() - 1)])

func _tint_for(cat: String) -> Color:
    if cat == "tower":
        return GLASS_TINTS[rng.randi_range(0, GLASS_TINTS.size() - 1)]
    return FACADE_TINTS[rng.randi_range(0, FACADE_TINTS.size() - 1)]

func _place_osm(list: Array) -> void:
    for bi in list.size():
        var b: Array = list[bi]
        if algiers._building_blocked(b):
            continue
        var n: int = int((b.size() - 1) / 2.0)
        if n < 3:
            continue
        var poly: Array = []
        for k in n:
            poly.append(Vector2(float(b[1 + k * 2]), float(b[2 + k * 2])))
        var longest: float = 0.0
        var ang: float = 0.0
        for k in n:
            var pa: Vector2 = poly[k]
            var pb: Vector2 = poly[(k + 1) % n]
            var l: float = pa.distance_to(pb)
            if l > longest:
                longest = l
                ang = atan2(pb.y - pa.y, pb.x - pa.x)
        var ca: float = cos(ang)
        var sa: float = sin(ang)
        var minx: float = 1.0e9
        var maxx: float = -1.0e9
        var minz: float = 1.0e9
        var maxz: float = -1.0e9
        for pv in poly:
            var v: Vector2 = pv
            var rx: float = v.x * ca + v.y * sa
            var rz: float = -v.x * sa + v.y * ca
            minx = minf(minx, rx)
            maxx = maxf(maxx, rx)
            minz = minf(minz, rz)
            maxz = maxf(maxz, rz)
        var w: float = maxx - minx
        var d: float = maxz - minz
        var area: float = w * d
        if area < 90.0:
            continue
        var cr := Vector2((minx + maxx) * 0.5, (minz + maxz) * 0.5)
        var center := Vector2(cr.x * ca - cr.y * sa, cr.x * sa + cr.y * ca)
        var h: float = float(b[0])
        var cat: String = _cat_for(h, area)
        var vi: int = _random_variant(cat)
        var vr: Dictionary = variants[vi]
        var sx: float = clampf(w / float(vr["w"]), 0.7, 1.6)
        var sz: float = clampf(d / float(vr["d"]), 0.7, 1.6)
        var sy: float = clampf(h / float(vr["h"]), 0.85, 1.3)
        if cat == "villa" or cat == "boutique":
            sy = rng.randf_range(0.92, 1.1)
        var yaw: float = -ang
        var ni: int = algiers.road_nearest(center)
        if ni >= 0:
            var to_road: Vector2 = algiers.pts[ni] - center
            var zaxis := Vector2(sin(yaw), cos(yaw))
            if to_road.dot(zaxis) < 0.0:
                yaw += PI
        _add_instance(vi, center, yaw, sx, sy, sz, _tint_for(cat))

func _cat_for(h: float, area: float) -> String:
    if area < 160.0:
        return "villa"
    if (h >= 38.0 and area > 300.0) or (area > 500.0 and rng.randf() < 0.1):
        return "tower"
    if h >= 22.0 or area > 900.0:
        return _pick_cat(["hotel", "apt", "comm"], [0.35, 0.4, 0.25])
    if h >= 12.0:
        return _pick_cat(["apt", "comm", "boutique"], [0.45, 0.2, 0.35])
    return _pick_cat(["villa", "boutique", "apt"], [0.4, 0.35, 0.25])

func _cat_for_row(row: int) -> String:
    if row == 0:
        return _pick_cat(["hotel", "apt", "comm", "boutique", "tower"], [0.22, 0.28, 0.2, 0.2, 0.1])
    if row == 1:
        return _pick_cat(["tower", "apt", "hotel", "villa", "boutique"], [0.22, 0.3, 0.15, 0.2, 0.13])
    return _pick_cat(["villa", "boutique", "apt", "tower"], [0.5, 0.2, 0.2, 0.1])

func _lot_ok(center: Vector2, t: Vector2, side: float, w: float, d: float) -> bool:
    if algiers.in_sea(center):
        return false
    if algiers.wadi_on and algiers.in_wadi(center, maxf(w, d) * 0.5 + 6.0):
        return false
    if algiers.in_water_zone(center, maxf(w, d) * 0.5 + 4.0):
        return false
    var nrm := Vector2(-t.y, t.x)
    var front: Vector2 = center - nrm * side * (d * 0.5)
    for e in [-1.0, 1.0]:
        var corner: Vector2 = front + t * float(e) * (w * 0.5)
        if algiers.road_dist(corner) < TW + 6.0:
            return false
    if algiers.road_dist(center) < d * 0.5 + 9.0:
        return false
    return not overlaps(center, 0.5 * sqrt(w * d) * 1.1)

func _place_lots() -> void:
    var pts: Array[Vector2] = algiers.pts
    var n: int = pts.size()
    for i in range(8, n - 8, 6):
        var t: Vector2 = (pts[i + 1] - pts[i - 1]).normalized()
        var nrm := Vector2(-t.y, t.x)
        for side in [-1.0, 1.0]:
            var sd: float = side
            for row in 3:
                var chance: float = 0.92 if row == 0 else (0.75 if row == 1 else 0.5)
                if rng.randf() > chance:
                    continue
                var cat: String = _cat_for_row(row)
                var vi: int = _random_variant(cat)
                var vr: Dictionary = variants[vi]
                var sx: float = rng.randf_range(0.88, 1.2)
                var sz: float = rng.randf_range(0.9, 1.15)
                var sy: float = rng.randf_range(0.92, 1.12)
                var w: float = float(vr["w"]) * sx
                var d: float = float(vr["d"]) * sz
                var gap: float = 17.0 + rng.randf_range(0.0, 8.0)
                if row == 1:
                    gap = 55.0 + rng.randf_range(0.0, 25.0)
                elif row == 2:
                    gap = 105.0 + rng.randf_range(0.0, 30.0)
                var along: float = rng.randf_range(-8.0, 8.0)
                var center: Vector2 = pts[i] + t * along + nrm * sd * (gap + d * 0.5)
                if not _lot_ok(center, t, sd, w, d):
                    continue
                var yaw: float = atan2(-t.y, t.x)
                if sd > 0.0:
                    yaw += PI
                _add_instance(vi, center, yaw, sx, sy, sz, _tint_for(cat))

func _commit() -> void:
    for key in chunks:
        var kk: Vector2i = key
        var ch: Dictionary = chunks[kk]
        var origin := Vector3((float(kk.x) + 0.5) * CHUNK, 0.0, (float(kk.y) + 0.5) * CHUNK)
        for vkey in ch:
            var vi: int = vkey
            var list: Array = ch[vi]
            var mm := MultiMesh.new()
            mm.transform_format = MultiMesh.TRANSFORM_3D
            mm.use_colors = true
            mm.mesh = variants[vi]["mesh"]
            mm.instance_count = list.size()
            for k in list.size():
                var pair: Array = list[k]
                var xf: Transform3D = pair[0]
                xf.origin -= origin
                mm.set_instance_transform(k, xf)
                mm.set_instance_color(k, pair[1])
            var mi := MultiMeshInstance3D.new()
            mi.multimesh = mm
            mi.position = origin
            mi.visibility_range_end = VIS_RANGE
            add_child(mi)

# osm: the "b" list of maps/algiers.json ([height, x1, z1, x2, z2, ...] per building)
func build(alg, osm: Array) -> void:
    algiers = alg
    name = "Premium_City"
    rng.seed = 90210
    _make_materials()
    _build_variants()
    _place_osm(osm)
    _place_lots()
    _commit()
