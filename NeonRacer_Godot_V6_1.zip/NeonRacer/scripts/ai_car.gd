extends AnimatableBody3D
## AI racer. Drives along the stage line by (s, d); the player collides with its body.
const CarScript := preload("res://scripts/car.gd")

var route                      # route.gd instance
var player                     # the player's car (for rubber-banding)
var field: Array = []          # every racer (incl. player) for avoidance
var is_ai := true
var racing := false
var finished := false
var finish_time := 0.0
var racer_name := "AI"
var number := 1
var rcolor := Color.WHITE
var rs := 0.0
var rd := 0.0
var speed := 0.0
var model_index := 0
var skill := 0.9               # stage difficulty x personal factor
var corner_skill := 0.95       # how close to the corner limit this driver dares to go
var max_v := 60.0
var accel := 20.0
var lane := 0.0                # preferred lane offset
var lane_timer := 0.0
var done_timer := 0.0
var model: Node3D
var wheels: Array = []
var wheel_spin := 0.0
var engine: AudioStreamPlayer3D
var sound_on := true
var sfx_vol := 1.0

func setup_car(idx: int, hue: float, label_color: Color) -> void:
    model_index = idx % CarScript.MODELS.size()
    var st: Dictionary = CarScript.STATS[model_index]
    max_v = float(st["max"]) * skill
    accel = float(st["acc"]) * (0.85 + skill * 0.2)
    rcolor = label_color
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(1.9, 0.9, 4.2)
    cs.shape = bs
    cs.position.y = 0.2
    add_child(cs)
    var ps = load(CarScript.MODELS[model_index])
    if ps != null:
        model = ps.instantiate()
        model.rotation.y = -PI / 2.0
        model.scale = Vector3.ONE * CarScript.MODEL_SCALE
        model.position = Vector3(0, -0.236, 0)
        CarScript.tint_model(model, hue)
        add_child(model)
        for n in ["FL", "FR", "RL", "RR"]:
            var w = model.find_child(n, true, false)
            if w != null:
                wheels.append(w)
    var tag := Label3D.new()
    tag.text = str(number)
    tag.font_size = 72
    tag.pixel_size = 0.012
    tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    tag.modulate = label_color
    tag.outline_modulate = Color(0, 0, 0, 0.9)
    tag.outline_size = 14
    tag.position = Vector3(0, 2.1, 0)
    tag.no_depth_test = false
    tag.visibility_range_end = 140.0
    add_child(tag)
    var wav = load("res://audio/engine.wav")
    if wav != null:
        var stream: AudioStreamWAV = wav.duplicate()
        stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
        stream.loop_begin = 0
        stream.loop_end = stream.data.size() / 2
        engine = AudioStreamPlayer3D.new()
        engine.stream = stream
        engine.unit_size = 14.0
        engine.max_distance = 110.0
        engine.volume_db = -9.0
        add_child(engine)
        engine.play()
    lane = randf_range(-3.5, 3.5)
    rd = lane
    _apply_transform(0.0, 0.0)

func place(s: float, d: float) -> void:
    rs = s
    rd = d
    lane = d
    speed = 0.0
    _apply_transform(0.0, 0.0)

func _apply_transform(delta: float, lat_v: float) -> void:
    var p: Vector3 = route.world_pos(rs, rd)
    global_position = Vector3(p.x, 0.5, p.z)
    var yaw: float = route.yaw_at(rs)
    if delta > 0.0 and speed > 3.0:
        yaw -= clampf(atan2(lat_v, speed), -0.35, 0.35)
    rotation.y = yaw

func _physics_process(delta: float) -> void:
    if route == null:
        return
    if finished:
        # brake in the run-off, then disappear so the finished race stays tidy
        speed = move_toward(speed, 0.0, 30.0 * delta)
        rs += speed * delta
        done_timer += delta
        _apply_transform(delta, 0.0)
        if done_timer > 4.0 and visible:
            visible = false
            if engine != null:
                engine.stop()
            for c in get_children():
                if c is CollisionShape3D:
                    c.set_deferred("disabled", true)
        _visuals(delta)
        return
    if not racing:
        _visuals(delta)
        return

    # ---- target speed: corner limits looking ahead, with braking distance ----
    var vt := max_v
    for look in [0.0, 25.0, 60.0, 100.0, 150.0]:
        var cv: float = route.corner_speed_at(rs + look) * corner_skill
        vt = minf(vt, sqrt(cv * cv + 2.0 * 26.0 * look))
    # rubber band toward the player so races stay close
    if player != null:
        var gap: float = rs - player.rs
        vt *= clampf(1.0 - gap * 0.0006, 0.93, 1.06)

    # ---- traffic: look for cars just ahead, move aside, never ram ----
    lane_timer -= delta
    if lane_timer <= 0.0:
        lane_timer = randf_range(2.5, 6.0)
        lane = clampf(lane + randf_range(-2.5, 2.5), -5.0, 5.0)
    var target_d := lane
    for o in field:
        if o == self or not is_instance_valid(o) or o.finished:
            continue
        var ds: float = o.rs - rs
        if ds > 0.0 and ds < 28.0 and absf(o.rd - rd) < 2.7:
            var away := 1.0 if rd >= o.rd else -1.0
            if absf(rd - o.rd) < 0.15:
                away = 1.0 if lane >= 0.0 else -1.0
            target_d = clampf(o.rd + away * 3.3, -5.2, 5.2)
            if ds < 11.0 and absf(o.rd - rd) < 2.3:
                vt = minf(vt, maxf(o.speed * 0.97, 8.0))
    var old_d := rd
    rd = move_toward(rd, target_d, 3.6 * delta)

    # ---- speed ----
    if speed < vt:
        var acc := accel * (1.0 - clampf(speed / (max_v * 1.05), 0.0, 0.95)) + 2.0
        speed = minf(speed + acc * delta, vt)
    else:
        speed = move_toward(speed, vt, 34.0 * delta)
    rs += speed * delta
    _apply_transform(delta, (rd - old_d) / maxf(delta, 0.0001))
    _visuals(delta)

func _visuals(delta: float) -> void:
    wheel_spin += speed / (0.25 * CarScript.MODEL_SCALE) * delta
    for w in wheels:
        var wn: Node3D = w
        wn.rotation = Vector3(0.0, 0.0, wheel_spin)
    if engine != null:
        engine.pitch_scale = 0.55 + speed / 70.0 * 2.0
        engine.volume_db = (-9.0 + linear_to_db(maxf(sfx_vol, 0.0001))) if sound_on else -80.0
