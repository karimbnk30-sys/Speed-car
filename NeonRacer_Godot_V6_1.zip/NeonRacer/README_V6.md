# Neon Racer V6.1
New: music + full sfx set, skid marks, sparks, nitro flame, car damage, drift score with combo,
slipstream boost, speed traps, rain + wet road (stages 5 and 7), ghost car of your best run,
best times, cinematic finish camera, car shop + engine/handling/nitro upgrades (5 levels),
settings screen (graphics preset, FPS limit, controls, steering sensitivity, volumes, km/h|mph,
vibration, language EN/AR/FR), first-run tutorial.
NOTE: written without a Godot editor available - not yet test-run. Arabic text needs a device font with Arabic glyphs.
Old saves keep all 4 cars owned; new saves start with car 1 only.

V6.1: loading screen that names each load step, and on-screen error text (reads user://logs/godot.log).
If a stage will not start, a message explains which script failed to compile.
