# Neon Racer – النسخة التجريبية القابلة للعب (Godot 4.3+)

## التشغيل على الكمبيوتر
1. حمّل Godot 4.3 أو أحدث (النسخة Standard وليس .NET) من godotengine.org
2. Import ← اختر ملف project.godot ← اضغط F5
3. المفاتيح: W/S تسارع/فرامل، A/D انعطاف، Space انجراف

## بناء APK
1. ثبّت JDK 17 و Android SDK (Android Studio يكفي).
2. Godot: Editor > Manage Export Templates > Download and Install
3. Editor > Editor Settings > Export > Android: حدّد مسار Java SDK و Android SDK.
4. أنشئ مفتاح التصحيح (مرة واحدة):
   keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
   ثم ضع مساره في Editor Settings > Export > Android > Debug Keystore (المستخدم androiddebugkey وكلمة السر android).
5. Project > Export > Add… > Android ← فعّل Export With Debug ← Export Project ← اسم الملف neonracer.apk
6. انقل الـ APK للهاتف وثبّته (اسمح بالتثبيت من مصادر غير معروفة)، أو وصّل الهاتف بـ USB وفعّل USB debugging واضغط أيقونة Android أعلى المحرر.

## ملاحظات
- إن كان الانعطاف بالإمالة معكوساً: غيّر TILT_SIGN في scripts/main.gd إلى -1.0

## إضافة مقام الشهيد – الجزائر العاصمة (V7)
- أضيف معلم مقام الشهيد إلى خريطة الجزائر الحالية عبر `scripts/maqam_echahid.gd`.
- يتضمن النموذج ثلاث دعامات/أجنحة منحنية، قاعدة وساحة واسعة ودرجاً وحدائق ونخيلاً وإنارة وعلم الجزائر.
- أضيف طريق وصول قصير يربط الساحة بالطريق الموجود قرب انتقال مرحلتي CASBAH RUN وHILLTOP RUSH.
- تم حجز مساحة المعلم من مولّد المباني والقطع السكنية لتقليل تداخل المباني معه.
- لم يتم تعديل `car.gd` أو `ai_car.gd` أو `route.gd` أو `stages.gd` أو نظام التحكم والسباقات.
- موضع المعلم داخل الخريطة تقريبي ومصمم ليتوافق مع المساحة المتاحة في خريطة المشروع؛ يمكن ضبطه لاحقاً بعد المعاينة داخل Godot.
