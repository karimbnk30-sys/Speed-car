# Neon Racer V6.1
New: music + full sfx set, skid marks, sparks, nitro flame, car damage, drift score with combo,
slipstream boost, speed traps, rain + wet road (stages 5 and 7), ghost car of your best run,
best times, cinematic finish camera, car shop + engine/handling/nitro upgrades (5 levels),
settings screen (graphics preset, FPS limit, controls, steering sensitivity, volumes, km/h|mph,
vibration, language EN/AR/FR), first-run tutorial.
NOTE: written without a Godot editor available - not yet test-run. Arabic text needs a device font with Arabic glyphs.
Old saves keep all 4 cars owned; new saves start with car 1 only.

V6.2 (fixed type-inference parse error in algiers.gd). V6.1: loading screen that names each load step, and on-screen error text (reads user://logs/godot.log).
If a stage will not start, a message explains which script failed to compile.

V6.3: OSM buildings touching the road are removed and generated blocks are placed by wall distance (no more buildings on the road);
two-way road (double yellow line, dashed lane lines) with ambient traffic (same direction + oncoming), racers keep to the right half;
puddles (spray, hydroplaning, splash sound), potholes (jolt + damage), cracks and rubble on damaged stretches;
a dry river channel (oued) with a bridge deck + piers around route point ~925 (stages 2, 5, 7, 8).

V7 (environment overhaul): new modules city.gd (12 premium building archetypes: glass towers, hotels, apartments, commercial,
villas, boutique - instanced, tinted, night-lit windows), nature.gd (5 tree species + bushes, flowers, grass), waterfront.gd (ONE ~130 m
waterfront along the road: promenade, sea wall, sand shore, animated reflective water, pier, boats, palms, reeds, rocks, benches, lamps),
roadside.gd (curved street lamps, speed-limit + chevron signs, zebra crossings, checkpoint gates, start-grid paint),
texgen.gd (asphalt tile with lane markings, facade tiles, vegetation + sign textures). Checkpoints (3 per stage) with split times vs your best.
Waterfront is on route index 728-752 (stages 2, 5, 7, 8); the bridge/oued is at ~925.
