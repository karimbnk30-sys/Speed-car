extends Node
## Stage select: horizontally scrolling cards, locked until the previous stage is finished in the top 3.
const ShowroomScript := preload("res://scripts/showroom.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const Tr := preload("res://scripts/tr.gd")
const StagesScript := preload("res://scripts/stages.gd")
const CARD := Vector2(300, 400)

func _ready() -> void:
    Audio.play_music("music_menu")
    var sr := ShowroomScript.new()
    sr.model_index = int(Save.get_in("garage.selected", 0))
    sr.orbit_speed = 0.12
    add_child(sr)
    var layer := CanvasLayer.new()
    add_child(layer)
    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.03, 0.62)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(dim)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var sz := get_viewport().get_visible_rect().size
    var ins := UIUtil.safe_insets(get_viewport())

    var title := UIUtil.make_label(Tr.t("SELECT STAGE"), 60, Color(0.0, 0.95, 1.0))
    title.position = Vector2(ins.x, ins.y)
    root.add_child(title)
    var money := UIUtil.make_label(Tr.t("MONEY") + "  %d" % int(Save.get_in("profile.money", 0)), 34, Color(0.3, 1.0, 0.5))
    money.position = Vector2(sz.x - ins.z - 330.0, ins.y + 12.0)
    money.size = Vector2(330, 50)
    money.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    root.add_child(money)

    var scroll := ScrollContainer.new()
    scroll.position = Vector2(ins.x, ins.y + 90.0)
    scroll.size = Vector2(sz.x - ins.x - ins.z, CARD.y + 30.0)
    scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
    root.add_child(scroll)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 22)
    scroll.add_child(row)

    var unlocked := int(Save.get_in("progress.stage_unlocked", 0))
    for i in StagesScript.COUNT:
        row.add_child(_card(i))

    var back := UIUtil.make_button(Tr.t("BACK"), Color(1.0, 0.3, 0.35), Vector2(220, 76))
    back.position = Vector2(ins.x, sz.y - ins.w - 76.0)
    back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/menu.tscn"))
    root.add_child(back)

    # open on the newest unlocked stage
    await get_tree().process_frame
    scroll.scroll_horizontal = maxi(int((CARD.x + 22.0) * float(unlocked)) - 160, 0)

func _card(i: int) -> Button:
    var st: Dictionary = StagesScript.get_stage(i)
    var open := StagesScript.is_unlocked(i)
    var best := StagesScript.best_place(i)
    var col := Color(0.0, 0.9, 1.0)
    var lines := Tr.t("STAGE %d") % (i + 1)
    lines += "\n\n%s\n\n%.1f km\n%s" % [st["name"], StagesScript.length_m(i) / 1000.0, str(st["theme"]).to_upper()]
    if StagesScript.weather_of(i) == "rain":
        lines += "  " + Tr.t("RAIN")
    if open:
        if best > 0:
            lines += "\n\n" + Tr.t("BEST") + "  P%d" % best
            var bt := StagesScript.best_time(i)
            if bt > 0.0:
                lines += "\n" + _fmt_time(bt)
            if best <= 3:
                col = Color(1.0, 0.85, 0.2)
        else:
            lines += "\n\n" + Tr.t("NEW")
            col = Color(0.3, 1.0, 0.5)
    else:
        lines += "\n\n" + Tr.t("LOCKED") + "\n" + Tr.t("Finish top 3") + "\n" + Tr.t("in stage %d") % i
        col = Color(0.45, 0.47, 0.52)
    var b := UIUtil.make_button(lines, col, CARD)
    b.add_theme_font_size_override("font_size", 28)
    b.disabled = not open
    b.add_theme_color_override("font_disabled_color", col)
    b.add_theme_stylebox_override("disabled", UIUtil.box(Color(0.04, 0.05, 0.09, 0.55), col, 2))
    b.pressed.connect(_start.bind(i))
    return b

func _fmt_time(t: float) -> String:
    return "%02d:%05.2f" % [int(t / 60.0), fmod(t, 60.0)]

func _start(i: int) -> void:
    const DiagScript := preload("res://scripts/diag.gd")
    for path in ["main", "algiers", "route", "hud", "ai_car", "car", "skid_marks"]:
        var scr = load("res://scripts/%s.gd" % path)
        if scr == null or not (scr as GDScript).can_instantiate():
            DiagScript.show_message(self, "SCRIPT ERROR in %s.gd\n\n%s\n\nSend a screenshot of this screen." % [path, DiagScript.log_errors(6)])
            return
    Save.next_stage = i
    get_tree().change_scene_to_file("res://scenes/main.tscn")
