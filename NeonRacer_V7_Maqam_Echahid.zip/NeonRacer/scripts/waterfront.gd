extends Node3D
## ONE long waterfront that follows the road like a coastal canal (~130 m): promenade, sea wall, sandy
## shore with foam line, animated reflective water, far bank, pier, boats, palms, reeds, rocks, benches, lamps.
const TexGen := preload("res://scripts/texgen.gd")
const TW := 7.0
const WATER_Y := -0.19
const WATER_IN := 20.4        # lateral distance (from the road centre) where the water surface starts
const WATER_W := 62.0         # lateral distance of the far shore at full width

var algiers
var nature
var i0 := 0
var i1 := 0
var side := -1.0
var cnt := 0
var lamp_mats: Array = []
var wmat: ShaderMaterial

func _pt(i: int, d: float, y: float) -> Vector3:
    var p: Vector2 = algiers.pts[i]
    var n: Vector2 = algiers.nrm[i]
    return Vector3(p.x + n.x * side * d, y, p.y + n.y * side * d)

func _w_out(k: int) -> float:
    var edge: float = float(mini(k, cnt - 1 - k))
    var tp: float = clampf(edge / 5.0, 0.0, 1.0)
    tp = tp * tp * (3.0 - 2.0 * tp)
    return WATER_IN + 3.0 + (WATER_W - WATER_IN - 3.0) * tp

# strip between two lateral profiles; da/ya (+ db/yb) are Arrays with one value per route index i0..i1
func _strip(da: Array, ya: Array, db: Array, yb: Array, mat: Material, tile: float, tangents := false) -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for k in cnt - 1:
        var ia: int = i0 + k
        var ib: int = ia + 1
        var a0: Vector3 = _pt(ia, float(da[k]), float(ya[k]))
        var b0: Vector3 = _pt(ia, float(db[k]), float(yb[k]))
        var a1: Vector3 = _pt(ib, float(da[k + 1]), float(ya[k + 1]))
        var b1: Vector3 = _pt(ib, float(db[k + 1]), float(yb[k + 1]))
        var v0: float = float(algiers.cum[ia]) / tile
        var v1: float = float(algiers.cum[ib]) / tile
        var order: Array = [[a0, 0.0, v0], [b0, 1.0, v0], [a1, 0.0, v1], [b0, 1.0, v0], [b1, 1.0, v1], [a1, 0.0, v1]]
        for e in order:
            st.set_uv(Vector2(float(e[1]), float(e[2])))
            st.add_vertex(e[0])
    st.generate_normals()
    if tangents:
        st.generate_tangents()
    var mi := MeshInstance3D.new()
    mi.mesh = st.commit()
    mi.material_override = mat
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)

func _const_arr(v: float) -> Array:
    var a: Array = []
    for k in cnt:
        a.append(v)
    return a

func _make_water_material() -> ShaderMaterial:
    var nt := NoiseTexture2D.new()
    nt.width = 256
    nt.height = 256
    nt.seamless = true
    nt.as_normal_map = true
    nt.bump_strength = 7.0
    var fn := FastNoiseLite.new()
    fn.frequency = 0.03
    fn.fractal_octaves = 3
    nt.noise = fn
    var sh := Shader.new()
    sh.code = """shader_type spatial;
render_mode specular_schlick_ggx;
uniform sampler2D normal_a : hint_normal, filter_linear_mipmap, repeat_enable;
uniform vec3 shallow_col : source_color = vec3(0.10, 0.52, 0.58);
uniform vec3 deep_col : source_color = vec3(0.02, 0.16, 0.28);
void fragment() {
    vec2 uv = vec2(UV.x * 3.0, UV.y * 0.8);
    vec3 n1 = texture(normal_a, uv + vec2(TIME * 0.012, TIME * 0.03)).rgb;
    vec3 n2 = texture(normal_a, uv * 2.1 + vec2(-TIME * 0.02, TIME * 0.045)).rgb;
    NORMAL_MAP = mix(n1, n2, 0.5);
    NORMAL_MAP_DEPTH = 0.9;
    float depth = smoothstep(0.0, 0.5, UV.x);
    vec3 col = mix(shallow_col, deep_col, depth);
    float foam = (1.0 - smoothstep(0.0, 0.05, UV.x)) * (0.65 + 0.35 * sin(TIME * 1.8 + UV.y * 9.0));
    foam += smoothstep(0.95, 1.0, UV.x) * 0.4;
    ALBEDO = col + vec3(foam * 0.8);
    ROUGHNESS = mix(0.04, 0.3, clamp(foam, 0.0, 1.0));
    METALLIC = 0.0;
    SPECULAR = 0.9;
    ALPHA = mix(0.82, 0.96, depth);
}
"""
    var sm := ShaderMaterial.new()
    sm.shader = sh
    sm.set_shader_parameter("normal_a", nt)
    return sm

func _std(c: Color, rough: float, tex: Texture2D = null) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    if tex != null:
        m.albedo_texture = tex
        m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    return m

func _mesh_node(m: Mesh, mat: Material, pos: Vector3, rot_y: float, scl: Vector3, shadow := true) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = m
    mi.material_override = mat
    mi.position = pos
    mi.rotation.y = rot_y
    mi.scale = scl
    if not shadow:
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)
    return mi

func _build_surfaces() -> void:
    var prom_mat: Material = algiers.mat_paving
    if prom_mat == null:
        prom_mat = _std(Color(0.64, 0.62, 0.57), 0.9)
    var wall_mat: StandardMaterial3D = _std(Color(0.72, 0.71, 0.68), 0.9)
    var sand_mat: StandardMaterial3D = _std(Color(1.0, 1.0, 1.0), 1.0, TexGen.sand())
    var wet_mat: StandardMaterial3D = _std(Color(0.62, 0.56, 0.44), 1.0, TexGen.sand())
    # promenade
    _strip(_const_arr(12.0), _const_arr(0.14), _const_arr(16.5), _const_arr(0.14), prom_mat, 3.0)
    # sea wall: face + top (lower at both ends)
    var top: Array = []
    for k in cnt:
        var edge: float = clampf(float(mini(k, cnt - 1 - k)) / 5.0, 0.0, 1.0)
        top.append(lerpf(0.14, 0.5, edge))
    _strip(_const_arr(16.5), _const_arr(0.14), _const_arr(16.5), top, wall_mat, 3.0)
    _strip(_const_arr(16.5), top, _const_arr(17.1), top, wall_mat, 3.0)
    # sandy shore sloping into the water
    _strip(_const_arr(17.1), _const_arr(0.08), _const_arr(22.0), _const_arr(-0.26), sand_mat, 4.0)
    var wo: Array = []
    for k in cnt:
        wo.append(maxf(22.5, _w_out(k) - 3.5))
    _strip(_const_arr(22.0), _const_arr(-0.26), wo, _const_arr(-0.27), wet_mat, 4.0)
    # far bank (low sandy mound that hides the water edge)
    var bank_top: Array = []
    var bank_end: Array = []
    var water_out: Array = []
    for k in cnt:
        var wk: float = _w_out(k)
        bank_top.append(wk + 0.4)
        bank_end.append(wk + 4.5)
        water_out.append(wk)
    _strip(wo, _const_arr(-0.28), bank_top, _const_arr(-0.1), sand_mat, 4.0)
    _strip(bank_top, _const_arr(-0.1), bank_end, _const_arr(-0.29), sand_mat, 4.0)
    # the water itself
    wmat = _make_water_material()
    _strip(_const_arr(WATER_IN), _const_arr(WATER_Y), water_out, _const_arr(WATER_Y), wmat, 6.0, true)

func _dir_to_water(i: int) -> Vector2:
    var n: Vector2 = algiers.nrm[i]
    return n * side

func _lamp(i: int, d: float) -> void:
    var p: Vector3 = _pt(i, d, 0.0)
    var pole := CylinderMesh.new()
    pole.top_radius = 0.05
    pole.bottom_radius = 0.09
    pole.height = 4.2
    _mesh_node(pole, _std(Color(0.2, 0.21, 0.24), 0.5), Vector3(p.x, 2.2, p.z), 0.0, Vector3.ONE, false)
    var head := SphereMesh.new()
    head.radius = 0.28
    head.height = 0.56
    var hm := _std(Color(1.0, 0.88, 0.6), 0.4)
    hm.emission_enabled = true
    hm.emission = Color(1.0, 0.85, 0.55)
    hm.emission_energy_multiplier = 1.0
    lamp_mats.append(hm)
    _mesh_node(head, hm, Vector3(p.x, 4.45, p.z), 0.0, Vector3.ONE, false)

func _bench(i: int) -> void:
    var p: Vector3 = _pt(i, 15.6, 0.14)
    var dir: Vector2 = _dir_to_water(i)
    var yaw: float = atan2(dir.x, dir.y)
    var seat := BoxMesh.new()
    seat.size = Vector3(1.9, 0.08, 0.5)
    var back := BoxMesh.new()
    back.size = Vector3(1.9, 0.5, 0.06)
    var wood: StandardMaterial3D = _std(Color(0.45, 0.3, 0.18), 0.8)
    var rot := Basis(Vector3.UP, yaw)
    var s: MeshInstance3D = _mesh_node(seat, wood, p + Vector3(0, 0.45, 0), yaw, Vector3.ONE, false)
    s.rotation.y = yaw
    var b: MeshInstance3D = _mesh_node(back, wood, p + rot * Vector3(0, 0.7, -0.25), yaw, Vector3.ONE, false)
    b.rotation.y = yaw

func _pier(i: int) -> void:
    var n: Vector2 = _dir_to_water(i)
    var yaw: float = atan2(n.x, n.y)           # local +Z points toward the water
    var wood: StandardMaterial3D = _std(Color(0.5, 0.36, 0.22), 0.85)
    var start: Vector3 = _pt(i, 17.5, 0.0)
    var length: float = 17.0
    var deck := BoxMesh.new()
    deck.size = Vector3(2.6, 0.14, length)
    var mid: Vector3 = start + Vector3(n.x, 0.0, n.y) * (length * 0.5)
    _mesh_node(deck, wood, Vector3(mid.x, 0.12, mid.z), yaw, Vector3.ONE)
    var post := CylinderMesh.new()
    post.top_radius = 0.12
    post.bottom_radius = 0.12
    post.height = 1.5
    for k in 6:
        for sx in [-1.0, 1.0]:
            var along: float = 1.5 + float(k) * 3.0
            var pp: Vector3 = start + Vector3(n.x, 0.0, n.y) * along + Vector3(n.y, 0.0, -n.x) * float(sx) * 1.2
            _mesh_node(post, wood, Vector3(pp.x, -0.5, pp.z), 0.0, Vector3.ONE, false)

func _boat(i: int, d: float, hull_col: Color, yaw_off: float) -> void:
    var p: Vector3 = _pt(i, d, WATER_Y)
    var dir: Vector2 = algiers.pts[i + 1] - algiers.pts[i]
    var yaw: float = atan2(dir.x, dir.y) + yaw_off
    var hull := SphereMesh.new()
    hull.radius = 1.0
    hull.height = 2.0
    hull.radial_segments = 10
    hull.rings = 6
    _mesh_node(hull, _std(hull_col, 0.35), Vector3(p.x, p.y + 0.05, p.z), yaw, Vector3(1.0, 0.42, 2.8))
    var cabin := BoxMesh.new()
    cabin.size = Vector3(1.3, 0.75, 1.7)
    _mesh_node(cabin, _std(Color(0.95, 0.95, 0.93), 0.4), Vector3(p.x, p.y + 0.62, p.z) + Vector3(sin(yaw), 0, cos(yaw)) * 0.2, yaw, Vector3.ONE)
    var mast := CylinderMesh.new()
    mast.top_radius = 0.03
    mast.bottom_radius = 0.04
    mast.height = 3.2
    _mesh_node(mast, _std(Color(0.8, 0.8, 0.82), 0.4), Vector3(p.x, p.y + 2.0, p.z), 0.0, Vector3.ONE, false)

func _rocks() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 5150
    var mesh := SphereMesh.new()
    mesh.radius = 0.5
    mesh.height = 1.0
    mesh.radial_segments = 6
    mesh.rings = 4
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    var xfs: Array = []
    for k in range(2, cnt - 2):
        for rep in 2:
            var d: float = rng.randf_range(17.2, 19.2)
            var p: Vector3 = _pt(i0 + k, d, 0.0)
            var sc := Vector3(rng.randf_range(0.6, 1.4), rng.randf_range(0.4, 0.8), rng.randf_range(0.6, 1.3))
            var rot := Basis(Vector3.UP, rng.randf() * TAU).scaled(sc)
            xfs.append(Transform3D(rot, Vector3(p.x + rng.randf_range(-1.5, 1.5), 0.05 + sc.y * 0.1, p.z + rng.randf_range(-1.5, 1.5))))
    mm.mesh = mesh
    mm.instance_count = xfs.size()
    for k in xfs.size():
        mm.set_instance_transform(k, xfs[k])
    var mi := MultiMeshInstance3D.new()
    mi.multimesh = mm
    mi.material_override = _std(Color(0.55, 0.53, 0.5), 1.0, TexGen.rock())
    add_child(mi)

func _vegetation() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 6001
    for k in range(1, cnt - 1, 2):
        var i: int = i0 + k
        # palms on the promenade
        var p: Vector3 = _pt(i, 14.6, 0.0)
        nature.add(0, Vector2(p.x, p.z), rng.randf_range(1.0, 1.35), rng.randf() * TAU, Color(rng.randf_range(0.85, 1.0), 1.0, rng.randf_range(0.75, 0.9)))
        # reeds on the near shore edge and the far bank
        for r in 3:
            var pr: Vector3 = _pt(i, rng.randf_range(20.4, 21.8), 0.0)
            nature.add(6, Vector2(pr.x, pr.z), rng.randf_range(1.5, 2.4), rng.randf() * TAU, Color(0.78, 0.74, 0.42))
        var wk: float = _w_out(k)
        for r2 in 3:
            var pf: Vector3 = _pt(i, wk + rng.randf_range(-1.0, 3.5), 0.0)
            nature.add(6, Vector2(pf.x, pf.z), rng.randf_range(1.6, 2.6), rng.randf() * TAU, Color(0.68, 0.76, 0.4))
        if k % 2 == 0 and wk > 50.0:
            var pt: Vector3 = _pt(i, wk + rng.randf_range(5.0, 16.0), 0.0)
            var sp: int = 3 if rng.randf() < 0.5 else (0 if rng.randf() < 0.5 else 2)
            nature.add(sp, Vector2(pt.x, pt.z), rng.randf_range(1.0, 1.5), rng.randf() * TAU, Color(0.62, 0.82, 0.45))
        if k % 4 == 1:
            var pb: Vector3 = _pt(i, 12.6, 0.0)
            nature.add(5, Vector2(pb.x, pb.z), rng.randf_range(0.9, 1.3), rng.randf() * TAU, Color(1.0, 0.6, 0.75) if rng.randf() < 0.5 else Color(0.6, 0.8, 0.4))

func set_night(on: bool) -> void:
    for m in lamp_mats:
        (m as StandardMaterial3D).emission_energy_multiplier = 5.0 if on else 0.8

# alg: algiers.gd instance; nat: nature.gd instance (begin() already called); i_start..i_end: route index range
func build(alg, nat, i_start: int, i_end: int, s: float) -> void:
    algiers = alg
    nature = nat
    i0 = i_start
    i1 = i_end
    side = s
    cnt = i1 - i0 + 1
    name = "Waterfront"
    _build_surfaces()
    for k in range(2, cnt - 2, 3):
        _lamp(i0 + k, 13.2)
    for k in range(3, cnt - 3, 5):
        _bench(i0 + k)
    _pier(i0 + int(cnt / 2.0))
    _boat(i0 + int(cnt * 0.3), 30.0, Color(0.1, 0.2, 0.45), 0.15)
    _boat(i0 + int(cnt * 0.62), 36.0, Color(0.85, 0.2, 0.15), -0.1)
    _boat(i0 + int(cnt * 0.78), 28.0, Color(0.95, 0.95, 0.95), 0.05)
    _rocks()
    _vegetation()
