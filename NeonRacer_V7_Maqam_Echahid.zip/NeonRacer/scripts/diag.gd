extends RefCounted
## On-screen diagnostics: reads the last error lines from the game's own log file.

static func log_errors(max_lines: int = 5) -> String:
    var path := "user://logs/godot.log"
    if not FileAccess.file_exists(path):
        return ""
    var f := FileAccess.open(path, FileAccess.READ)
    if f == null:
        return ""
    var lines := f.get_as_text().split("\n")
    var out := PackedStringArray()
    for i in range(lines.size() - 1, -1, -1):
        var l: String = lines[i]
        if l.contains("ERROR") or l.contains("Parse Error") or l.contains("Invalid"):
            out.append(l.strip_edges().left(120))
            if out.size() >= max_lines:
                break
    out.reverse()
    return "\n".join(out)

# Full-screen dark message that stays on top (used for script/loading failures)
static func show_message(host: Node, text: String) -> void:
    var layer := CanvasLayer.new()
    layer.layer = 200
    host.add_child(layer)
    var bg := ColorRect.new()
    bg.color = Color(0.02, 0.03, 0.08, 0.96)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    layer.add_child(bg)
    var l := Label.new()
    l.set_anchors_preset(Control.PRESET_FULL_RECT)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.add_theme_font_size_override("font_size", 26)
    l.text = text
    layer.add_child(l)
