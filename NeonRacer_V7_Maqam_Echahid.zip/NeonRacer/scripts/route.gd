extends RefCounted
## One stage's centre line (a slice of the Algiers route, optionally reversed).
## Cars are placed by (s, d): s = metres along the line, d = metres to the right of the centre.

var pts: Array[Vector2] = []
var tng: Array[Vector2] = []
var nrm: Array[Vector2] = []     # right-hand normal
var cum: PackedFloat32Array = PackedFloat32Array()
var corner_v: PackedFloat32Array = PackedFloat32Array()   # max sensible speed per point (m/s)
var length := 0.0
var start_s := 0.0     # distance of the start line
var finish_s := 0.0    # distance of the finish line

# a -> b are indices into the full map route; the line is extended by `ext` points each side
# (clamped to the map) so there is real road behind the grid and after the finish.
func setup(all_pts: Array[Vector2], a: int, b: int, ext := 25) -> void:
    pts.clear()
    var dir := 1 if b >= a else -1
    var a2 := clampi(a - dir * ext, 0, all_pts.size() - 1)
    var b2 := clampi(b + dir * ext, 0, all_pts.size() - 1)
    for i in range(a2, b2 + dir, dir):
        pts.append(all_pts[i])
    var ia := absi(a - a2)
    var ib := ia + absi(b - a)
    var n := pts.size()
    cum.resize(n)
    cum[0] = 0.0
    for i in range(1, n):
        cum[i] = cum[i - 1] + pts[i].distance_to(pts[i - 1])
    length = cum[n - 1]
    start_s = cum[ia]
    finish_s = cum[ib]
    for i in n:
        var p0 := pts[maxi(i - 1, 0)]
        var p1 := pts[mini(i + 1, n - 1)]
        var t := (p1 - p0).normalized()
        tng.append(t)
        nrm.append(Vector2(-t.y, t.x))   # same convention as algiers.gd (kept so d>0 means "its +nrm side")
    _build_corner_speeds()

# curvature from heading change over ~40 m, then v = sqrt(a_lat / k)
func _build_corner_speeds() -> void:
    var n := pts.size()
    corner_v.resize(n)
    var win := 7
    for i in n:
        var i0 := maxi(i - win, 0)
        var i1 := mini(i + win, n - 1)
        var h0 := atan2(tng[i0].y, tng[i0].x)
        var h1 := atan2(tng[i1].y, tng[i1].x)
        var dh := absf(wrapf(h1 - h0, -PI, PI))
        var ds := maxf(cum[i1] - cum[i0], 1.0)
        var k := dh / ds
        var v := 200.0
        if k > 0.0005:
            v = sqrt(13.0 / k)
        corner_v[i] = clampf(v, 16.0, 200.0)

func _idx(s: float) -> int:
    # binary search for the last point with cum <= s
    var lo := 0
    var hi := pts.size() - 1
    while lo < hi:
        var mid := (lo + hi + 1) >> 1
        if cum[mid] <= s:
            lo = mid
        else:
            hi = mid - 1
    return lo

# centre point at distance s (extrapolated before the start / after the end)
func point_at(s: float) -> Vector2:
    if s <= 0.0:
        return pts[0] + tng[0] * s
    if s >= length:
        return pts[pts.size() - 1] + tng[pts.size() - 1] * (s - length)
    var i := mini(_idx(s), pts.size() - 2)
    var seg := maxf(cum[i + 1] - cum[i], 0.001)
    return pts[i].lerp(pts[i + 1], (s - cum[i]) / seg)

func tangent_at(s: float) -> Vector2:
    if s <= 0.0:
        return tng[0]
    if s >= length:
        return tng[pts.size() - 1]
    var i := mini(_idx(s), pts.size() - 2)
    var seg := maxf(cum[i + 1] - cum[i], 0.001)
    return tng[i].lerp(tng[i + 1], (s - cum[i]) / seg).normalized()

func normal_at(s: float) -> Vector2:
    var t := tangent_at(s)
    return Vector2(-t.y, t.x)

func corner_speed_at(s: float) -> float:
    return corner_v[clampi(_idx(clampf(s, 0.0, length)), 0, corner_v.size() - 1)]

# world position + yaw (Godot: car drives toward -Z at yaw 0) for (s, d)
func world_pos(s: float, d: float) -> Vector3:
    var p := point_at(s) + normal_at(s) * d
    return Vector3(p.x, 0.5, p.y)

func yaw_at(s: float) -> float:
    var t := tangent_at(s)
    return atan2(-t.x, -t.y)

# project a world position onto the line near a hint distance -> Vector2(s, d)
func project(p: Vector2, hint_s: float, back := 40.0, ahead := 80.0) -> Vector2:
    var i0 := maxi(_idx(clampf(hint_s - back, 0.0, length)), 0)
    var i1 := mini(_idx(clampf(hint_s + ahead, 0.0, length)) + 1, pts.size() - 2)
    var best_d2 := INF
    var best_s := hint_s
    var best_d := 0.0
    for i in range(i0, i1 + 1):
        var a := pts[i]
        var ab := pts[i + 1] - a
        var l2 := maxf(ab.length_squared(), 0.0001)
        var t := clampf((p - a).dot(ab) / l2, 0.0, 1.0)
        var q := a + ab * t
        var d2 := p.distance_squared_to(q)
        if d2 < best_d2:
            best_d2 = d2
            best_s = cum[i] + t * sqrt(l2)
            var nn := Vector2(-ab.y, ab.x).normalized()
            best_d = (p - q).dot(nn)
    return Vector2(best_s, best_d)
