extends Node3D
## Pool of dark road decals dropped behind the rear wheels while sliding or braking hard.
const POOL := 90
var meshes: Array = []
var idx := 0
var timer := 0.0

func _ready() -> void:
    var q := PlaneMesh.new()
    q.size = Vector2(0.28, 1.1)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.02, 0.02, 0.02, 0.5)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    for i in POOL * 2:
        var mi := MeshInstance3D.new()
        mi.mesh = q
        mi.material_override = mat
        mi.visible = false
        mi.top_level = true
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(mi)
        meshes.append(mi)

func update_marks(car: Node3D, on: bool, delta: float) -> void:
    if not on:
        timer = 0.0
        return
    timer -= delta
    if timer > 0.0:
        return
    timer = 0.04
    var yaw := car.global_rotation.y
    for side in [-1.0, 1.0]:
        var p: Vector3 = car.global_transform * Vector3(side * 0.85, 0.0, 1.3)
        var mi: MeshInstance3D = meshes[idx]
        idx = (idx + 1) % meshes.size()
        mi.global_position = Vector3(p.x, 0.075, p.z)
        mi.global_rotation = Vector3(0.0, yaw, 0.0)
        mi.visible = true
