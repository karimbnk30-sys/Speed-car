extends AnimatableBody3D
## Ambient traffic on the two-way road. dir = +1: same direction as the race, -1: oncoming.
const CarScript := preload("res://scripts/car.gd")

var route
var rs := 0.0
var rd := 0.0
var speed := 20.0          # signed along the route (negative = oncoming)
var dir := 1.0
var finished := false      # lets the AI avoidance code treat traffic like any other car
var wheels: Array = []
var wheel_spin := 0.0
var model: Node3D

func setup(idx: int, hue: float, r) -> void:
    route = r
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(1.9, 0.9, 4.2)
    cs.shape = bs
    cs.position.y = 0.2
    add_child(cs)
    var ps = load(CarScript.MODELS[idx % CarScript.MODELS.size()])
    if ps != null:
        model = ps.instantiate()
        model.rotation.y = -PI / 2.0
        model.scale = Vector3.ONE * CarScript.MODEL_SCALE
        model.position = Vector3(0, -0.236, 0)
        CarScript.tint_model(model, hue)
        add_child(model)
        for n in ["FL", "FR", "RL", "RR"]:
            var w = model.find_child(n, true, false)
            if w != null:
                wheels.append(w)
    # small emissive head / tail lights so the cars read at night and in the rain
    for sx in [-0.65, 0.65]:
        _light(Vector3(float(sx), 0.55, -2.1), Color(1.0, 0.95, 0.8))
        _light(Vector3(float(sx), 0.6, 2.1), Color(1.0, 0.1, 0.1))

func _light(pos: Vector3, col: Color) -> void:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(0.28, 0.14, 0.06)
    mi.mesh = bm
    var m := StandardMaterial3D.new()
    m.albedo_color = col
    m.emission_enabled = true
    m.emission = col
    m.emission_energy_multiplier = 2.5
    mi.material_override = m
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    mi.position = pos
    add_child(mi)

func place(s: float, d: float, v: float) -> void:
    rs = s
    rd = d
    dir = 1.0 if d > 0.0 else -1.0
    speed = v * dir
    _apply()

func _apply() -> void:
    var p: Vector3 = route.world_pos(rs, rd)
    global_position = Vector3(p.x, 0.5, p.z)
    rotation.y = route.yaw_at(rs) + (PI if dir < 0.0 else 0.0)

func _physics_process(delta: float) -> void:
    if route == null or not visible:
        return
    rs += speed * delta
    _apply()
    wheel_spin += absf(speed) / (0.25 * CarScript.MODEL_SCALE) * delta
    for w in wheels:
        (w as Node3D).rotation = Vector3(0.0, 0.0, wheel_spin)
