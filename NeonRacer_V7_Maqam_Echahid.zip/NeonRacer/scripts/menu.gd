extends Node
## Stage 1 main menu: only buttons that work (PLAY, EXIT). More entries arrive with their screens.
const ShowroomScript := preload("res://scripts/showroom.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const Tr := preload("res://scripts/tr.gd")

func _ready() -> void:
    Audio.play_music("music_menu")
    var sr := ShowroomScript.new()
    sr.model_index = int(Save.get_in("garage.selected", 0))
    sr.orbit_speed = 0.2
    add_child(sr)
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var ins := UIUtil.safe_insets(get_viewport())
    var title := UIUtil.make_label("NEON RACER", 72, Color(0.0, 0.95, 1.0))
    title.position = Vector2(ins.x, ins.y)
    root.add_child(title)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 18)
    col.set_anchors_preset(Control.PRESET_CENTER_LEFT)
    col.position = Vector2(ins.x, 0)
    col.grow_vertical = Control.GROW_DIRECTION_BOTH
    root.add_child(col)
    var play := UIUtil.make_button(Tr.t("PLAY"), Color(0.2, 1.0, 0.4))
    play.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/stage_select.tscn"))
    col.add_child(play)
    var garage := UIUtil.make_button(Tr.t("GARAGE"), Color(0.9, 0.3, 1.0))
    garage.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/garage.tscn"))
    col.add_child(garage)
    var settings := UIUtil.make_button(Tr.t("SETTINGS"), Color(1.0, 0.8, 0.2))
    settings.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/settings.tscn"))
    col.add_child(settings)
    var quit := UIUtil.make_button(Tr.t("EXIT"), Color(1.0, 0.3, 0.35))
    quit.pressed.connect(func():
        Save.save()
        get_tree().quit())
    col.add_child(quit)
    var st := UIUtil.make_label(_stats_text(), 26, Color.WHITE)
    st.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    st.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    st.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    st.grow_vertical = Control.GROW_DIRECTION_BEGIN
    st.position = Vector2(-ins.z, -ins.w)
    root.add_child(st)

func _stats_text() -> String:
    var fmt := Tr.t("RACES WON") + "  %d\n" + Tr.t("TOP SPEED") + "  %d km/h\n" + Tr.t("TOTAL DISTANCE") + "  %.1f km\n" + Tr.t("MONEY") + "  %d"
    return fmt % [
        int(float(Save.get_in("stats.wins", 0.0))),
        int(float(Save.get_in("stats.best_speed", 0.0))),
        float(Save.get_in("stats.total_distance", 0.0)) / 1000.0,
        int(Save.get_in("profile.money", 0))]
