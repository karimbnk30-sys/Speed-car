extends Node3D
## Road furniture: curved street lamps, speed-limit and chevron signs, zebra crossings,
## checkpoint gates and start-grid paint. Everything repeated is chunked MultiMesh.
const TexGen := preload("res://scripts/texgen.gd")
const TW := 7.0
const CHUNK := 600.0

var algiers
var lamp_mat: StandardMaterial3D
var checkpoint_mats: Array = []

func _chunk_mm(mesh: Mesh, xfs: Array, vis: float, shadow: bool, mat: Material = null) -> void:
    var cells := {}
    for xf in xfs:
        var t: Transform3D = xf
        var key := Vector2i(int(floorf(t.origin.x / CHUNK)), int(floorf(t.origin.z / CHUNK)))
        if not cells.has(key):
            cells[key] = []
        cells[key].append(t)
    for key in cells:
        var kk: Vector2i = key
        var list: Array = cells[kk]
        var origin := Vector3((float(kk.x) + 0.5) * CHUNK, 0.0, (float(kk.y) + 0.5) * CHUNK)
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        mm.mesh = mesh
        mm.instance_count = list.size()
        for k in list.size():
            var t2: Transform3D = list[k]
            t2.origin -= origin
            mm.set_instance_transform(k, t2)
        var mi := MultiMeshInstance3D.new()
        mi.multimesh = mm
        mi.position = origin
        mi.visibility_range_end = vis
        if mat != null:
            mi.material_override = mat
        if not shadow:
            mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(mi)

func _std(c: Color, rough: float, metal: float) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    m.metallic = metal
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    return m

func _tangent(i: int) -> Vector2:
    return (algiers.pts[i + 1] - algiers.pts[i - 1]).normalized()

# ---------------------------------------------------------------- street lamps
func _lamp_mesh() -> ArrayMesh:
    var pole := CylinderMesh.new()
    pole.top_radius = 0.06
    pole.bottom_radius = 0.1
    pole.height = 7.6
    pole.radial_segments = 6
    pole.rings = 1
    var box := BoxMesh.new()
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    st.append_from(pole, 0, Transform3D(Basis.IDENTITY, Vector3(0, 3.8, 0)))
    box.size = Vector3(0.1, 0.1, 2.4)
    st.append_from(box, 0, Transform3D(Basis.IDENTITY, Vector3(0, 7.55, -1.1)))
    box.size = Vector3(0.18, 0.5, 0.18)
    st.append_from(box, 0, Transform3D(Basis.IDENTITY, Vector3(0, 7.3, 0)))
    var head_st := SurfaceTool.new()
    head_st.begin(Mesh.PRIMITIVE_TRIANGLES)
    box.size = Vector3(0.55, 0.14, 0.95)
    head_st.append_from(box, 0, Transform3D(Basis.IDENTITY, Vector3(0, 7.45, -2.15)))
    var mesh := ArrayMesh.new()
    st.commit(mesh)
    mesh.surface_set_material(0, _std(Color(0.2, 0.21, 0.24), 0.45, 0.6))
    head_st.commit(mesh)
    lamp_mat = _std(Color(1.0, 0.9, 0.65), 0.4, 0.0)
    lamp_mat.emission_enabled = true
    lamp_mat.emission = Color(1.0, 0.86, 0.55)
    lamp_mat.emission_energy_multiplier = 1.0
    mesh.surface_set_material(1, lamp_mat)
    return mesh

func _lamps() -> void:
    var n: int = algiers.pts.size()
    var xfs: Array = []
    var side: float = 1.0
    for i in range(6, n - 6, 7):
        side = -side
        var p: Vector2 = algiers.pts[i]
        if algiers.wadi_on and algiers.in_wadi(p, 4.0):
            continue
        var t: Vector2 = _tangent(i)
        var nrm := Vector2(-t.y, t.x)
        var pos: Vector2 = p + nrm * side * (TW + 1.1)
        var yaw: float = atan2(-t.y, t.x) + (PI if side < 0.0 else 0.0)
        xfs.append(Transform3D(Basis(Vector3.UP, yaw), Vector3(pos.x, 0.14, pos.y)))
    _chunk_mm(_lamp_mesh(), xfs, 520.0, false)

# ---------------------------------------------------------------- signs
func _panel_mesh(tex: Texture2D, size: float, pole_h: float) -> ArrayMesh:
    var q := QuadMesh.new()
    q.size = Vector2(size, size)
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    st.append_from(q, 0, Transform3D(Basis.IDENTITY, Vector3(0, pole_h, 0)))
    var box := BoxMesh.new()
    box.size = Vector3(0.1, pole_h, 0.1)
    var pst := SurfaceTool.new()
    pst.begin(Mesh.PRIMITIVE_TRIANGLES)
    pst.append_from(box, 0, Transform3D(Basis.IDENTITY, Vector3(0, pole_h * 0.5, -0.06)))
    var mesh := ArrayMesh.new()
    st.commit(mesh)
    var pm := StandardMaterial3D.new()
    pm.albedo_texture = tex
    pm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
    pm.alpha_scissor_threshold = 0.5
    pm.cull_mode = BaseMaterial3D.CULL_DISABLED
    pm.roughness = 0.5
    mesh.surface_set_material(0, pm)
    pst.commit(mesh)
    mesh.surface_set_material(1, _std(Color(0.5, 0.52, 0.56), 0.5, 0.6))
    return mesh

func _signs() -> void:
    var n: int = algiers.pts.size()
    # speed limits every ~540 m, alternating sides and values
    var limits: Array = [50, 70, 90]
    var groups := {}
    for k in 3:
        groups[k] = []
    var cnt: int = 0
    for i in range(30, n - 30, 90):
        var p: Vector2 = algiers.pts[i]
        if algiers.wadi_on and algiers.in_wadi(p, 20.0):
            continue
        if algiers.in_water_zone(p, 6.0):
            continue
        var t: Vector2 = _tangent(i)
        var nrm := Vector2(-t.y, t.x)
        var pos: Vector2 = p + nrm * (TW + 1.9)
        var yaw: float = atan2(-t.x, -t.y)
        groups[cnt % 3].append(Transform3D(Basis(Vector3.UP, yaw), Vector3(pos.x, 0.14, pos.y)))
        cnt += 1
    for k in 3:
        _chunk_mm(_panel_mesh(TexGen.speed_sign(int(limits[k])), 1.2, 2.5), groups[k], 600.0, false)
    # chevron boards on the outside of every bend
    var right_xfs: Array = []
    var left_xfs: Array = []
    for i in range(6, n - 6, 2):
        var ta: Vector2 = (algiers.pts[i] - algiers.pts[i - 5]).normalized()
        var tb: Vector2 = (algiers.pts[i + 5] - algiers.pts[i]).normalized()
        var turn: float = ta.x * tb.y - ta.y * tb.x       # + = bends toward +normal (right)
        if absf(turn) < 0.22:
            continue
        var p2: Vector2 = algiers.pts[i]
        if algiers.wadi_on and algiers.in_wadi(p2, 12.0):
            continue
        if algiers.in_water_zone(p2, 6.0):
            continue
        var t2: Vector2 = _tangent(i)
        var nrm2 := Vector2(-t2.y, t2.x)
        var outer: float = -signf(turn)
        var pos2: Vector2 = p2 + nrm2 * outer * (TW + 1.9)
        var yaw2: float = atan2(-t2.x, -t2.y)
        var xf := Transform3D(Basis(Vector3.UP, yaw2), Vector3(pos2.x, 0.14, pos2.y))
        if turn > 0.0:
            right_xfs.append(xf)
        else:
            var mirrored := Transform3D(Basis(Vector3.UP, yaw2).scaled(Vector3(-1, 1, 1)), xf.origin)
            left_xfs.append(mirrored)
    var chev: ImageTexture = TexGen.chevron_sign()
    _chunk_mm(_panel_mesh(chev, 1.3, 1.8), right_xfs, 420.0, false)
    _chunk_mm(_panel_mesh(chev, 1.3, 1.8), left_xfs, 420.0, false)

# ---------------------------------------------------------------- zebra crossings
func _crossings() -> void:
    var n: int = algiers.pts.size()
    var stripe := BoxMesh.new()
    stripe.size = Vector3(3.0, 0.02, 0.5)
    var xfs: Array = []
    for i in range(40, n - 40, 70):
        var p: Vector2 = algiers.pts[i]
        if algiers.wadi_on and algiers.in_wadi(p, 30.0):
            continue
        if algiers.in_water_zone(p, 6.0):
            continue
        var ta: Vector2 = (algiers.pts[i] - algiers.pts[i - 4]).normalized()
        var tb: Vector2 = (algiers.pts[i + 4] - algiers.pts[i]).normalized()
        if absf(ta.x * tb.y - ta.y * tb.x) > 0.05:
            continue
        var t: Vector2 = _tangent(i)
        var nrm := Vector2(-t.y, t.x)
        var yaw: float = atan2(-t.y, t.x)
        for k in range(-6, 7):
            var q: Vector2 = p + nrm * (float(k) + 0.0) * 0.98
            if absf(float(k)) < 1.0:
                continue
            xfs.append(Transform3D(Basis(Vector3.UP, yaw), Vector3(q.x, 0.062, q.y)))
    var mat := _std(Color(0.95, 0.95, 0.92), 0.8, 0.0)
    _chunk_mm(stripe, xfs, 300.0, false, mat)

# ---------------------------------------------------------------- checkpoint gate + start grid
func add_checkpoint(center: Vector2, tangent: Vector2, label: String) -> void:
    var root := Node3D.new()
    root.position = Vector3(center.x, 0.0, center.y)
    root.basis = Basis.looking_at(Vector3(tangent.x, 0.0, tangent.y), Vector3.UP)
    add_child(root)
    var half: float = TW + 1.0
    var dark := _std(Color(0.12, 0.13, 0.16), 0.5, 0.5)
    var glow := StandardMaterial3D.new()
    glow.albedo_color = Color(0.1, 0.9, 1.0)
    glow.emission_enabled = true
    glow.emission = Color(0.1, 0.9, 1.0)
    glow.emission_energy_multiplier = 3.0
    glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    checkpoint_mats.append(glow)
    for sx in [-1.0, 1.0]:
        var pm := MeshInstance3D.new()
        var bx := BoxMesh.new()
        bx.size = Vector3(0.6, 6.5, 0.6)
        pm.mesh = bx
        pm.material_override = dark
        pm.position = Vector3(float(sx) * half, 3.25, 0.0)
        root.add_child(pm)
        var strip := MeshInstance3D.new()
        var sb := BoxMesh.new()
        sb.size = Vector3(0.12, 6.3, 0.12)
        strip.mesh = sb
        strip.material_override = glow
        strip.position = Vector3(float(sx) * (half - 0.36), 3.25, 0.34)
        strip.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        root.add_child(strip)
    var beam := MeshInstance3D.new()
    var bb := BoxMesh.new()
    bb.size = Vector3(half * 2.0 + 0.6, 0.7, 0.7)
    beam.mesh = bb
    beam.material_override = dark
    beam.position = Vector3(0.0, 6.6, 0.0)
    root.add_child(beam)
    var bar := MeshInstance3D.new()
    var bar_b := BoxMesh.new()
    bar_b.size = Vector3(half * 2.0, 0.14, 0.14)
    bar.mesh = bar_b
    bar.material_override = glow
    bar.position = Vector3(0.0, 6.6, 0.38)
    bar.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(bar)
    for side in [1.0, -1.0]:
        var lb := Label3D.new()
        lb.text = label
        lb.font_size = 72
        lb.pixel_size = 0.012
        lb.modulate = Color(0.3, 0.95, 1.0)
        lb.outline_modulate = Color(0, 0, 0, 1)
        lb.outline_size = 14
        lb.position = Vector3(0.0, 7.7, float(side) * 0.5)
        lb.rotation.y = 0.0 if float(side) > 0.0 else PI
        root.add_child(lb)

# one painted start slot (front bar + side ticks); pos on the road, yaw = car heading
func add_grid_slot(pos: Vector3, yaw: float) -> void:
    var root := Node3D.new()
    root.position = Vector3(pos.x, 0.07, pos.z)
    root.rotation.y = yaw
    add_child(root)
    var mat := _std(Color(0.95, 0.95, 0.92), 0.8, 0.0)
    for part in [[Vector3(2.4, 0.02, 0.16), Vector3(0, 0, -2.6)], [Vector3(0.16, 0.02, 1.2), Vector3(-1.2, 0, -2.0)], [Vector3(0.16, 0.02, 1.2), Vector3(1.2, 0, -2.0)]]:
        var mi := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = part[0]
        mi.mesh = bm
        mi.material_override = mat
        mi.position = part[1]
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        root.add_child(mi)

func set_night(on: bool) -> void:
    if lamp_mat != null:
        lamp_mat.emission_energy_multiplier = 6.0 if on else 0.8

func build(alg) -> void:
    algiers = alg
    name = "Roadside"
    _lamps()
    _signs()
    _crossings()
