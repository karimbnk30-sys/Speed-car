extends RefCounted
## Procedural textures: asphalt with road markings, facade tiles, vegetation, signs.

static func _stamp(dst: Image, rect: Rect2i, c: Color) -> void:
    var ov := Image.create(rect.size.x, rect.size.y, false, Image.FORMAT_RGBA8)
    ov.fill(c)
    dst.blend_rect(ov, Rect2i(0, 0, rect.size.x, rect.size.y), rect.position)

static func _tex(img: Image) -> ImageTexture:
    img.generate_mipmaps()
    return ImageTexture.create_from_image(img)

# 14 m wide x 14 m long tile: asphalt + wheel tracks + lane markings. u = across the road, v = along it.
static func road() -> ImageTexture:
    var w: int = 256
    var h: int = 512
    var noise := FastNoiseLite.new()
    noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    noise.frequency = 0.09
    noise.fractal_octaves = 3
    var img: Image = noise.get_seamless_image(w, h)
    img.convert(Image.FORMAT_RGBA8)
    _stamp(img, Rect2i(0, 0, w, h), Color(0.09, 0.09, 0.1, 0.78))
    var rng := RandomNumberGenerator.new()
    rng.seed = 5
    for k in 3200:
        var g: float = rng.randf_range(0.12, 0.42)
        img.set_pixel(rng.randi_range(0, w - 1), rng.randi_range(0, h - 1), Color(g, g, g * 1.03, 1.0))
    # polished wheel tracks in every lane
    for lane_c in [-5.0, -1.9, 1.9, 5.0]:
        for off in [-0.8, 0.8]:
            var x0: int = _px(float(lane_c) + float(off) - 0.28, w)
            var x1: int = _px(float(lane_c) + float(off) + 0.28, w)
            _stamp(img, Rect2i(x0, 0, x1 - x0, h), Color(0.02, 0.02, 0.02, 0.2))
    var white := Color(0.93, 0.93, 0.9, 0.95)
    var yellow := Color(0.96, 0.78, 0.1, 0.96)
    # edge lines
    for s in [-1.0, 1.0]:
        var a: int = _px(float(s) * 6.45 - 0.1, w)
        var b: int = _px(float(s) * 6.45 + 0.1, w)
        _stamp(img, Rect2i(a, 0, b - a, h), white)
    # solid double yellow centre line
    _stamp(img, Rect2i(_px(-0.34, w), 0, _px(-0.16, w) - _px(-0.34, w), h), yellow)
    _stamp(img, Rect2i(_px(0.16, w), 0, _px(0.34, w) - _px(0.16, w), h), yellow)
    # dashed lane dividers: 3 m dash every 7 m
    for s in [-1.0, 1.0]:
        var a2: int = _px(float(s) * 3.5 - 0.1, w)
        var b2: int = _px(float(s) * 3.5 + 0.1, w)
        for dash in 2:
            var y0: int = int(float(dash) * 256.0)
            _stamp(img, Rect2i(a2, y0, b2 - a2, 110), white)
    return _tex(img)

static func _px(d: float, w: int) -> int:
    return clampi(int(round((d + 7.0) / 14.0 * float(w))), 0, w - 1)

# 256x256 tile = 4 bays x 4 floors. kind: 0 curtain glass, 1 stone + punched windows, 2 plaster, 3 metal panels.
# Returns {"albedo": tex, "emission": tex}
static func window_tile(kind: int, seed_value: int) -> Dictionary:
    var size: int = 256
    var cell: int = 64
    var alb := Image.create(size, size, false, Image.FORMAT_RGBA8)
    var emi := Image.create(size, size, false, Image.FORMAT_RGBA8)
    emi.fill(Color(0, 0, 0, 1))
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    var wall: Color = Color(0.84, 0.79, 0.7)
    if kind == 2:
        wall = Color(0.94, 0.92, 0.87)
    elif kind == 3:
        wall = Color(0.3, 0.32, 0.35)
    elif kind == 0:
        wall = Color(0.16, 0.18, 0.21)
    alb.fill(wall)
    if kind == 1:
        for y in range(0, size, 16):    # stone course joints
            alb.fill_rect(Rect2i(0, y, size, 1), wall.darkened(0.18))
    for k in 1400:
        var v: float = rng.randf_range(-0.05, 0.05)
        alb.set_pixel(rng.randi_range(0, size - 1), rng.randi_range(0, size - 1), Color(clampf(wall.r + v, 0.0, 1.0), clampf(wall.g + v, 0.0, 1.0), clampf(wall.b + v, 0.0, 1.0), 1.0))
    for cy in 4:
        for cx in 4:
            var ox: int = cx * cell
            var oy: int = cy * cell
            var r: Rect2i
            var frame: Color = Color(0.1, 0.11, 0.13)
            if kind == 0:
                r = Rect2i(ox + 2, oy + 2, cell - 4, cell - 22)       # glass above an opaque spandrel
                frame = Color(0.08, 0.09, 0.11)
            elif kind == 3:
                r = Rect2i(ox + 4, oy + 14, cell - 8, 30)              # ribbon window
            elif kind == 2:
                r = Rect2i(ox + 12, oy + 10, cell - 24, cell - 26)
                frame = Color(0.35, 0.35, 0.36)
            else:
                r = Rect2i(ox + 14, oy + 9, cell - 28, cell - 24)
                frame = Color(0.96, 0.95, 0.92)
            alb.fill_rect(Rect2i(r.position.x - 2, r.position.y - 2, r.size.x + 4, r.size.y + 4), frame)
            var tone: float = rng.randf_range(0.0, 1.0)
            var glass: Color = Color(0.17 + tone * 0.06, 0.28 + tone * 0.08, 0.38 + tone * 0.1)
            if kind == 0:
                glass = Color(0.2 + tone * 0.08, 0.36 + tone * 0.1, 0.46 + tone * 0.12)
            alb.fill_rect(r, glass)
            # sky reflection streak
            alb.fill_rect(Rect2i(r.position.x + 3, r.position.y + 2, 3, r.size.y - 4), glass.lightened(0.18))
            if kind == 1:
                alb.fill_rect(Rect2i(r.position.x - 4, r.position.y + r.size.y + 2, r.size.x + 8, 3), Color(0.95, 0.94, 0.9))   # sill
            if rng.randf() < 0.32:
                var warm: bool = rng.randf() < 0.75
                var lit: Color = Color(1.0, 0.82, 0.5) if warm else Color(0.7, 0.86, 1.0)
                emi.fill_rect(r, lit.darkened(rng.randf_range(0.0, 0.35)))
    return {"albedo": _tex(alb), "emission": _tex(emi)}

static func leaf_noise() -> ImageTexture:
    var noise := FastNoiseLite.new()
    noise.noise_type = FastNoiseLite.TYPE_CELLULAR
    noise.frequency = 0.09
    var img: Image = noise.get_seamless_image(128, 128)
    img.convert(Image.FORMAT_RGBA8)
    _stamp(img, Rect2i(0, 0, 128, 128), Color(0.8, 0.8, 0.8, 0.55))
    return _tex(img)

static func _line(img: Image, x0: float, y0: float, x1: float, y1: float, c: Color, thick: int) -> void:
    var steps: int = int(maxf(absf(x1 - x0), absf(y1 - y0))) + 1
    for s in steps + 1:
        var t: float = float(s) / float(steps)
        var x: int = int(lerpf(x0, x1, t))
        var y: int = int(lerpf(y0, y1, t))
        for ox in thick:
            for oy in thick:
                var px: int = x + ox
                var py: int = y + oy
                if px >= 0 and py >= 0 and px < img.get_width() and py < img.get_height():
                    img.set_pixel(px, py, c)

# palm frond: rib up the middle, leaflets drooping to both sides. Alpha cut-out.
static func frond() -> ImageTexture:
    var w: int = 128
    var h: int = 256
    var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    _line(img, 64.0, 250.0, 64.0, 6.0, Color(0.3, 0.42, 0.16, 1.0), 2)
    var rng := RandomNumberGenerator.new()
    rng.seed = 21
    for k in 52:
        var y: float = 244.0 - float(k) * 4.4
        var reach: float = 58.0 * sin(clampf((250.0 - y) / 250.0, 0.0, 1.0) * PI * 0.9 + 0.35)
        reach = clampf(reach, 10.0, 60.0)
        var shade: float = rng.randf_range(0.0, 0.12)
        var col: Color = Color(0.13 + shade, 0.38 + shade, 0.1, 1.0)
        for side in [-1.0, 1.0]:
            _line(img, 64.0, y, 64.0 + float(side) * reach, y + reach * 0.55, col, 2)
    return _tex(img)

static func grass_tuft() -> ImageTexture:
    var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    var rng := RandomNumberGenerator.new()
    rng.seed = 8
    for k in 16:
        var x0: float = 32.0 + rng.randf_range(-10.0, 10.0)
        var x1: float = x0 + rng.randf_range(-16.0, 16.0)
        var y1: float = rng.randf_range(8.0, 40.0)
        var g: float = rng.randf_range(0.0, 0.18)
        _line(img, x0, 62.0, x1, y1, Color(0.42 + g, 0.6 + g, 0.18, 1.0), 2)
    return _tex(img)

static func sand() -> ImageTexture:
    var noise := FastNoiseLite.new()
    noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    noise.frequency = 0.12
    var img: Image = noise.get_seamless_image(128, 128)
    img.convert(Image.FORMAT_RGBA8)
    _stamp(img, Rect2i(0, 0, 128, 128), Color(0.82, 0.72, 0.52, 0.8))
    return _tex(img)

static func rock() -> ImageTexture:
    var noise := FastNoiseLite.new()
    noise.noise_type = FastNoiseLite.TYPE_CELLULAR
    noise.frequency = 0.05
    var img: Image = noise.get_seamless_image(128, 128)
    img.convert(Image.FORMAT_RGBA8)
    _stamp(img, Rect2i(0, 0, 128, 128), Color(0.4, 0.38, 0.35, 0.65))
    return _tex(img)

# ---------- road signs (128x128) ----------
const SEG := {
    0: [1, 1, 1, 0, 1, 1, 1], 1: [0, 1, 1, 0, 0, 0, 0], 2: [1, 1, 0, 1, 1, 0, 1], 3: [1, 1, 1, 1, 0, 0, 1],
    4: [0, 1, 1, 0, 0, 1, 1], 5: [1, 0, 1, 1, 0, 1, 1], 6: [1, 0, 1, 1, 1, 1, 1], 7: [1, 1, 1, 0, 0, 0, 0],
    8: [1, 1, 1, 1, 1, 1, 1], 9: [1, 1, 1, 1, 0, 1, 1]}

static func _digit(img: Image, ox: int, oy: int, n: int) -> void:
    var seg: Array = SEG[n]
    var t: int = 6
    var w: int = 24
    var h: int = 44
    var rects: Array = [
        Rect2i(ox, oy, w, t), Rect2i(ox + w - t, oy, t, h / 2 + t / 2), Rect2i(ox + w - t, oy + h / 2, t, h / 2 + t / 2),
        Rect2i(ox, oy + h, w, t), Rect2i(ox, oy + h / 2, t, h / 2 + t / 2), Rect2i(ox, oy, t, h / 2 + t / 2),
        Rect2i(ox, oy + h / 2, w, t)]
    for k in 7:
        if int(seg[k]) == 1:
            img.fill_rect(rects[k], Color(0.05, 0.05, 0.05, 1.0))

static func speed_sign(limit: int) -> ImageTexture:
    var s: int = 128
    var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    for y in s:
        for x in s:
            var d: float = Vector2(float(x) - 63.5, float(y) - 63.5).length()
            if d < 62.0:
                img.set_pixel(x, y, Color(0.85, 0.05, 0.05, 1.0) if d > 48.0 else Color(0.97, 0.97, 0.97, 1.0))
    var tens: int = (limit / 10) % 10
    var ones: int = limit % 10
    _digit(img, 33, 40, tens)
    _digit(img, 71, 40, ones)
    return _tex(img)

static func chevron_sign() -> ImageTexture:
    var s: int = 128
    var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
    img.fill(Color(0.08, 0.08, 0.08, 1.0))
    img.fill_rect(Rect2i(6, 6, s - 12, s - 12), Color(1.0, 0.8, 0.05, 1.0))
    for y in range(12, s - 12):
        var k: float = absf(float(y) - 63.5)
        for off in [26.0, 62.0]:
            var xa: int = int(float(off) + k * 0.55)
            for t in 14:
                if xa + t < s - 12:
                    img.set_pixel(xa + t, y, Color(0.06, 0.06, 0.06, 1.0))
    return _tex(img)

static func zebra_dummy() -> int:
    return 0
