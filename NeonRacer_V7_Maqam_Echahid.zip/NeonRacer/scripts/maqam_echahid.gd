extends Node3D
## Maqam Echahid landmark zone, placed into the existing Algiers route.
## Geometry is deliberately independent from vehicle/race systems.

const MEMORIAL_ROUTE_INDEX := 950
const MEMORIAL_OFFSET := 100.0

var stone: StandardMaterial3D
var pale_stone: StandardMaterial3D
var dark_stone: StandardMaterial3D
var asphalt: StandardMaterial3D
var grass: StandardMaterial3D
var palm_green: StandardMaterial3D
var trunk_mat: StandardMaterial3D
var white: StandardMaterial3D
var green: StandardMaterial3D
var red: StandardMaterial3D
var lamp_mat: StandardMaterial3D

func build(alg, center: Vector2, road_point: Vector2) -> void:
    _materials()
    var tangent := (alg.pts[MEMORIAL_ROUTE_INDEX + 1] - alg.pts[MEMORIAL_ROUTE_INDEX - 1]).normalized()
    var toward_road := road_point - center
    rotation.y = atan2(toward_road.x, toward_road.y)
    position = Vector3(center.x, 0.0, center.y)
    name = "Maqam_Echahid_Algiers"
    _build_access_road(road_point)
    _build_plaza()
    _build_memorial()
    _build_gardens()
    _build_flag()
    _build_lighting()

func _materials() -> void:
    stone = _mat(Color(0.68, 0.63, 0.54), 0.88)
    pale_stone = _mat(Color(0.79, 0.74, 0.65), 0.82)
    dark_stone = _mat(Color(0.30, 0.29, 0.27), 0.9)
    asphalt = _mat(Color(0.075, 0.085, 0.095), 0.96)
    grass = _mat(Color(0.17, 0.30, 0.12), 0.98)
    palm_green = _mat(Color(0.10, 0.26, 0.08), 0.9)
    trunk_mat = _mat(Color(0.35, 0.24, 0.14), 0.95)
    white = _mat(Color(0.92, 0.90, 0.83), 0.75)
    green = _mat(Color(0.0, 0.38, 0.20), 0.8)
    red = _mat(Color(0.82, 0.06, 0.12), 0.6)
    lamp_mat = StandardMaterial3D.new()
    lamp_mat.albedo_color = Color(1.0, 0.78, 0.42)
    lamp_mat.emission_enabled = true
    lamp_mat.emission = Color(1.0, 0.62, 0.24)
    lamp_mat.emission_energy_multiplier = 1.2
    lamp_mat.roughness = 0.3

func _mat(c: Color, rough: float) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    return m

func _box(parent: Node3D, name_text: String, pos: Vector3, size: Vector3, material: Material, yaw := 0.0) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.name = name_text
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = material
    mi.position = pos
    mi.rotation.y = yaw
    mi.cast_shadow = true
    mi.gi_mode = GeometryInstance3D.GI_MODE_DISABLED
    parent.add_child(mi)
    return mi

func _cylinder(parent: Node3D, name_text: String, pos: Vector3, radius: float, height: float, material: Material, sides := 20) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.name = name_text
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = height
    cm.radial_segments = sides
    mi.mesh = cm
    mi.material_override = material
    mi.position = pos
    parent.add_child(mi)
    return mi

func _build_access_road(road_point: Vector2) -> void:
    # A short access boulevard joins the existing race route; the race route itself is untouched.
    var local_road := to_local(Vector3(road_point.x, 0.0, road_point.y))
    var path: Array[Vector3] = [
        Vector3(0.0, 0.08, 57.0),
        Vector3(0.0, 0.08, 35.0),
        Vector3(local_road.x * 0.55, 0.08, lerpf(35.0, local_road.z, 0.55)),
        Vector3(local_road.x, 0.08, local_road.z)
    ]
    for i in range(path.size() - 1):
        var a := path[i]
        var b := path[i + 1]
        var delta := b - a
        var length := Vector2(delta.x, delta.z).length()
        var yaw := atan2(delta.x, delta.z)
        _box(self, "Memorial_Access_Asphalt", (a + b) * 0.5, Vector3(14.0, 0.18, length + 1.0), asphalt, yaw)
        for side in [-1.0, 1.0]:
            var edge_pos := (a + b) * 0.5 + Vector3(cos(yaw) * side * 7.4, 0.18, -sin(yaw) * side * 7.4)
            _box(self, "Access_Road_Kerb", edge_pos, Vector3(0.45, 0.35, length), pale_stone, yaw)
    # painted lane separators
    for z in range(25, 54, 8):
        _box(self, "Access_Road_Marking", Vector3(0.0, 0.19, float(z)), Vector3(0.18, 0.035, 3.5), white)

func _build_plaza() -> void:
    _box(self, "Memorial_Paved_Podium", Vector3(0.0, 0.15, 0.0), Vector3(116.0, 0.3, 112.0), pale_stone)
    _box(self, "Memorial_Upper_Podium", Vector3(0.0, 0.55, 0.0), Vector3(48.0, 0.65, 43.0), stone)
    # broad forecourt steps and paving bands
    for i in range(7):
        var w := 34.0 + float(i) * 3.0
        _box(self, "Monument_Entrance_Step", Vector3(0.0, 0.24 + float(i) * 0.13, 27.0 + float(i) * 2.1), Vector3(w, 0.28, 2.0), pale_stone)
    for x in [-43.0, 43.0]:
        _box(self, "Plaza_Garden_Bed", Vector3(x, 0.32, -2.0), Vector3(18.0, 0.35, 66.0), grass)
    for z in [-45.0, 46.0]:
        _box(self, "Plaza_Paving_Band", Vector3(0.0, 0.34, z), Vector3(82.0, 0.12, 1.2), stone)

func _blade_mesh(angle: float) -> ArrayMesh:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var radial := Vector2(sin(angle), cos(angle))
    var tangent := Vector2(cos(angle), -sin(angle))
    var segments := 22
    var depth := 2.6
    for i in range(segments):
        var t0 := float(i) / float(segments)
        var t1 := float(i + 1) / float(segments)
        var r0 := lerpf(25.0, 2.6, pow(t0, 0.82))
        var r1 := lerpf(25.0, 2.6, pow(t1, 0.82))
        var w0 := lerpf(18.0, 7.2, t0)
        var w1 := lerpf(18.0, 7.2, t1)
        var y0 := 4.0 + t0 * 88.0
        var y1 := 4.0 + t1 * 88.0
        var f0l := radial * (r0 + depth * 0.5) + tangent * (-w0 * 0.5)
        var f0r := radial * (r0 + depth * 0.5) + tangent * (w0 * 0.5)
        var f1l := radial * (r1 + depth * 0.5) + tangent * (-w1 * 0.5)
        var f1r := radial * (r1 + depth * 0.5) + tangent * (w1 * 0.5)
        var b0l := radial * (r0 - depth * 0.5) + tangent * (-w0 * 0.5)
        var b0r := radial * (r0 - depth * 0.5) + tangent * (w0 * 0.5)
        var b1l := radial * (r1 - depth * 0.5) + tangent * (-w1 * 0.5)
        var b1r := radial * (r1 - depth * 0.5) + tangent * (w1 * 0.5)
        _quad(st, Vector3(f0l.x,y0,f0l.y), Vector3(f0r.x,y0,f0r.y), Vector3(f1r.x,y1,f1r.y), Vector3(f1l.x,y1,f1l.y))
        _quad(st, Vector3(b0r.x,y0,b0r.y), Vector3(b0l.x,y0,b0l.y), Vector3(b1l.x,y1,b1l.y), Vector3(b1r.x,y1,b1r.y))
        _quad(st, Vector3(f0l.x,y0,f0l.y), Vector3(f1l.x,y1,f1l.y), Vector3(b1l.x,y1,b1l.y), Vector3(b0l.x,y0,b0l.y))
        _quad(st, Vector3(f1r.x,y1,f1r.y), Vector3(f0r.x,y0,f0r.y), Vector3(b0r.x,y0,b0r.y), Vector3(b1r.x,y1,b1r.y))
    st.generate_normals()
    return st.commit()

func _quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3) -> void:
    st.add_vertex(a); st.add_vertex(b); st.add_vertex(c)
    st.add_vertex(a); st.add_vertex(c); st.add_vertex(d)

func _build_memorial() -> void:
    # Authentic three-wing silhouette, with each wing sweeping inward toward the crown.
    _box(self, "Memorial_Foundation", Vector3(0.0, 1.35, 0.0), Vector3(34.0, 2.7, 32.0), stone)
    _box(self, "Memorial_Upper_Foundation", Vector3(0.0, 3.0, 0.0), Vector3(25.0, 0.8, 24.0), pale_stone)
    for i in range(3):
        var wing := MeshInstance3D.new()
        wing.name = "Maqam_Three_Sweeping_Pillars_%d" % (i + 1)
        wing.mesh = _blade_mesh(float(i) * TAU / 3.0)
        wing.material_override = stone
        wing.cast_shadow = true
        add_child(wing)
    _cylinder(self, "Central_Memorial_Core", Vector3(0.0, 35.0, 0.0), 2.4, 66.0, pale_stone, 24)
    _cylinder(self, "Crown_Ring", Vector3(0.0, 90.0, 0.0), 3.2, 1.2, dark_stone, 24)
    _cylinder(self, "Memorial_Antenna", Vector3(0.0, 94.0, 0.0), 0.16, 7.0, dark_stone, 10)
    # Dark inset at the base gives the lower central opening more depth.
    _box(self, "Memorial_Entrance_Shadow", Vector3(0.0, 5.0, 11.8), Vector3(8.0, 5.0, 0.3), dark_stone)

func _build_gardens() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 1962
    for side in [-1.0, 1.0]:
        for i in range(7):
            var z := -38.0 + float(i) * 12.0
            _palm(Vector3(side * rng.randf_range(36.0, 48.0), 0.0, z), rng)
        for i in range(10):
            var x := side * rng.randf_range(30.0, 53.0)
            var z2 := rng.randf_range(-43.0, 42.0)
            _cylinder(self, "Landscaped_Shrub", Vector3(x, 0.85, z2), rng.randf_range(0.55, 1.0), 1.7, palm_green, 12)

func _palm(pos: Vector3, rng: RandomNumberGenerator) -> void:
    var h := rng.randf_range(6.0, 8.5)
    _cylinder(self, "Palm_Trunk", pos + Vector3(0.0, h * 0.5, 0.0), 0.24, h, trunk_mat, 10)
    for i in range(8):
        var frond := _box(self, "Palm_Frond", pos + Vector3(0.0, h, 0.0), Vector3(0.35, 0.14, rng.randf_range(3.2, 4.6)), palm_green, float(i) * TAU / 8.0)
        frond.rotation.x = -0.25

func _build_flag() -> void:
    _cylinder(self, "Algerian_Flag_Pole", Vector3(-31.0, 8.0, 38.0), 0.12, 16.0, dark_stone, 12)
    _box(self, "Algerian_Flag_Green", Vector3(-28.7, 13.0, 38.0), Vector3(2.3, 3.2, 0.12), green)
    _box(self, "Algerian_Flag_White", Vector3(-26.4, 13.0, 38.0), Vector3(2.3, 3.2, 0.12), white)
    _cylinder(self, "Flag_Red_Crescent_Mark", Vector3(-27.2, 13.0, 37.88), 0.58, 0.08, red, 20)

func _build_lighting() -> void:
    for x in [-50.0, 50.0]:
        for z in [-42.0, 42.0]:
            _cylinder(self, "Plaza_Lamp_Pole", Vector3(x, 4.0, z), 0.12, 8.0, dark_stone, 10)
            _box(self, "Plaza_Lamp_Head", Vector3(x, 8.0, z), Vector3(0.8, 0.24, 0.8), lamp_mat)
