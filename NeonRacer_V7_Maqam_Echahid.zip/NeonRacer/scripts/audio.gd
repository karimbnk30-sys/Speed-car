extends Node
## Autoload "Audio": looping background music + volume refresh from the saved settings.

var music: AudioStreamPlayer
var current := ""

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    music = AudioStreamPlayer.new()
    add_child(music)
    refresh()

func play_music(track: String) -> void:
    if track == current and music.playing:
        refresh()
        return
    current = track
    var res = load("res://audio/%s.wav" % track)
    if res == null:
        return
    var st: AudioStreamWAV = res.duplicate()
    st.loop_mode = AudioStreamWAV.LOOP_FORWARD
    st.loop_begin = 0
    st.loop_end = st.data.size() >> 1
    music.stream = st
    refresh()
    music.play()

func stop_music() -> void:
    current = ""
    music.stop()

func sfx_volume() -> float:
    return float(Save.get_in("settings.audio_master", 1.0)) * float(Save.get_in("settings.audio_sfx", 1.0))

func refresh() -> void:
    var v := float(Save.get_in("settings.audio_master", 1.0)) * float(Save.get_in("settings.audio_music", 0.7))
    music.volume_db = linear_to_db(maxf(v, 0.0001)) - 8.0
