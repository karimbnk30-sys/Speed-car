extends Node3D
## Vegetation: 5 tree species (date palm, cypress, umbrella pine, oak/olive, flowering tree), bushes,
## flower beds and grass tufts. Everything is MultiMesh-instanced in chunks with visibility ranges.
const TexGen := preload("res://scripts/texgen.gd")
const TW := 7.0
const CHUNK := 600.0
const SP_PALM := 0
const SP_CYPRESS := 1
const SP_PINE := 2
const SP_OAK := 3
const SP_BLOSSOM := 4
const SP_BUSH := 5
const SP_GRASS := 6
const SP_FLOWER := 7
const VIS := [900.0, 900.0, 900.0, 900.0, 900.0, 420.0, 190.0, 260.0]

var algiers
var city
var rng := RandomNumberGenerator.new()
var meshes: Array = []
var chunks := {}                 # Vector2i -> {species -> Array of [Transform3D, Color]}
var density := 1.0
var count := 0
var m_bark: StandardMaterial3D
var m_leaf: StandardMaterial3D
var m_frond: StandardMaterial3D
var m_grass: StandardMaterial3D
var m_flower: StandardMaterial3D
var _sphere: SphereMesh
var _cyl: CylinderMesh

const LEAF_GREENS := [
    Color(0.62, 0.82, 0.42), Color(0.5, 0.75, 0.38), Color(0.68, 0.84, 0.5), Color(0.55, 0.7, 0.45), Color(0.72, 0.8, 0.5)]
const BLOSSOMS := [
    Color(1.0, 0.6, 0.75), Color(0.75, 0.55, 0.95), Color(1.0, 0.95, 0.95), Color(1.0, 0.58, 0.42), Color(1.0, 0.85, 0.35)]
const FLOWER_COLORS := [
    Color(0.95, 0.15, 0.2), Color(1.0, 0.85, 0.15), Color(0.95, 0.95, 0.95), Color(0.7, 0.3, 0.9), Color(1.0, 0.5, 0.15), Color(0.2, 0.5, 1.0)]

# ---------------------------------------------------------------- materials + species meshes
func _make_materials() -> void:
    m_bark = StandardMaterial3D.new()
    m_bark.albedo_texture = TexGen.rock()
    m_bark.albedo_color = Color(0.85, 0.62, 0.45)
    m_bark.uv1_scale = Vector3(2, 2, 2)
    m_bark.roughness = 1.0
    m_leaf = StandardMaterial3D.new()
    m_leaf.albedo_texture = TexGen.leaf_noise()
    m_leaf.vertex_color_use_as_albedo = true
    m_leaf.uv1_scale = Vector3(3, 3, 3)
    m_leaf.roughness = 0.8
    m_leaf.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    m_frond = StandardMaterial3D.new()
    m_frond.albedo_texture = TexGen.frond()
    m_frond.vertex_color_use_as_albedo = true
    m_frond.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
    m_frond.alpha_scissor_threshold = 0.5
    m_frond.cull_mode = BaseMaterial3D.CULL_DISABLED
    m_frond.roughness = 0.7
    m_grass = StandardMaterial3D.new()
    m_grass.albedo_texture = TexGen.grass_tuft()
    m_grass.vertex_color_use_as_albedo = true
    m_grass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
    m_grass.alpha_scissor_threshold = 0.5
    m_grass.cull_mode = BaseMaterial3D.CULL_DISABLED
    m_grass.roughness = 0.9
    m_flower = StandardMaterial3D.new()
    m_flower.vertex_color_use_as_albedo = true
    m_flower.roughness = 0.6
    _sphere = SphereMesh.new()
    _sphere.radius = 1.0
    _sphere.height = 2.0
    _sphere.radial_segments = 8
    _sphere.rings = 5
    _cyl = CylinderMesh.new()
    _cyl.top_radius = 0.8
    _cyl.bottom_radius = 1.0
    _cyl.height = 1.0
    _cyl.radial_segments = 7
    _cyl.rings = 1

func _new_st() -> SurfaceTool:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    return st

func _blob(st: SurfaceTool, pos: Vector3, sx: float, sy: float, sz: float) -> void:
    st.append_from(_sphere, 0, Transform3D(Basis.from_scale(Vector3(sx, sy, sz)), pos))

func _stem(st: SurfaceTool, x: float, y: float, z: float, h: float, r: float, tilt: float) -> void:
    var rot := Basis(Vector3(0, 0, 1), tilt) * Basis.from_scale(Vector3(r, h, r))
    st.append_from(_cyl, 0, Transform3D(rot, Vector3(x, y + h * 0.5, z)))

func _mesh2(trunk: SurfaceTool, fol: SurfaceTool, fol_mat: Material) -> ArrayMesh:
    var m := ArrayMesh.new()
    trunk.commit(m)
    m.surface_set_material(0, m_bark)
    fol.commit(m)
    m.surface_set_material(1, fol_mat)
    return m

func _mesh1(fol: SurfaceTool, mat: Material) -> ArrayMesh:
    var m := ArrayMesh.new()
    fol.commit(m)
    m.surface_set_material(0, mat)
    return m

func _frond_quad(st: SurfaceTool, base: Vector3, ang: float, length: float, droop: float) -> void:
    var dir := Vector3(cos(ang), 0.0, sin(ang))
    var perp := Vector3(-dir.z, 0.0, dir.x)
    var p1: Vector3 = base + dir * (length * 0.5) + Vector3(0, length * 0.22, 0)
    var p2: Vector3 = base + dir * length + Vector3(0, -droop, 0)
    var pts: Array = [base, p1, p2]
    var halves: Array = [0.1, length * 0.17, length * 0.07]
    var vs: Array = []
    for k in 3:
        var c: Vector3 = pts[k]
        var hw: float = float(halves[k])
        vs.append([c - perp * hw, c + perp * hw])
    for k in 2:
        var l0: Vector3 = vs[k][0]
        var r0: Vector3 = vs[k][1]
        var l1: Vector3 = vs[k + 1][0]
        var r1: Vector3 = vs[k + 1][1]
        var v0: float = 1.0 - float(k) * 0.5
        var v1: float = 1.0 - float(k + 1) * 0.5
        var order: Array = [[l0, 0.0, v0], [r0, 1.0, v0], [r1, 1.0, v1], [l0, 0.0, v0], [r1, 1.0, v1], [l1, 0.0, v1]]
        for e in order:
            st.set_normal(Vector3.UP)
            st.set_uv(Vector2(float(e[1]), float(e[2])))
            st.add_vertex(e[0])

func _build_species() -> void:
    _make_materials()
    meshes.clear()
    var srng := RandomNumberGenerator.new()
    srng.seed = 777
    # 0: date palm
    var trunk := _new_st()
    var fol := _new_st()
    for k in 8:
        var lean: float = 0.012 * float(k * k)
        _stem(trunk, lean, float(k) * 1.0, 0.0, 1.05, 0.3 - float(k) * 0.022, -0.02 * float(k))
    var crown := Vector3(0.012 * 64.0, 8.0, 0.0)
    for a in 14:
        var ang: float = TAU * float(a) / 14.0 + srng.randf_range(-0.2, 0.2)
        _frond_quad(fol, crown, ang, srng.randf_range(3.0, 3.8), srng.randf_range(0.6, 1.4))
    _blob(fol, crown + Vector3(0, 0.2, 0), 0.45, 0.35, 0.45)
    meshes.append(_mesh2(trunk, fol, m_frond))
    # 1: cypress
    trunk = _new_st()
    fol = _new_st()
    _stem(trunk, 0.0, 0.0, 0.0, 1.4, 0.16, 0.0)
    _blob(fol, Vector3(0, 3.2, 0), 1.15, 2.2, 1.15)
    _blob(fol, Vector3(0, 5.8, 0), 0.95, 2.2, 0.95)
    _blob(fol, Vector3(0, 8.2, 0), 0.65, 1.8, 0.65)
    meshes.append(_mesh2(trunk, fol, m_leaf))
    # 2: umbrella pine
    trunk = _new_st()
    fol = _new_st()
    for k in 5:
        _stem(trunk, 0.05 * float(k), float(k) * 1.2, 0.0, 1.25, 0.24 - float(k) * 0.02, -0.04 * float(k))
    _blob(fol, Vector3(0.2, 6.4, 0.0), 3.2, 0.95, 3.2)
    _blob(fol, Vector3(1.7, 5.9, 0.6), 2.2, 0.7, 2.2)
    _blob(fol, Vector3(-1.5, 6.1, -0.8), 2.4, 0.8, 2.4)
    _blob(fol, Vector3(0.3, 7.2, 0.2), 1.8, 0.6, 1.8)
    meshes.append(_mesh2(trunk, fol, m_leaf))
    # 3 + 4: oak / olive and a smaller flowering tree
    for variant in 2:
        trunk = _new_st()
        fol = _new_st()
        var th: float = 2.6 if variant == 0 else 2.0
        _stem(trunk, 0.0, 0.0, 0.0, th, 0.26 if variant == 0 else 0.2, 0.0)
        _stem(trunk, 0.0, th * 0.8, 0.0, 1.2, 0.14, 0.5)
        var nb: int = 6 if variant == 0 else 5
        var rr: float = 1.7 if variant == 0 else 1.2
        for k in nb:
            var a2: float = TAU * float(k) / float(nb) + srng.randf_range(-0.3, 0.3)
            var rad: float = rr * srng.randf_range(0.55, 1.0)
            _blob(fol, Vector3(cos(a2) * rr * 0.85, th + 1.1 + srng.randf_range(-0.3, 0.9), sin(a2) * rr * 0.85), rad, rad * 0.85, rad)
        _blob(fol, Vector3(0, th + 1.9, 0), rr * 0.95, rr * 0.8, rr * 0.95)
        meshes.append(_mesh2(trunk, fol, m_leaf))
    # 5: bush
    fol = _new_st()
    for k in 5:
        var a3: float = TAU * float(k) / 5.0
        _blob(fol, Vector3(cos(a3) * 0.5, 0.45, sin(a3) * 0.5), 0.6, 0.55, 0.6)
    _blob(fol, Vector3(0, 0.7, 0), 0.7, 0.6, 0.7)
    meshes.append(_mesh1(fol, m_leaf))
    # 6: grass tuft (two crossed quads)
    fol = _new_st()
    for q in 2:
        var ang2: float = float(q) * PI * 0.5
        var ax := Vector3(cos(ang2), 0.0, sin(ang2)) * 0.5
        var order2: Array = [[-1.0, 0.0, 0.0, 1.0], [1.0, 0.0, 1.0, 1.0], [1.0, 0.8, 1.0, 0.0], [-1.0, 0.0, 0.0, 1.0], [1.0, 0.8, 1.0, 0.0], [-1.0, 0.8, 0.0, 0.0]]
        for e in order2:
            fol.set_normal(Vector3.UP)
            fol.set_uv(Vector2(float(e[2]), float(e[3])))
            fol.add_vertex(ax * float(e[0]) + Vector3(0, float(e[1]), 0))
    meshes.append(_mesh1(fol, m_grass))
    # 7: flower patch
    fol = _new_st()
    for k in 6:
        var a4: float = TAU * float(k) / 6.0
        var rr2: float = 0.35 if k < 5 else 0.0
        _blob(fol, Vector3(cos(a4) * rr2, 0.16, sin(a4) * rr2), 0.13, 0.11, 0.13)
    meshes.append(_mesh1(fol, m_flower))

# ---------------------------------------------------------------- instances
func add(sp: int, pos: Vector2, scale_f: float, yaw: float, tint: Color) -> void:
    var rot := Basis(Vector3.UP, yaw).scaled(Vector3(scale_f, scale_f, scale_f))
    var key := Vector2i(int(floorf(pos.x / CHUNK)), int(floorf(pos.y / CHUNK)))
    if not chunks.has(key):
        chunks[key] = {}
    var ch: Dictionary = chunks[key]
    if not ch.has(sp):
        ch[sp] = []
    ch[sp].append([Transform3D(rot, Vector3(pos.x, 0.0, pos.y)), tint])
    count += 1

func _tint(sp: int) -> Color:
    if sp == SP_PALM:
        return Color(rng.randf_range(0.8, 1.0), rng.randf_range(0.92, 1.0), rng.randf_range(0.7, 0.9))
    if sp == SP_CYPRESS:
        return Color(0.55, 0.72, 0.55)
    if sp == SP_PINE:
        return Color(0.6, 0.78, 0.55)
    if sp == SP_BLOSSOM:
        return BLOSSOMS[rng.randi_range(0, BLOSSOMS.size() - 1)]
    return LEAF_GREENS[rng.randi_range(0, LEAF_GREENS.size() - 1)]

func _free(p: Vector2, r: float, near_road: float) -> bool:
    if algiers.road_dist(p) < near_road:
        return false
    if algiers.in_sea(p):
        return false
    if algiers.wadi_on and algiers.in_wadi(p, r + 2.0):
        return false
    if algiers.in_water_zone(p, r):
        return false
    return not city.overlaps(p, r)

func _pick_tree(w_palm: float, w_cyp: float, w_pine: float, w_oak: float, w_blo: float) -> int:
    var total: float = w_palm + w_cyp + w_pine + w_oak + w_blo
    var r: float = rng.randf() * total
    r -= w_palm
    if r <= 0.0:
        return SP_PALM
    r -= w_cyp
    if r <= 0.0:
        return SP_CYPRESS
    r -= w_pine
    if r <= 0.0:
        return SP_PINE
    r -= w_oak
    if r <= 0.0:
        return SP_OAK
    return SP_BLOSSOM

func populate_route() -> void:
    var preset: String = str(Save.get_in("settings.graphics_preset", "auto"))
    density = 0.55 if preset == "low" else (0.85 if preset == "medium" else 1.0)
    var pts: Array[Vector2] = algiers.pts
    var n: int = pts.size()
    # boulevard rows right behind the sidewalk
    for i in range(6, n - 6, 3):
        var t: Vector2 = (pts[i + 1] - pts[i - 1]).normalized()
        var nrm := Vector2(-t.y, t.x)
        for side in [-1.0, 1.0]:
            var sd: float = side
            if rng.randf() > 0.85 * density:
                continue
            var p: Vector2 = pts[i] + nrm * sd * (TW + 6.2) + t * rng.randf_range(-2.0, 2.0)
            if not _free(p, 1.4, TW + 5.2):
                continue
            var sp: int = _pick_tree(0.5, 0.2, 0.0, 0.12, 0.18)
            add(sp, p, rng.randf_range(0.85, 1.3), rng.randf() * TAU, _tint(sp))
    # gardens and parks behind the first building row
    for i in range(5, n - 5, 2):
        var t2: Vector2 = (pts[i + 1] - pts[i - 1]).normalized()
        var nrm2 := Vector2(-t2.y, t2.x)
        for side in [-1.0, 1.0]:
            var sd2: float = side
            if rng.randf() > 0.55 * density:
                continue
            var off: float = rng.randf_range(14.0, 64.0)
            var p2: Vector2 = pts[i] + nrm2 * sd2 * off + t2 * rng.randf_range(-6.0, 6.0)
            if not _free(p2, 2.6, TW + 7.0):
                continue
            var sp2: int = _pick_tree(0.1, 0.2, 0.22, 0.33, 0.15)
            add(sp2, p2, rng.randf_range(0.75, 1.35), rng.randf() * TAU, _tint(sp2))
    # bushes and flower beds along the frontage
    for i in range(4, n - 4, 2):
        var t3: Vector2 = (pts[i + 1] - pts[i - 1]).normalized()
        var nrm3 := Vector2(-t3.y, t3.x)
        for side in [-1.0, 1.0]:
            var sd3: float = side
            if rng.randf() < 0.55 * density:
                var pb: Vector2 = pts[i] + nrm3 * sd3 * (TW + rng.randf_range(5.6, 8.5)) + t3 * rng.randf_range(-2.0, 2.0)
                if _free(pb, 0.9, TW + 5.2):
                    var tint_b: Color = LEAF_GREENS[rng.randi_range(0, LEAF_GREENS.size() - 1)]
                    if rng.randf() < 0.2:
                        tint_b = BLOSSOMS[rng.randi_range(0, BLOSSOMS.size() - 1)]
                    add(SP_BUSH, pb, rng.randf_range(0.8, 1.4), rng.randf() * TAU, tint_b)
            if i % 4 == 0 and rng.randf() < 0.5 * density:
                var base: Vector2 = pts[i] + nrm3 * sd3 * (TW + rng.randf_range(6.0, 9.0))
                var fc: Color = FLOWER_COLORS[rng.randi_range(0, FLOWER_COLORS.size() - 1)]
                for k in 5:
                    var pf: Vector2 = base + Vector2(rng.randf_range(-2.5, 2.5), rng.randf_range(-2.5, 2.5))
                    if _free(pf, 0.5, TW + 5.2):
                        add(SP_FLOWER, pf, rng.randf_range(0.9, 1.6), rng.randf() * TAU, fc)
    # grass tufts on the verges (skipped on the lowest preset)
    if preset != "low":
        for i in range(4, n - 4, 2):
            var t4: Vector2 = (pts[i + 1] - pts[i - 1]).normalized()
            var nrm4 := Vector2(-t4.y, t4.x)
            for side in [-1.0, 1.0]:
                var sd4: float = side
                for k in 3:
                    var pg: Vector2 = pts[i] + nrm4 * sd4 * (TW + rng.randf_range(5.4, 12.0)) + t4 * rng.randf_range(-3.0, 3.0)
                    if algiers.in_water_zone(pg, 0.0) or algiers.in_sea(pg):
                        continue
                    if algiers.wadi_on and algiers.in_wadi(pg, 1.0):
                        continue
                    var g: float = rng.randf_range(0.0, 0.25)
                    add(SP_GRASS, pg, rng.randf_range(0.7, 1.4), rng.randf() * TAU, Color(0.7 + g, 0.85 + g * 0.3, 0.5))

func commit() -> void:
    for key in chunks:
        var kk: Vector2i = key
        var ch: Dictionary = chunks[kk]
        var origin := Vector3((float(kk.x) + 0.5) * CHUNK, 0.0, (float(kk.y) + 0.5) * CHUNK)
        for skey in ch:
            var sp: int = skey
            var list: Array = ch[sp]
            var mm := MultiMesh.new()
            mm.transform_format = MultiMesh.TRANSFORM_3D
            mm.use_colors = true
            mm.mesh = meshes[sp]
            mm.instance_count = list.size()
            for k in list.size():
                var pair: Array = list[k]
                var xf: Transform3D = pair[0]
                xf.origin -= origin
                mm.set_instance_transform(k, xf)
                mm.set_instance_color(k, pair[1])
            var mi := MultiMeshInstance3D.new()
            mi.multimesh = mm
            mi.position = origin
            mi.visibility_range_end = float(VIS[sp])
            if sp >= SP_BUSH:
                mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
            add_child(mi)

func begin(alg, city_ref) -> void:
    algiers = alg
    city = city_ref
    name = "Vegetation"
    rng.seed = 31337
    _build_species()
