# Neon Racer V7 — Maqam Echahid Integration

## What changed
- Added `scripts/maqam_echahid.gd`, a standalone procedural landmark scene builder.
- Integrated it from `scripts/algiers.gd` after the existing city, vegetation and roadside generation.
- Reserved a clear parcel in the procedural city generator by updating `algiers.gd` and `city.gd`.
- Added a short access boulevard from the existing route to the memorial forecourt.

## What was intentionally left untouched
Vehicle physics, steering, AI racing, route definition, stage list, race manager, HUD, traffic and save data were not modified.

## Placement
The landmark is attached near route point 950, on the open side of the existing road, at the transition between the `CASBAH RUN` and `HILLTOP RUSH` race sectors. The route itself and its race indices remain unchanged. Placement is a map-fit approximation and should be checked in the Godot editor.

## Open
Import `project.godot` in Godot 4.3+ and run the project. Start the second stage (`CASBAH RUN`) to drive past the new memorial area.

## Limitations
This is an integrated procedural environment pass, not finished photogrammetry or final AAA art. The landmark geometry and landscaping are generated from meshes and materials in code. A final art pass can replace these with higher-resolution custom assets without changing the racing systems.
