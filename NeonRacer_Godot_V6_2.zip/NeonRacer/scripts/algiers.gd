extends Node3D
## Algiers map built from OpenStreetMap data (c) OpenStreetMap contributors.
const TW := 7.0
var pts: Array[Vector2] = []
var nrm: Array[Vector2] = []
var yaw0 := 0.0
var end_point := Vector2.ZERO
var cum: PackedFloat32Array = PackedFloat32Array()
var tex_win: Texture2D
var tex_road: Texture2D
var tex_ground: Texture2D
var road_mat: StandardMaterial3D
var mat_paving: StandardMaterial3D   # ambientCG PavingStones142, null if textures are missing

func build() -> void:
    var f := FileAccess.open("res://maps/algiers.json", FileAccess.READ)
    if f == null:
        push_warning("maps/algiers.json not found")
        return
    var d: Dictionary = JSON.parse_string(f.get_as_text())
    for p in d["r"]:
        pts.append(Vector2(p[0], p[1]))
    var n := pts.size()
    for i in n:
        var a := pts[maxi(i - 1, 0)]
        var b := pts[mini(i + 1, n - 1)]
        var t := (b - a).normalized()
        nrm.append(Vector2(-t.y, t.x))
    var t0 := (pts[1] - pts[0]).normalized()
    yaw0 = atan2(-t0.x, -t0.y)
    end_point = pts[n - 1]
    cum.resize(n)
    cum[0] = 0.0
    for i in range(1, n):
        cum[i] = cum[i - 1] + pts[i].distance_to(pts[i - 1])
    tex_win = _make_window_tex()
    tex_road = _make_noise_tex(Color(0.20, 0.20, 0.22), 0.07, 128)
    tex_ground = _make_noise_tex(Color(0.66, 0.60, 0.48), 0.06, 128)
    mat_paving = _paving_mat()
    # road surface, edge lines, centre dashes
    var road_mi: MeshInstance3D = _ribbon(-TW, 0.02, TW, 0.02, Color.WHITE, false, false, false, tex_road, 8.0)
    road_mat = road_mi.material_override as StandardMaterial3D
    _ribbon(-0.1, 0.06, 0.1, 0.06, Color(0.95, 0.95, 0.9), false, true, false)
    for s in [-1.0, 1.0]:
        _ribbon(s * (TW - 0.55), 0.06, s * (TW - 0.4), 0.06, Color(0.95, 0.95, 0.9), false, false, false)
        # concrete barrier (collision) + kerb + sidewalk
        _ribbon(s * (TW + 0.25), 0.0, s * (TW + 0.25), 1.0, Color(0.62, 0.62, 0.6), false, false, true)
        _ribbon(s * (TW + 0.25), 1.0, s * (TW + 0.55), 1.0, Color(0.7, 0.7, 0.68), false, false, false)
        # sidewalk: ordered so the surface normal always faces up (needed for the normal map)
        var sw_a := (TW + 0.55) if s > 0.0 else -(TW + 5.0)
        var sw_b := (TW + 5.0) if s > 0.0 else -(TW + 0.55)
        _ribbon(sw_a, 0.14, sw_b, 0.14, Color(0.6, 0.58, 0.54), false, false, false, null, 1.5, mat_paving)
    _buildings(d["b"])
    _build_route_districts(d["sea"])
    _sea(d["sea"])
    _props()
    _kerbs()
    var g := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(14000, 14000)
    g.mesh = pm
    g.material_override = _ground_mat()
    g.position = Vector3(2500, -0.3, -2500)
    g.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(g)

# terrain photo stretched over the whole map + fine tiled grain for close-ups
func _ground_mat() -> Material:
    var macro = load("res://textures/terrain_color.jpg")
    if macro == null:
        var gm := _mat(Color.WHITE, false, tex_ground)
        gm.uv1_scale = Vector3(1750, 1750, 1)
        return gm
    var sh := Shader.new()
    sh.code = """shader_type spatial;
uniform sampler2D macro_tex : source_color, filter_linear_mipmap_anisotropic, repeat_disable;
uniform sampler2D detail_tex : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform float tiles = 1750.0;
void fragment() {
    vec3 m = texture(macro_tex, UV).rgb;
    // Re-tint the old dry terrain into a greener Mediterranean grassland.
    // Keep a little macro texture variation so it does not look like a flat green plane.
    vec3 grass = vec3(0.20, 0.39, 0.15);
    m = mix(m, grass, 0.84);
    float d = texture(detail_tex, UV * tiles).r;
    float variation = 0.82 + d * 0.42;
    ALBEDO = m * variation;
    ROUGHNESS = 0.95;
    SPECULAR = 0.1;
}
"""
    var sm := ShaderMaterial.new()
    sm.shader = sh
    sm.set_shader_parameter("macro_tex", macro)
    sm.set_shader_parameter("detail_tex", _make_noise_tex(Color(0.5, 0.5, 0.5), 0.08, 128))
    return sm

func _make_noise_tex(base: Color, amount: float, size: int) -> ImageTexture:
    var img := Image.create(size, size, false, Image.FORMAT_RGB8)
    var rng := RandomNumberGenerator.new()
    rng.seed = 11
    for y in size:
        for x in size:
            var n := rng.randf_range(-amount, amount)
            if rng.randf() < 0.015:
                n += amount * 1.5
            img.set_pixel(x, y, Color(clampf(base.r + n, 0.0, 1.0), clampf(base.g + n, 0.0, 1.0), clampf(base.b + n, 0.0, 1.0)))
    img.generate_mipmaps()
    return ImageTexture.create_from_image(img)

# one facade tile = 4 m wide x 3.2 m tall: plaster wall with a glass window
func _make_window_tex() -> ImageTexture:
    var w := 64
    var h := 128
    var img := Image.create(w, h, false, Image.FORMAT_RGB8)
    var wall := Color(0.96, 0.95, 0.92)
    for y in h:
        for x in w:
            var c := wall
            if x >= 14 and x < 50 and y >= 26 and y < 100:
                var t := float(y - 26) / 74.0
                c = Color(0.20, 0.27, 0.35).lerp(Color(0.55, 0.65, 0.75), 1.0 - t)
                if x < 16 or x >= 48 or y < 28 or y >= 98 or absi(x - 32) < 1:
                    c = Color(0.35, 0.35, 0.36)
            elif x >= 12 and x < 52 and y >= 100 and y < 104:
                c = Color(0.80, 0.79, 0.76)
            elif y >= 120:
                c = wall.darkened(0.06)
            img.set_pixel(x, y, c)
    img.generate_mipmaps()
    return ImageTexture.create_from_image(img)

func _paving_mat() -> StandardMaterial3D:
    var col = load("res://textures/sidewalk/paving_color_1k.jpg")
    if col == null:
        push_warning("Sidewalk paving textures missing - using plain colour")
        return null
    var m := StandardMaterial3D.new()
    m.albedo_texture = col
    m.albedo_color = Color(0.92, 0.9, 0.86)
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    var nrm_tex = load("res://textures/sidewalk/paving_normal_1k.png")
    if nrm_tex != null:
        m.normal_enabled = true
        m.normal_texture = nrm_tex
        m.normal_scale = 0.8
    var rough_tex = load("res://textures/sidewalk/paving_rough_1k.png")
    m.roughness = 1.0
    if rough_tex != null:
        m.roughness_texture = rough_tex
        m.roughness_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_RED
    return m

func _mat(c: Color, emissive: bool, tex: Texture2D = null) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    if tex != null:
        m.albedo_texture = tex
        m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    m.roughness = 0.85
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    if emissive:
        m.emission_enabled = true
        m.emission = c
    return m

func _ribbon(oa: float, ya: float, ob: float, yb: float, color: Color, emissive: bool, dashed: bool, collide: bool, tex: Texture2D = null, tile: float = 8.0, override_mat: Material = null) -> MeshInstance3D:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var faces := PackedVector3Array()
    for i in pts.size() - 1:
        if dashed and i % 3 != 0:
            continue
        var a0 := Vector3(pts[i].x + nrm[i].x * oa, ya, pts[i].y + nrm[i].y * oa)
        var b0 := Vector3(pts[i].x + nrm[i].x * ob, yb, pts[i].y + nrm[i].y * ob)
        var a1 := Vector3(pts[i + 1].x + nrm[i + 1].x * oa, ya, pts[i + 1].y + nrm[i + 1].y * oa)
        var b1 := Vector3(pts[i + 1].x + nrm[i + 1].x * ob, yb, pts[i + 1].y + nrm[i + 1].y * ob)
        var uw := absf(ob - oa) / tile
        var v0 := cum[i] / tile
        var v1 := cum[i + 1] / tile
        var vs := [a0, b0, a1, b0, b1, a1]
        var us := [Vector2(0, v0), Vector2(uw, v0), Vector2(0, v1), Vector2(uw, v0), Vector2(uw, v1), Vector2(0, v1)]
        for k in 6:
            st.set_uv(us[k])
            st.add_vertex(vs[k])
            faces.append(vs[k])
    st.generate_normals()
    if override_mat != null:
        st.generate_tangents()   # needed by the normal map
    var mi := MeshInstance3D.new()
    mi.mesh = st.commit()
    mi.material_override = override_mat if override_mat != null else _mat(color, emissive, tex)
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)
    if collide:
        var body := StaticBody3D.new()
        var cs := CollisionShape3D.new()
        var sh := ConcavePolygonShape3D.new()
        sh.set_faces(faces)
        sh.backface_collision = true
        cs.shape = sh
        body.add_child(cs)
        add_child(body)
    return mi

func _buildings(list: Array) -> void:
    var cells := {}
    for bi in list.size():
        var b0: Array = list[bi]
        var key := Vector2i(int(floorf(float(b0[1]) / 500.0)), int(floorf(float(b0[2]) / 500.0)))
        if not cells.has(key):
            cells[key] = []
        cells[key].append(bi)
    var mat := StandardMaterial3D.new()
    mat.vertex_color_use_as_albedo = true
    mat.albedo_texture = tex_win
    mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.roughness = 0.75
    for key in cells:
        _buildings_chunk(list, cells[key], mat)

func _buildings_chunk(list: Array, idxs: Array, mat: Material) -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    st.set_smooth_group(-1)
    var cols := [Color("f2eee4"), Color("e8dfcf"), Color("dcd3c4"), Color("f7f4ee"), Color("d9c8b0")]
    var roof := Color(0.55, 0.56, 0.57)
    for bi in idxs:
        var b: Array = list[bi]
        var h: float = b[0]
        var poly := PackedVector2Array()
        for i in range(1, b.size(), 2):
            poly.append(Vector2(b[i], b[i + 1]))
        var col: Color = cols[bi % cols.size()]
        var m := poly.size()
        var cu := 0.0
        for i in m:
            var p := poly[i]
            var q := poly[(i + 1) % m]
            var ul := p.distance_to(q) / 4.0
            var vt := 1.0 - h / 3.2
            var wv := [Vector3(p.x, 0, p.y), Vector3(q.x, 0, q.y), Vector3(q.x, h, q.y), Vector3(p.x, 0, p.y), Vector3(q.x, h, q.y), Vector3(p.x, h, p.y)]
            var wu := [Vector2(cu, 1.0), Vector2(cu + ul, 1.0), Vector2(cu + ul, vt), Vector2(cu, 1.0), Vector2(cu + ul, vt), Vector2(cu, vt)]
            for k in 6:
                st.set_color(col)
                st.set_uv(wu[k])
                st.add_vertex(wv[k])
            cu += ul
        for k in Geometry2D.triangulate_polygon(poly):
            st.set_color(roof)
            st.set_uv(Vector2(0.02, 0.02))
            st.add_vertex(Vector3(poly[k].x, h, poly[k].y))
    st.generate_normals()
    var mi := MeshInstance3D.new()
    mi.mesh = st.commit()
    mi.material_override = mat
    # Keep distant city blocks visible along the full 5 km route.
    # The previous 1300 m range was measured from each chunk origin and could
    # make whole districts disappear while racing far from the map origin.
    add_child(mi)


# Fill the empty strips beside the mapped Algiers road with lightweight
# Mediterranean-style low-rise blocks. Buildings are batched in one MultiMesh
# to keep draw calls low on Android. Existing OSM buildings remain untouched.
func _build_route_districts(sea_flat: Array) -> void:
    var sea_poly := PackedVector2Array()
    for k in range(0, sea_flat.size(), 2):
        sea_poly.append(Vector2(sea_flat[k], sea_flat[k + 1]))
    var box := BoxMesh.new()
    box.size = Vector3.ONE
    var mat := StandardMaterial3D.new()
    mat.vertex_color_use_as_albedo = true
    mat.roughness = 0.92
    mat.cull_mode = BaseMaterial3D.CULL_BACK

    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.use_colors = true
    mm.mesh = box

    var transforms: Array[Transform3D] = []
    var colors: Array[Color] = []
    var rng := RandomNumberGenerator.new()
    rng.seed = 73021
    var palette := [
        Color("e8dfcf"), Color("f0e9dc"), Color("d9d0c2"),
        Color("e4d2b8"), Color("f3eee5"), Color("d7d8d2"),
        Color("cfc6b6")
    ]

    # Two staggered rows on both sides create a continuous urban skyline
    # without placing walls directly beside the road or blocking the track.
    for i in range(10, pts.size() - 10, 7):
        var tangent := (pts[mini(i + 1, pts.size() - 1)] - pts[maxi(i - 1, 0)]).normalized()
        var normal := Vector2(-tangent.y, tangent.x)
        var yaw := atan2(-tangent.x, -tangent.y)
        for side in [-1.0, 1.0]:
            for row in 2:
                # Randomized setbacks leave occasional plazas and side streets.
                var along := rng.randf_range(-10.0, 10.0)
                var setback := rng.randf_range(25.0, 42.0) if row == 0 else rng.randf_range(61.0, 88.0)
                var center: Vector2 = pts[i] + tangent * along + normal * (float(side) * setback)
                # Never place generated city blocks inside the mapped sea polygon.
                if not sea_poly.is_empty() and Geometry2D.is_point_in_polygon(center, sea_poly):
                    continue
                var width := rng.randf_range(17.0, 31.0)
                var depth := rng.randf_range(13.0, 22.0)
                var height := rng.randf_range(7.0, 19.0)
                # A few taller apartment blocks break up the roofline.
                if rng.randf() < 0.13:
                    height = rng.randf_range(20.0, 30.0)
                var basis := Basis(Vector3.UP, yaw).scaled(Vector3(width, height, depth))
                var origin := Vector3(center.x, height * 0.5, center.y)
                transforms.append(Transform3D(basis, origin))
                colors.append(palette[rng.randi_range(0, palette.size() - 1)])

    mm.instance_count = transforms.size()
    for i in transforms.size():
        mm.set_instance_transform(i, transforms[i])
        mm.set_instance_color(i, colors[i])

    var city := MultiMeshInstance3D.new()
    city.name = "Procedural_Route_Districts"
    city.multimesh = mm
    city.material_override = mat
    city.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    add_child(city)

func _sea(flat: Array) -> void:
    var poly := PackedVector2Array()
    for i in range(0, flat.size(), 2):
        poly.append(Vector2(flat[i], flat[i + 1]))
    var tri := Geometry2D.triangulate_polygon(poly)
    if tri.is_empty():
        push_warning("sea polygon could not be triangulated")
        return
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for k in tri:
        st.add_vertex(Vector3(poly[k].x, -0.2, poly[k].y))
    st.generate_normals()
    var mi := MeshInstance3D.new()
    mi.mesh = st.commit()
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(0.06, 0.28, 0.45)
    m.metallic = 0.4
    m.metallic_specular = 0.8
    m.roughness = 0.12
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    mi.material_override = m
    add_child(mi)

func _mm(mesh: Mesh, mat: Material, xf: Array[Transform3D], shadow: bool) -> void:
    if xf.is_empty():
        return
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.mesh = mesh
    mm.instance_count = xf.size()
    for i in xf.size():
        mm.set_instance_transform(i, xf[i])
    var mi := MultiMeshInstance3D.new()
    mi.multimesh = mm
    mi.material_override = mat
    if not shadow:
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)

# street lamps and trees along the sidewalks
func _props() -> void:
    var pole: Array[Transform3D] = []
    var head: Array[Transform3D] = []
    var trunk: Array[Transform3D] = []
    var crown: Array[Transform3D] = []
    var n := pts.size()
    var side := 1.0
    for i in range(6, n - 6, 7):
        side = -side
        var pl: Vector2 = pts[i] + nrm[i] * (side * (TW + 1.4))
        pole.append(Transform3D(Basis(), Vector3(pl.x, 3.5, pl.y)))
        var hd: Vector2 = pts[i] + nrm[i] * (side * (TW + 0.5))
        head.append(Transform3D(Basis(), Vector3(hd.x, 7.0, hd.y)))
        var tp: Vector2 = pts[i + 3] + nrm[i + 3] * (-side * (TW + 3.2))
        trunk.append(Transform3D(Basis(), Vector3(tp.x, 1.6, tp.y)))
        crown.append(Transform3D(Basis(), Vector3(tp.x, 4.2, tp.y)))
    var pm := CylinderMesh.new()
    pm.top_radius = 0.06
    pm.bottom_radius = 0.1
    pm.height = 7.0
    _mm(pm, _mat(Color(0.25, 0.26, 0.28), false), pole, false)
    var hm := BoxMesh.new()
    hm.size = Vector3(0.9, 0.15, 0.4)
    _mm(hm, _mat(Color(1.0, 0.85, 0.55), true), head, false)
    var tm := CylinderMesh.new()
    tm.top_radius = 0.14
    tm.bottom_radius = 0.22
    tm.height = 3.2
    _mm(tm, _mat(Color(0.38, 0.28, 0.2), false), trunk, true)
    var cm := SphereMesh.new()
    cm.radius = 1.7
    cm.height = 3.0
    _mm(cm, _mat(Color(0.2, 0.42, 0.18), false), crown, true)


# red / white blocks on top of the barriers: the classic race-track look (2 MultiMeshes)
func _kerbs() -> void:
    var red: Array[Transform3D] = []
    var white: Array[Transform3D] = []
    var n := pts.size()
    for i in range(1, n - 1, 2):
        for s in [-1.0, 1.0]:
            var c: Vector2 = pts[i] + nrm[i] * (s * (TW + 0.25))
            var t := Vector2(nrm[i].y, -nrm[i].x)   # along the road
            var b := Basis.looking_at(Vector3(t.x, 0.0, t.y), Vector3.UP)
            var xf := Transform3D(b, Vector3(c.x, 1.05, c.y))
            if (i / 2) % 2 == 0:
                red.append(xf)
            else:
                white.append(xf)
    var bm := BoxMesh.new()
    bm.size = Vector3(0.45, 0.12, 6.0)
    _mm(bm, _mat(Color(0.85, 0.08, 0.1), false), red, false)
    _mm(bm, _mat(Color(0.95, 0.95, 0.95), false), white, false)

# checkered gantry over the road at a point-to-point stage start / finish
func add_gantry(center: Vector2, tangent: Vector2, label: String, color: Color) -> void:
    var root := Node3D.new()
    root.position = Vector3(center.x, 0.0, center.y)
    root.basis = Basis.looking_at(Vector3(tangent.x, 0.0, tangent.y), Vector3.UP)
    add_child(root)
    var half := TW + 0.9
    var dark := _mat(Color(0.12, 0.13, 0.16), false)
    for sx in [-1.0, 1.0]:
        var pm := MeshInstance3D.new()
        var bx := BoxMesh.new()
        bx.size = Vector3(0.7, 8.0, 0.7)
        pm.mesh = bx
        pm.material_override = dark
        pm.position = Vector3(sx * half, 4.0, 0.0)
        root.add_child(pm)
    var beam := MeshInstance3D.new()
    var bb := BoxMesh.new()
    bb.size = Vector3(half * 2.0 + 0.7, 1.6, 0.8)
    beam.mesh = bb
    var cm := StandardMaterial3D.new()
    cm.albedo_texture = _checker_tex()
    cm.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
    cm.uv1_scale = Vector3(14.0, 1.0, 1.0)
    cm.emission_enabled = true
    cm.emission = color
    cm.emission_energy_multiplier = 0.15
    beam.material_override = cm
    beam.position = Vector3(0.0, 7.4, 0.0)
    root.add_child(beam)
    for side in [1.0, -1.0]:
        var lb := Label3D.new()
        lb.text = label
        lb.font_size = 96
        lb.pixel_size = 0.014
        lb.modulate = color
        lb.outline_modulate = Color(0, 0, 0, 1)
        lb.outline_size = 16
        lb.position = Vector3(0.0, 9.2, side * 0.5)
        lb.rotation.y = 0.0 if side > 0.0 else PI
        root.add_child(lb)
    # painted start/finish line on the asphalt
    var line := MeshInstance3D.new()
    var pl := PlaneMesh.new()
    pl.size = Vector2(TW * 2.0, 1.4)
    line.mesh = pl
    var lm := StandardMaterial3D.new()
    lm.albedo_texture = cm.albedo_texture
    lm.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
    lm.uv1_scale = Vector3(14.0, 2.0, 1.0)
    line.material_override = lm
    line.position = Vector3(0.0, 0.07, 0.0)
    line.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(line)

func _checker_tex() -> ImageTexture:
    var img := Image.create(2, 2, false, Image.FORMAT_RGB8)
    img.set_pixel(0, 0, Color.WHITE)
    img.set_pixel(1, 1, Color.WHITE)
    img.set_pixel(1, 0, Color(0.05, 0.05, 0.05))
    img.set_pixel(0, 1, Color(0.05, 0.05, 0.05))
    return ImageTexture.create_from_image(img)

# night / dusk: turn on street-lamp glow (emissive heads are already in the scene)
func set_night(on: bool) -> void:
    for c in get_children():
        if c is GeometryInstance3D:
            var gi: GeometryInstance3D = c
            if gi.material_override is StandardMaterial3D:
                var m: StandardMaterial3D = gi.material_override
                if m.emission_enabled and m.albedo_color.r > 0.9 and m.albedo_color.g > 0.8 and m.albedo_color.b < 0.6:
                    m.emission_energy_multiplier = 6.0 if on else 1.0

# rain: darker, glossy asphalt
func set_wet(on: bool) -> void:
    if road_mat == null or not on:
        return
    road_mat.roughness = 0.2
    road_mat.metallic_specular = 0.9
    road_mat.albedo_color = Color(0.5, 0.5, 0.56)

# speed trap camera on a pole beside the road (the trigger itself lives in main.gd)
func add_speedcam(center: Vector2, tangent: Vector2) -> void:
    var root := Node3D.new()
    root.position = Vector3(center.x, 0.0, center.y)
    root.basis = Basis.looking_at(Vector3(tangent.x, 0.0, tangent.y), Vector3.UP)
    add_child(root)
    var pole := MeshInstance3D.new()
    var pb := BoxMesh.new()
    pb.size = Vector3(0.25, 6.0, 0.25)
    pole.mesh = pb
    pole.material_override = _mat(Color(0.15, 0.15, 0.18), false)
    pole.position = Vector3(TW + 1.0, 3.0, 0.0)
    root.add_child(pole)
    var cam_box := MeshInstance3D.new()
    var hb := BoxMesh.new()
    hb.size = Vector3(1.4, 0.8, 1.0)
    cam_box.mesh = hb
    cam_box.material_override = _mat(Color(1.0, 0.9, 0.2), true)
    cam_box.position = Vector3(TW + 1.0, 6.2, 0.0)
    root.add_child(cam_box)
    var lb := Label3D.new()
    lb.text = "SPEED TRAP"
    lb.font_size = 64
    lb.pixel_size = 0.012
    lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    lb.modulate = Color(1.0, 0.9, 0.2)
    lb.outline_modulate = Color(0, 0, 0, 1)
    lb.outline_size = 12
    lb.position = Vector3(TW + 1.0, 7.4, 0.0)
    root.add_child(lb)
