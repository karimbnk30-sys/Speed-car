extends CharacterBody3D
## Arcade car physics: throttle, brake, reverse, steering, drift, collisions.
signal crashed(force: float)

var throttle := 0.0
var braking := false
var steer := 0.0
var drift := false

var speed := 0.0      # m/s along heading
var lateral := 0.0    # m/s sideways (drift)
var max_speed := 70.0
var accel := 22.0
var brake_force := 45.0
var turn_rate := 1.9
var grip := 8.0

var body_mat := StandardMaterial3D.new()
var smoke: CPUParticles3D

func _ready() -> void:
    motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(1.9, 0.9, 4.2)
    cs.shape = bs
    cs.position.y = 0.2
    add_child(cs)

    body_mat.albedo_color = Color(0.9, 0.1, 0.15)
    body_mat.metallic = 0.8
    body_mat.roughness = 0.25
    var glass := StandardMaterial3D.new()
    glass.albedo_color = Color(0.05, 0.08, 0.12)
    glass.metallic = 1.0
    glass.roughness = 0.1
    var tire := StandardMaterial3D.new()
    tire.albedo_color = Color(0.03, 0.03, 0.03)
    var head := StandardMaterial3D.new()
    head.albedo_color = Color(1, 1, 0.9)
    head.emission_enabled = true
    head.emission = Color(1, 1, 0.8)
    var tail := StandardMaterial3D.new()
    tail.albedo_color = Color(1, 0, 0)
    tail.emission_enabled = true
    tail.emission = Color(1, 0, 0)

    _box(Vector3(1.8, 0.5, 4.0), Vector3(0, 0.15, 0), body_mat)
    _box(Vector3(1.5, 0.45, 1.9), Vector3(0, 0.62, 0.3), glass)
    _box(Vector3(1.7, 0.08, 0.4), Vector3(0, 0.78, 1.85), body_mat)
    _box(Vector3(0.4, 0.15, 0.05), Vector3(-0.6, 0.2, -2.0), head)
    _box(Vector3(0.4, 0.15, 0.05), Vector3(0.6, 0.2, -2.0), head)
    _box(Vector3(0.5, 0.12, 0.05), Vector3(-0.55, 0.3, 2.0), tail)
    _box(Vector3(0.5, 0.12, 0.05), Vector3(0.55, 0.3, 2.0), tail)
    for x in [-0.95, 0.95]:
        for z in [-1.3, 1.3]:
            var w := MeshInstance3D.new()
            var c := CylinderMesh.new()
            c.top_radius = 0.38
            c.bottom_radius = 0.38
            c.height = 0.3
            w.mesh = c
            w.material_override = tire
            w.rotation_degrees.z = 90
            w.position = Vector3(x, -0.05, z)
            add_child(w)

    smoke = CPUParticles3D.new()
    smoke.amount = 40
    smoke.lifetime = 1.2
    smoke.local_coords = false
    smoke.direction = Vector3(0, 1, 0.5)
    smoke.spread = 25.0
    smoke.initial_velocity_min = 1.0
    smoke.initial_velocity_max = 3.0
    smoke.gravity = Vector3(0, 0.5, 0)
    smoke.scale_amount_min = 1.0
    smoke.scale_amount_max = 2.5
    var sm := SphereMesh.new()
    sm.radius = 0.3
    sm.height = 0.6
    var smat := StandardMaterial3D.new()
    smat.albedo_color = Color(0.85, 0.85, 0.85, 0.45)
    smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    sm.material = smat
    smoke.mesh = sm
    smoke.position = Vector3(0, -0.1, 1.5)
    smoke.emitting = false
    add_child(smoke)

func _box(size: Vector3, pos: Vector3, mat: Material) -> void:
    var m := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = size
    m.mesh = b
    m.position = pos
    m.material_override = mat
    add_child(m)

func set_color(c: Color) -> void:
    body_mat.albedo_color = c

func _physics_process(delta: float) -> void:
    if throttle > 0.0 and not braking:
        speed += accel * throttle * (1.0 - clampf(speed / max_speed, 0.0, 1.0)) * delta
    if braking:
        if speed > 0.5:
            speed = move_toward(speed, 0.0, brake_force * delta)
        else:
            speed = move_toward(speed, -12.0, 14.0 * delta)
    elif throttle <= 0.0:
        speed = move_toward(speed, 0.0, 4.0 * delta)

    var s := clampf(speed / 12.0, -1.0, 1.0)
    rotation.y -= steer * turn_rate * s / (1.0 + absf(speed) / 60.0) * delta

    var g := grip * (0.25 if drift else 1.0)
    if drift:
        lateral -= steer * speed * 0.25 * delta
        speed = move_toward(speed, 0.0, absf(lateral) * 0.25 * delta)
    lateral = lerpf(lateral, 0.0, clampf(g * delta, 0.0, 1.0))

    var fwd := -global_transform.basis.z
    var right := global_transform.basis.x
    velocity = fwd * speed + right * lateral
    var before := speed
    move_and_slide()
    if get_slide_collision_count() > 0:
        speed = velocity.dot(fwd)
        lateral = velocity.dot(right)
        var impact := absf(before - speed)
        speed *= 0.98
        if impact > 3.0:
            crashed.emit(impact)
    position.y = 0.5
    smoke.emitting = absf(lateral) > 2.5 and speed > 10.0
