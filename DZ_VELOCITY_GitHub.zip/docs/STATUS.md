# Status (read this before releasing)

## Not verified
This version was written and packaged **without a Godot editor, emulator or device available**. Nothing here has been
run. The GDScript was reviewed by hand only. First steps after pushing:
1. Let the GitHub Action finish. Check the **lint** job log for parse errors and the debug APK job for export errors.
2. Install the APK on a phone. Check: launcher name and icon, boot splash, menu, Career stage 1, Free Drive, Car Battle arena 1.
3. Send me the log or a screenshot of anything that breaks and I will fix it.

## Implemented (untested)
Rebrand, icon set, Free Drive, Car Battle (5 arenas), credits, translations for new text, CI workflow, export presets.

## Not done in this pass
- AAA environment overhaul, PBR/LOD/occlusion work, new vegetation, reflection upgrades.
- Martyrs' Memorial (Maqam Echahid) and Casbah landmark models: not built. Needs a modelling pass.
- Garage visual customisation (paint/wheels/spoilers/suspension height). The garage still has the original engine/handling/nitro upgrades.
- Physics retune per vehicle class, new camera modes (the original 3 camera modes remain).
- New racing activities: time trial, drift challenges, championship, daily challenges.
- Per-class engine sounds, new SFX, independent sliders beyond what Settings already has.
- "Custom" graphics preset (Auto / Low / Medium / High exist).
- Arabic right-to-left layout and a bundled Arabic font. Arabic text relies on the phone's system font.
- Screenshots / video of the running game.
- Free Drive uses the single Algiers route (no side streets, no intersections).
