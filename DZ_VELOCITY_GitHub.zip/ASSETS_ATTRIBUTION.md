# Third-party assets (DZ VELOCITY)

| Asset | Source | License | Files in project |
|---|---|---|---|
| PavingStones142 (2K PNG set) | ambientCG | CC0 1.0 | textures/sidewalk/paving_*_1k.* (resized 2K -> 1K) |
| citrus_orchard_road_puresky (4K EXR) | Poly Haven (file header names the Poly Haven pipeline) | CC0 1.0 | sky/puresky_morning_2k.hdr (resampled 4K -> 2K) |
| Map data | OpenStreetMap contributors | ODbL | maps/algiers.json (already in V3) |

The uploaded files carried no license text. CC0 is what these two sites publish for these asset types
(ambientCG and Poly Haven), but please confirm on the asset pages before release:
https://ambientcg.com/view?id=PavingStones142  and  https://polyhaven.com/a/citrus_orchard_road_puresky
Attribution is not required under CC0; this file is kept as a record.
