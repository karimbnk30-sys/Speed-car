extends Node
## Garage: browse cars, buy them, upgrade engine / handling / nitro, pick the one you race with.
const ShowroomScript := preload("res://scripts/showroom.gd")
const CarScript := preload("res://scripts/car.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const Tr := preload("res://scripts/tr.gd")
const UPGRADES := ["engine", "handling", "nitro"]
const UP_LABELS := {"engine": "ENGINE", "handling": "HANDLING", "nitro": "NITRO"}

var idx := 0
var showroom
var name_label: Label
var money_label: Label
var sel_btn: Button
var msg_label: Label
var bars := {}
var up_btns := {}

func _ready() -> void:
    Audio.play_music("music_menu")
    idx = int(Save.get_in("garage.selected", 0)) % CarScript.MODELS.size()
    showroom = ShowroomScript.new()
    showroom.model_index = idx
    showroom.orbit_speed = 0.3
    add_child(showroom)
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var sz := get_viewport().get_visible_rect().size
    var ins := UIUtil.safe_insets(get_viewport())

    var title := UIUtil.make_label(Tr.t("GARAGE"), 60, Color(0.1, 1.0, 0.35))
    title.position = Vector2(ins.x, ins.y)
    root.add_child(title)
    money_label = UIUtil.make_label("", 34, Color(0.3, 1.0, 0.5))
    money_label.position = Vector2(sz.x - ins.z - 420.0, ins.y + 12.0)
    money_label.size = Vector2(420, 50)
    money_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    root.add_child(money_label)
    name_label = UIUtil.make_label("", 48, Color.WHITE)
    name_label.position = Vector2(ins.x, ins.y + 80.0)
    root.add_child(name_label)

    # stat bars
    var y := ins.y + 150.0
    for k in ["SPEED", "ACCEL", "HANDLING"]:
        var l := UIUtil.make_label(Tr.t(k), 24, Color(0.8, 0.9, 1.0))
        l.position = Vector2(ins.x, y)
        root.add_child(l)
        var pb := ProgressBar.new()
        pb.show_percentage = false
        pb.max_value = 1.0
        pb.position = Vector2(ins.x + 190.0, y + 8.0)
        pb.size = Vector2(260, 16)
        pb.add_theme_stylebox_override("background", UIUtil.box(Color(0.05, 0.06, 0.1, 0.8), Color(0.0, 0.5, 0.6), 2))
        pb.add_theme_stylebox_override("fill", UIUtil.box(Color(0.1, 1.0, 0.35), Color(0.1, 1.0, 0.35), 0))
        root.add_child(pb)
        bars[k] = pb
        y += 40.0

    # upgrade buttons (bottom-left column)
    var uy := y + 14.0
    for k in UPGRADES:
        var ub := UIUtil.make_button("", Color(1.0, 0.8, 0.2), Vector2(470, 66))
        ub.add_theme_font_size_override("font_size", 24)
        ub.position = Vector2(ins.x, uy)
        var key: String = k
        ub.pressed.connect(func(): _upgrade(key))
        root.add_child(ub)
        up_btns[k] = ub
        uy += 74.0

    var prev := UIUtil.make_button("<", Color(0.9, 0.3, 1.0), Vector2(110, 110))
    prev.position = Vector2(sz.x * 0.5 - 330.0, sz.y * 0.5 - 20.0)
    prev.pressed.connect(func(): _step(-1))
    root.add_child(prev)
    var nxt := UIUtil.make_button(">", Color(0.9, 0.3, 1.0), Vector2(110, 110))
    nxt.position = Vector2(sz.x - ins.z - 110.0, sz.y * 0.5 - 20.0)
    nxt.pressed.connect(func(): _step(1))
    root.add_child(nxt)

    sel_btn = UIUtil.make_button("", Color(0.2, 1.0, 0.4), Vector2(360, 84))
    sel_btn.position = Vector2(sz.x - ins.z - 360.0, sz.y - ins.w - 84.0)
    sel_btn.pressed.connect(_choose)
    root.add_child(sel_btn)
    var back := UIUtil.make_button(Tr.t("BACK"), Color(1.0, 0.3, 0.35), Vector2(220, 76))
    back.position = Vector2(ins.x, sz.y - ins.w - 76.0)
    back.pressed.connect(func():
        Save.save()
        get_tree().change_scene_to_file("res://scenes/menu.tscn"))
    root.add_child(back)
    msg_label = UIUtil.make_label("", 28, Color(1.0, 0.5, 0.4))
    msg_label.position = Vector2(sz.x * 0.5 - 300.0, sz.y - ins.w - 150.0)
    msg_label.size = Vector2(600, 40)
    msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    root.add_child(msg_label)
    _refresh()

func _step(dir: int) -> void:
    var n := CarScript.MODELS.size()
    idx = (idx + dir + n) % n
    showroom.set_model(idx)
    msg_label.text = ""
    _refresh()

func _choose() -> void:
    var price := int(CarScript.STATS[idx]["price"])
    if not Save.owns(idx):
        if Save.buy_car(idx, price):
            Save.set_in("garage.selected", idx)
            Save.save()
            msg_label.text = ""
        else:
            msg_label.text = Tr.t("NOT ENOUGH MONEY")
    else:
        Save.set_in("garage.selected", idx)
        Save.save()
    _refresh()

func _upgrade(key: String) -> void:
    if Save.buy_upgrade(idx, key):
        msg_label.text = ""
    else:
        msg_label.text = Tr.t("NOT ENOUGH MONEY")
    _refresh()

func _refresh() -> void:
    var st: Dictionary = CarScript.STATS[idx]
    var cs: Dictionary = CarScript.stats_for(idx)
    var owned := Save.owns(idx)
    var money := int(Save.get_in("profile.money", 0))
    name_label.text = str(st["name"])
    money_label.text = Tr.t("MONEY") + "  %d" % money
    (bars["SPEED"] as ProgressBar).value = clampf((float(cs["max"]) - 60.0) / 25.0, 0.0, 1.0)
    (bars["ACCEL"] as ProgressBar).value = clampf((float(cs["acc"]) - 16.0) / 14.0, 0.0, 1.0)
    (bars["HANDLING"] as ProgressBar).value = clampf((float(cs["turn"]) - 1.4) / 1.0, 0.0, 1.0)
    for k in UPGRADES:
        var b: Button = up_btns[k]
        var lvl := Save.upgrade_level(idx, k)
        if lvl >= 5:
            b.text = "%s  %d/5  -  %s" % [Tr.t(UP_LABELS[k]), lvl, Tr.t("MAX")]
            b.disabled = true
        else:
            b.text = "%s  %d/5  -  %s %d" % [Tr.t(UP_LABELS[k]), lvl, Tr.t("UPGRADE"), Save.upgrade_cost(idx, k)]
            b.disabled = not owned
    var chosen := int(Save.get_in("garage.selected", 0)) == idx
    if not owned:
        sel_btn.text = "%s  %d" % [Tr.t("BUY"), int(st["price"])]
        sel_btn.disabled = false
    else:
        sel_btn.text = Tr.t("SELECTED") if chosen else Tr.t("SELECT")
        sel_btn.disabled = chosen
