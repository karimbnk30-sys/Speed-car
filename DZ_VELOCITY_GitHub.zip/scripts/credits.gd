extends Node
## Credits screen: game credits + third-party asset notices.
const ShowroomScript := preload("res://scripts/showroom.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const Tr := preload("res://scripts/tr.gd")
const GREEN := Color(0.1, 1.0, 0.35)

func _ready() -> void:
    Audio.play_music("music_menu")
    var sr := ShowroomScript.new()
    sr.model_index = int(Save.get_in("garage.selected", 0))
    sr.orbit_speed = 0.1
    add_child(sr)
    var layer := CanvasLayer.new()
    add_child(layer)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.72)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(dim)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var sz := get_viewport().get_visible_rect().size
    var ins := UIUtil.safe_insets(get_viewport())
    var title := UIUtil.make_label("DZ VELOCITY", 64, GREEN)
    title.position = Vector2(ins.x, ins.y)
    root.add_child(title)
    var ver := UIUtil.make_label("v" + str(ProjectSettings.get_setting("application/config/version", "1.0.0")) + "  -  " + Tr.t("CREDITS"), 28, Color.WHITE)
    ver.position = Vector2(ins.x + 4.0, ins.y + 80.0)
    root.add_child(ver)
    var body := UIUtil.make_label(_text(), 28, Color.WHITE)
    body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    body.custom_minimum_size = Vector2(sz.x - ins.x - ins.z - 40.0, 0)
    var scroll := ScrollContainer.new()
    scroll.position = Vector2(ins.x, ins.y + 130.0)
    scroll.size = Vector2(sz.x - ins.x - ins.z, sz.y - ins.y - ins.w - 130.0 - 100.0)
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    root.add_child(scroll)
    scroll.add_child(body)
    var back := UIUtil.make_button(Tr.t("BACK"), Color(1.0, 0.2, 0.25), Vector2(220, 76))
    back.position = Vector2(ins.x, sz.y - ins.w - 76.0)
    back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/menu.tscn"))
    root.add_child(back)

func _text() -> String:
    return "DZ VELOCITY\nALGIERS  -  ALGERIA\n\n" \
        + "Racing - Free Drive - Car Battle\n\n" \
        + "MAP DATA\nOpenStreetMap contributors (ODbL)\n\n" \
        + "TEXTURES AND SKY\nambientCG (PavingStones142) - CC0\nPoly Haven (citrus_orchard_road_puresky) - CC0\n\n" \
        + "ENGINE\nGodot Engine (MIT License)\n\n" \
        + "Full third-party list: ASSETS_ATTRIBUTION.md in the project."
