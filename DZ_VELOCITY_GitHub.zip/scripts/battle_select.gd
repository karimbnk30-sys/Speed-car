extends Node
## CAR BATTLE arena select: horizontally scrolling cards, each arena unlocks after the previous one is cleared.
const ShowroomScript := preload("res://scripts/showroom.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const Tr := preload("res://scripts/tr.gd")
const BD := preload("res://scripts/battle_data.gd")
const CARD := Vector2(300, 400)
const RED := Color(1.0, 0.2, 0.25)

func _ready() -> void:
    Audio.play_music("music_menu")
    var sr := ShowroomScript.new()
    sr.model_index = int(Save.get_in("garage.selected", 0))
    sr.orbit_speed = 0.12
    add_child(sr)
    var layer := CanvasLayer.new()
    add_child(layer)
    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.03, 0.62)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(dim)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var sz := get_viewport().get_visible_rect().size
    var ins := UIUtil.safe_insets(get_viewport())
    var title := UIUtil.make_label(Tr.t("CAR BATTLE") + "  -  " + Tr.t("DESERT ARENA"), 52, RED)
    title.position = Vector2(ins.x, ins.y)
    root.add_child(title)
    var money := UIUtil.make_label(Tr.t("MONEY") + "  %d" % int(Save.get_in("profile.money", 0)), 34, Color(0.3, 1.0, 0.5))
    money.position = Vector2(sz.x - ins.z - 330.0, ins.y + 12.0)
    money.size = Vector2(330, 50)
    money.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    root.add_child(money)
    var scroll := ScrollContainer.new()
    scroll.position = Vector2(ins.x, ins.y + 90.0)
    scroll.size = Vector2(sz.x - ins.x - ins.z, CARD.y + 30.0)
    scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
    root.add_child(scroll)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 22)
    scroll.add_child(row)
    for i in BD.COUNT:
        row.add_child(_card(i))
    var back := UIUtil.make_button(Tr.t("BACK"), RED, Vector2(220, 76))
    back.position = Vector2(ins.x, sz.y - ins.w - 76.0)
    back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/menu.tscn"))
    root.add_child(back)

func _card(i: int) -> Button:
    var a: Dictionary = BD.get_arena(i)
    var open := BD.is_unlocked(i)
    var col := RED
    var lines := Tr.t("ARENA %d") % (i + 1) + "\n\n" + str(a["name"]) + "\n\n"
    if str(a["mode"]) == "survive":
        lines += Tr.t("SURVIVE %d s") % int(float(a["time"]))
    else:
        lines += Tr.t("LAST CAR STANDING")
    lines += "\n" + Tr.t("ENEMIES") + "  %d" % int(a["bots"])
    if open:
        if BD.is_cleared(i):
            lines += "\n\n" + Tr.t("CLEARED")
            col = Color(1.0, 0.85, 0.2)
            var bt := BD.best_time(i)
            if bt > 0.0:
                lines += "\n%02d:%05.2f" % [int(bt / 60.0), fmod(bt, 60.0)]
        else:
            lines += "\n\n" + Tr.t("NEW") + "\n" + Tr.t("PRIZE") + "  %d" % int(a["reward"])
            col = Color(0.3, 1.0, 0.5)
    else:
        lines += "\n\n" + Tr.t("LOCKED") + "\n" + Tr.t("Clear arena %d") % i
        col = Color(0.45, 0.47, 0.52)
    var b := UIUtil.make_button(lines, col, CARD)
    b.add_theme_font_size_override("font_size", 26)
    b.disabled = not open
    b.add_theme_color_override("font_disabled_color", col)
    b.add_theme_stylebox_override("disabled", UIUtil.box(Color(0.04, 0.05, 0.09, 0.55), col, 2))
    b.pressed.connect(func():
        Save.battle_stage = i
        get_tree().change_scene_to_file("res://scenes/battle.tscn"))
    return b
