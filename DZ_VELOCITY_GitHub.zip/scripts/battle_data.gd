extends RefCounted
## CAR BATTLE - DESERT ARENA: stage list. Fictional arcade arenas, separate from the Algiers road network.
## Rewards use the normal game economy (profile.money, garage.owned, garage.upgrades).

const COUNT := 5

# mode: "survive" (stay operational for `time` seconds) or "last" (last operational vehicle wins)
# fog: sand haze density, dust: sandstorm particles, rocks: obstacle count, player_dmg: damage multiplier on the player
const LIST := [
    {"name": "DESERT TRAINING",    "mode": "survive", "time": 60.0, "bots": 2, "skill": 0.55, "R": 55.0, "rocks": 0,  "fog": 0.0006, "dust": 0.0, "player_dmg": 0.8, "sky": "day",   "reward": 1500,  "unlock_car": -1, "bonus_up": ""},
    {"name": "SANDSTORM ARENA",    "mode": "last",    "time": 0.0,  "bots": 4, "skill": 0.65, "R": 75.0, "rocks": 4,  "fog": 0.013,  "dust": 1.0, "player_dmg": 1.0, "sky": "storm", "reward": 3000,  "unlock_car": -1, "bonus_up": "handling"},
    {"name": "ROCKY BATTLEFIELD",  "mode": "last",    "time": 0.0,  "bots": 4, "skill": 0.72, "R": 70.0, "rocks": 18, "fog": 0.0012, "dust": 0.0, "player_dmg": 1.0, "sky": "sunset", "reward": 4500, "unlock_car": 2,  "bonus_up": ""},
    {"name": "EXTREME ARENA",      "mode": "last",    "time": 0.0,  "bots": 5, "skill": 0.85, "R": 80.0, "rocks": 10, "fog": 0.0025, "dust": 0.35, "player_dmg": 1.25, "sky": "day",  "reward": 7000,  "unlock_car": -1, "bonus_up": "engine"},
    {"name": "LAST CAR STANDING",  "mode": "last",    "time": 0.0,  "bots": 7, "skill": 0.95, "R": 95.0, "rocks": 12, "fog": 0.003,  "dust": 0.2, "player_dmg": 1.15, "sky": "sunset", "reward": 12000, "unlock_car": 1,  "bonus_up": "nitro"},
]

static func get_arena(i: int) -> Dictionary:
    return LIST[clampi(i, 0, COUNT - 1)]

static func is_unlocked(i: int) -> bool:
    return i <= int(Save.get_in("progress.battle_unlocked", 0))

static func is_cleared(i: int) -> bool:
    return bool(Save.get_in("progress.battle_clear.%d" % i, false))

static func best_time(i: int) -> float:
    return float(Save.get_in("progress.battle_best.%d" % i, 0.0))

static func total_cleared() -> int:
    var n := 0
    for i in COUNT:
        if is_cleared(i):
            n += 1
    return n
