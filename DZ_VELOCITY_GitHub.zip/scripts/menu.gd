extends Node
## DZ VELOCITY main menu: CAREER, FREE DRIVE, CAR BATTLE, GARAGE, SETTINGS, CREDITS, EXIT.
const ShowroomScript := preload("res://scripts/showroom.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const Tr := preload("res://scripts/tr.gd")

const GREEN := Color(0.1, 1.0, 0.35)
const RED := Color(1.0, 0.2, 0.25)

var root: Control
var free_panel: Control
var theme_pick := "day"
var rain_pick := false

func _ready() -> void:
    Audio.play_music("music_menu")
    var sr := ShowroomScript.new()
    sr.model_index = int(Save.get_in("garage.selected", 0))
    sr.orbit_speed = 0.2
    add_child(sr)
    var layer := CanvasLayer.new()
    add_child(layer)
    root = Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var ins := UIUtil.safe_insets(get_viewport())
    var title := UIUtil.make_label("DZ VELOCITY", 72, GREEN)
    title.position = Vector2(ins.x, ins.y)
    root.add_child(title)
    var sub := UIUtil.make_label("ALGIERS  -  ALGERIA", 24, Color.WHITE)
    sub.position = Vector2(ins.x + 4.0, ins.y + 92.0)
    root.add_child(sub)

    var grid := GridContainer.new()
    grid.columns = 2
    grid.add_theme_constant_override("h_separation", 16)
    grid.add_theme_constant_override("v_separation", 14)
    grid.set_anchors_preset(Control.PRESET_CENTER_LEFT)
    grid.position = Vector2(ins.x, 40)
    grid.grow_vertical = Control.GROW_DIRECTION_BOTH
    root.add_child(grid)
    var sz := Vector2(330, 78)
    _add(grid, "CAREER", GREEN, sz, func(): get_tree().change_scene_to_file("res://scenes/stage_select.tscn"))
    _add(grid, "FREE DRIVE", Color.WHITE, sz, _open_free)
    _add(grid, "CAR BATTLE", RED, sz, func(): get_tree().change_scene_to_file("res://scenes/battle_select.tscn"))
    _add(grid, "GARAGE", GREEN, sz, func(): get_tree().change_scene_to_file("res://scenes/garage.tscn"))
    _add(grid, "SETTINGS", Color.WHITE, sz, func(): get_tree().change_scene_to_file("res://scenes/settings.tscn"))
    _add(grid, "CREDITS", Color.WHITE, sz, func(): get_tree().change_scene_to_file("res://scenes/credits.tscn"))
    _add(grid, "EXIT", RED, sz, func():
        Save.save()
        get_tree().quit())

    var st := UIUtil.make_label(_stats_text(), 26, Color.WHITE)
    st.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    st.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    st.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    st.grow_vertical = Control.GROW_DIRECTION_BEGIN
    st.position = Vector2(-ins.z, -ins.w)
    root.add_child(st)
    var ver := UIUtil.make_label("v" + str(ProjectSettings.get_setting("application/config/version", "1.0.0")), 20, Color(1, 1, 1, 0.6))
    ver.position = Vector2(ins.x, get_viewport().get_visible_rect().size.y - ins.w - 30.0)
    root.add_child(ver)

func _add(parent: Control, key: String, col: Color, size: Vector2, cb: Callable) -> void:
    var b := UIUtil.make_button(Tr.t(key), col, size)
    b.add_theme_font_size_override("font_size", 30)
    b.pressed.connect(cb)
    parent.add_child(b)

# ---- Free Drive setup: time of day + weather, then START ----
func _open_free() -> void:
    if free_panel != null:
        return
    free_panel = Control.new()
    free_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.78)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    free_panel.add_child(dim)
    root.add_child(free_panel)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 14)
    col.set_anchors_preset(Control.PRESET_CENTER)
    col.grow_horizontal = Control.GROW_DIRECTION_BOTH
    col.grow_vertical = Control.GROW_DIRECTION_BOTH
    col.alignment = BoxContainer.ALIGNMENT_CENTER
    free_panel.add_child(col)
    var t := UIUtil.make_label(Tr.t("FREE DRIVE"), 56, GREEN)
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(t)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 12)
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_child(row)
    var opts := {"day": "DAY", "sunset": "SUNSET", "night": "NIGHT"}
    var btns := {}
    for k in opts:
        var b := UIUtil.make_button(Tr.t(opts[k]), Color.WHITE, Vector2(220, 76))
        b.add_theme_font_size_override("font_size", 28)
        b.pressed.connect(func():
            theme_pick = k
            _refresh_pick(btns))
        row.add_child(b)
        btns[k] = b
    var rain := UIUtil.make_button("", Color.WHITE, Vector2(360, 76))
    rain.add_theme_font_size_override("font_size", 28)
    rain.pressed.connect(func():
        rain_pick = not rain_pick
        _refresh_pick(btns))
    btns["rain"] = rain
    col.add_child(rain)
    _refresh_pick(btns)
    var go := UIUtil.make_button(Tr.t("START"), GREEN, Vector2(360, 84))
    go.pressed.connect(func():
        Save.mode = "free"
        Save.free_theme = theme_pick
        Save.free_rain = rain_pick
        get_tree().change_scene_to_file("res://scenes/main.tscn"))
    col.add_child(go)
    var back := UIUtil.make_button(Tr.t("BACK"), RED, Vector2(360, 70))
    back.pressed.connect(func():
        free_panel.queue_free()
        free_panel = null)
    col.add_child(back)
    for c in col.get_children():
        if c is Button:
            (c as Button).size_flags_horizontal = Control.SIZE_SHRINK_CENTER

func _refresh_pick(btns: Dictionary) -> void:
    for k in ["day", "sunset", "night"]:
        var b: Button = btns[k]
        b.add_theme_color_override("font_color", GREEN if theme_pick == k else Color.WHITE)
    var r: Button = btns["rain"]
    r.text = Tr.t("RAIN") + ":  " + Tr.t("ON" if rain_pick else "OFF")
    r.add_theme_color_override("font_color", GREEN if rain_pick else Color.WHITE)

func _stats_text() -> String:
    var fmt := Tr.t("RACES WON") + "  %d\n" + Tr.t("TOP SPEED") + "  %d km/h\n" + Tr.t("TOTAL DISTANCE") + "  %.1f km\n" + Tr.t("MONEY") + "  %d"
    return fmt % [
        int(float(Save.get_in("stats.wins", 0.0))),
        int(float(Save.get_in("stats.best_speed", 0.0))),
        float(Save.get_in("stats.total_distance", 0.0)) / 1000.0,
        int(Save.get_in("profile.money", 0))]
