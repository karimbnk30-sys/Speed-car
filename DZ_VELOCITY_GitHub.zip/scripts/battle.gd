extends Node3D
## CAR BATTLE - DESERT ARENA. Arcade vehicle battles in a sandy arena (fictional, arcade-only).
## Uses the same car.gd physics as racing. Durability, 4 visual damage stages, AI bots, rewards.
const CarScript := preload("res://scripts/car.gd")
const HudScript := preload("res://scripts/hud.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const Tr := preload("res://scripts/tr.gd")
const BD := preload("res://scripts/battle_data.gd")

const CAM_OFFSETS := [Vector3(0, 3.2, 8.0), Vector3(0, 5.5, 13.0), Vector3(0, 1.2, 0.3)]
const BOT_NAMES := ["KARIM", "YACINE", "SOFIANE", "AMINE", "NADIR", "WALID", "RAYAN", "SAMIR"]
const GREEN := Color(0.1, 1.0, 0.35)
const RED := Color(1.0, 0.2, 0.25)
const MAX_DUR := 100.0
const STAGE_NAMES := ["OK", "MINOR DAMAGE", "MODERATE DAMAGE", "SEVERE DAMAGE", "DISABLED"]

var idx := 0
var arena: Dictionary
var R := 60.0
var player
var cars: Array = []          # every vehicle, player first
var alive: Array = []         # vehicles still in the fight
var st := {}                  # car -> state dictionary
var hud
var cam: Camera3D
var sun: DirectionalLight3D
var state := "countdown"      # countdown | fight | won | lost | results
var state_time := 0.0
var fight_time := 0.0
var kos := 0
var cd_step := -1
var cam_mode := 0
var cam_snap := true
var shake := 0.0
var steer_smooth := 0.0
var steer_sens := 1.0
var use_tilt := false
var touches := {}
var held := {}
var beeps := {}
var quality := "medium"
var dur_bar: ProgressBar
var dur_label: Label
var obj_label: Label
var stage_label: Label
var result_panel: Control
var puffs: Array = []
var puff_i := 0
var debris: Array = []
var debris_i := 0
var tag_timer := 0.0
var finish_angle := 0.0
var rocks: Array = []
var load_layer: CanvasLayer

func _ready() -> void:
    randomize()
    idx = clampi(Save.battle_stage, 0, BD.COUNT - 1)
    arena = BD.get_arena(idx)
    R = float(arena["R"])
    _build_environment()
    _build_ground()
    _build_walls()
    _build_stands()
    _build_rocks()
    _build_pools()
    _spawn_cars()
    _build_ui()
    _build_sounds()
    _apply_quality()
    _build_dust()
    get_tree().paused = false
    Audio.play_music("music_race")
    hud.toast("%s  -  %s" % [Tr.t("ARENA %d") % (idx + 1), arena["name"]], RED)

# ---------------------------------------------------------------- environment
func _build_environment() -> void:
    var env := Environment.new()
    var sky_mat := ProceduralSkyMaterial.new()
    var kind := str(arena["sky"])
    var sun_col := Color(1.0, 0.92, 0.8)
    var sun_e := 1.5
    match kind:
        "storm":
            sky_mat.sky_top_color = Color(0.62, 0.45, 0.3)
            sky_mat.sky_horizon_color = Color(0.85, 0.62, 0.4)
            sky_mat.ground_horizon_color = Color(0.85, 0.62, 0.4)
            sky_mat.ground_bottom_color = Color(0.55, 0.4, 0.25)
            sun_col = Color(1.0, 0.75, 0.5)
            sun_e = 0.9
            env.fog_light_color = Color(0.82, 0.6, 0.38)
        "sunset":
            sky_mat.sky_top_color = Color(0.25, 0.3, 0.6)
            sky_mat.sky_horizon_color = Color(1.0, 0.6, 0.35)
            sky_mat.ground_horizon_color = Color(0.95, 0.55, 0.35)
            sky_mat.ground_bottom_color = Color(0.45, 0.3, 0.2)
            sun_col = Color(1.0, 0.6, 0.35)
            sun_e = 1.6
            env.fog_light_color = Color(0.95, 0.62, 0.45)
        _:
            sky_mat.sky_top_color = Color(0.22, 0.5, 0.9)
            sky_mat.sky_horizon_color = Color(0.85, 0.8, 0.7)
            sky_mat.ground_horizon_color = Color(0.85, 0.75, 0.6)
            sky_mat.ground_bottom_color = Color(0.6, 0.48, 0.32)
            env.fog_light_color = Color(0.85, 0.75, 0.6)
    var sky := Sky.new()
    sky.sky_material = sky_mat
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.9
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_density = float(arena["fog"])
    env.fog_sky_affect = 0.6
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48.0, -35.0, 0.0)
    sun.light_color = sun_col
    sun.light_energy = sun_e
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 130.0
    add_child(sun)

func _build_ground() -> void:
    var noise := FastNoiseLite.new()
    noise.frequency = 0.035
    var nt := NoiseTexture2D.new()
    nt.noise = noise
    nt.seamless = true
    nt.width = 256
    nt.height = 256
    var grad := Gradient.new()
    grad.colors = PackedColorArray([Color(0.72, 0.56, 0.34), Color(0.93, 0.8, 0.55)])
    grad.offsets = PackedFloat32Array([0.0, 1.0])
    nt.color_ramp = grad
    var mat := StandardMaterial3D.new()
    mat.albedo_texture = nt
    mat.uv1_scale = Vector3(30, 30, 1)
    mat.roughness = 1.0
    var plane := PlaneMesh.new()
    plane.size = Vector2(R * 2.0 + 420.0, R * 2.0 + 420.0)
    plane.material = mat
    var mi := MeshInstance3D.new()
    mi.mesh = plane
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)
    # decorative dunes beyond the arena (no collision: the arena floor itself is flat)
    var dune_mat := StandardMaterial3D.new()
    dune_mat.albedo_color = Color(0.86, 0.7, 0.45)
    dune_mat.roughness = 1.0
    var dm := SphereMesh.new()
    dm.radius = 1.0
    dm.height = 2.0
    dm.radial_segments = 14
    dm.rings = 7
    dm.material = dune_mat
    for i in 20:
        var a := randf() * TAU
        var d := R + randf_range(30.0, 110.0)
        var n := MeshInstance3D.new()
        n.mesh = dm
        n.position = Vector3(sin(a) * d, -1.0, cos(a) * d)
        n.scale = Vector3(randf_range(22.0, 48.0), randf_range(5.0, 12.0), randf_range(22.0, 48.0))
        n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(n)

func _build_walls() -> void:
    var n := int(TAU * R / 8.0)
    var seg_len := TAU * R / float(n) + 0.4
    var mat_a := StandardMaterial3D.new()
    mat_a.albedo_color = Color(0.9, 0.15, 0.18)
    var mat_b := StandardMaterial3D.new()
    mat_b.albedo_color = Color(0.95, 0.95, 0.95)
    var bm := BoxMesh.new()
    bm.size = Vector3(seg_len, 1.7, 1.2)
    var shape := BoxShape3D.new()
    shape.size = Vector3(seg_len, 3.0, 1.2)
    for i in n:
        var a := TAU * float(i) / float(n)
        var body := StaticBody3D.new()
        body.position = Vector3(sin(a) * R, 0.85, cos(a) * R)
        body.rotation.y = a
        var mi := MeshInstance3D.new()
        mi.mesh = bm
        mi.material_override = mat_a if (i % 2 == 0) else mat_b
        body.add_child(mi)
        var cs := CollisionShape3D.new()
        cs.shape = shape
        body.add_child(cs)
        add_child(body)

func _build_stands() -> void:
    var step_mat := StandardMaterial3D.new()
    step_mat.albedo_color = Color(0.35, 0.36, 0.4)
    var n := int(TAU * (R + 9.0) / 10.0)
    var crowd := MultiMesh.new()
    crowd.transform_format = MultiMesh.TRANSFORM_3D
    crowd.use_colors = true
    var cap := CapsuleMesh.new()
    cap.radius = 0.28
    cap.height = 1.1
    cap.radial_segments = 6
    cap.rings = 2
    var cmat := StandardMaterial3D.new()
    cmat.vertex_color_use_as_albedo = true
    cap.material = cmat
    crowd.mesh = cap
    var per_row := n * 2
    crowd.instance_count = per_row * 3
    var palette := [Color(0.1, 0.8, 0.3), Color(0.95, 0.95, 0.95), Color(0.9, 0.15, 0.2), Color(0.95, 0.75, 0.2), Color(0.2, 0.3, 0.9)]
    var ci := 0
    for row in 3:
        var rad := R + 7.0 + float(row) * 3.2
        var h := 1.0 + float(row) * 1.3
        var sm := BoxMesh.new()
        sm.size = Vector3(TAU * rad / float(n) + 0.5, h, 3.0)
        for i in n:
            var a := TAU * float(i) / float(n)
            var step := MeshInstance3D.new()
            step.mesh = sm
            step.material_override = step_mat
            step.position = Vector3(sin(a) * rad, h * 0.5, cos(a) * rad)
            step.rotation.y = a
            step.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
            add_child(step)
        for k in per_row:
            var a2 := TAU * (float(k) + randf()) / float(per_row)
            var p := Vector3(sin(a2) * (rad + randf_range(-0.8, 0.8)), h + 0.55, cos(a2) * (rad + randf_range(-0.8, 0.8)))
            crowd.set_instance_transform(ci, Transform3D(Basis(), p))
            crowd.set_instance_color(ci, palette[randi() % palette.size()])
            ci += 1
    var cmi := MultiMeshInstance3D.new()
    cmi.multimesh = crowd
    cmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(cmi)
    # banners
    for q in 4:
        var a3 := TAU * float(q) / 4.0 + 0.4
        var lb := Label3D.new()
        lb.text = "DZ VELOCITY\nCAR BATTLE"
        lb.font_size = 96
        lb.pixel_size = 0.03
        lb.modulate = GREEN
        lb.outline_modulate = Color(0, 0, 0, 1)
        lb.outline_size = 16
        lb.position = Vector3(sin(a3) * (R + 14.0), 9.0, cos(a3) * (R + 14.0))
        lb.rotation.y = a3 + PI
        add_child(lb)

func _build_rocks() -> void:
    var count := int(arena["rocks"])
    if count <= 0:
        return
    var rock_mat := StandardMaterial3D.new()
    rock_mat.albedo_color = Color(0.45, 0.36, 0.28)
    rock_mat.roughness = 0.95
    var tries := 0
    while rocks.size() < count and tries < 400:
        tries += 1
        var a := randf() * TAU
        var d := randf_range(R * 0.18, R * 0.82)
        var rad := randf_range(2.0, 4.6)
        var p := Vector2(sin(a) * d, cos(a) * d)
        var ok := true
        # keep the spawn ring (0.55 R) clear of rocks
        if absf(d - R * 0.55) < rad + 7.0:
            ok = false
        for r in rocks:
            if (r["p"] as Vector2).distance_to(p) < rad + float(r["r"]) + 7.0:
                ok = false
        if not ok:
            continue
        var h := randf_range(3.0, 6.5)
        rocks.append({"p": p, "r": rad})
        var body := StaticBody3D.new()
        body.position = Vector3(p.x, h * 0.5, p.y)
        body.rotation.y = randf() * TAU
        var cm := CylinderMesh.new()
        cm.bottom_radius = rad
        cm.top_radius = rad * 0.6
        cm.height = h
        cm.radial_segments = 8
        cm.rings = 1
        cm.material = rock_mat
        var mi := MeshInstance3D.new()
        mi.mesh = cm
        body.add_child(mi)
        var cs := CollisionShape3D.new()
        var cyl := CylinderShape3D.new()
        cyl.radius = rad * 0.92
        cyl.height = h
        cs.shape = cyl
        body.add_child(cs)
        add_child(body)

# ---------------------------------------------------------------- pooled effects
func _build_pools() -> void:
    var pm := SphereMesh.new()
    pm.radius = 0.5
    pm.height = 1.0
    pm.radial_segments = 6
    pm.rings = 3
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.85, 0.7, 0.45, 0.5)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    pm.material = mat
    for i in 6:
        var p := CPUParticles3D.new()
        p.amount = 14
        p.lifetime = 0.9
        p.one_shot = true
        p.explosiveness = 1.0
        p.local_coords = false
        p.direction = Vector3(0, 1, 0)
        p.spread = 70.0
        p.initial_velocity_min = 3.0
        p.initial_velocity_max = 7.0
        p.gravity = Vector3(0, -3.0, 0)
        p.scale_amount_min = 0.8
        p.scale_amount_max = 2.2
        p.mesh = pm
        p.emitting = false
        p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(p)
        puffs.append(p)
    var dmesh := BoxMesh.new()
    dmesh.size = Vector3(0.45, 0.14, 0.7)
    var dmat := StandardMaterial3D.new()
    dmat.albedo_color = Color(0.1, 0.1, 0.12)
    dmat.metallic = 0.6
    dmesh.material = dmat
    for i in 16:
        var m := MeshInstance3D.new()
        m.mesh = dmesh
        m.visible = false
        m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(m)
        debris.append({"n": m, "v": Vector3.ZERO, "life": 0.0})

func _puff(pos: Vector3) -> void:
    var p: CPUParticles3D = puffs[puff_i % puffs.size()]
    puff_i += 1
    p.global_position = Vector3(pos.x, 0.4, pos.z)
    p.restart()
    p.emitting = true

func _debris(pos: Vector3, n: int) -> void:
    for k in n:
        var d: Dictionary = debris[debris_i % debris.size()]
        debris_i += 1
        var node: MeshInstance3D = d["n"]
        node.global_position = pos + Vector3(0, 0.8, 0)
        node.visible = true
        d["v"] = Vector3(randf_range(-6.0, 6.0), randf_range(4.0, 8.0), randf_range(-6.0, 6.0))
        d["life"] = 2.5

func _build_dust() -> void:
    var amt := float(arena["dust"])
    if amt <= 0.0:
        return
    var p := CPUParticles3D.new()
    p.amount = int(60.0 * amt) if quality == "low" else int(140.0 * amt)
    p.lifetime = 3.0
    p.local_coords = false
    p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    p.emission_box_extents = Vector3(38.0, 4.0, 38.0)
    p.direction = Vector3(1, 0, 0.3)
    p.spread = 15.0
    p.initial_velocity_min = 14.0
    p.initial_velocity_max = 22.0
    p.gravity = Vector3.ZERO
    var q := QuadMesh.new()
    q.size = Vector2(9, 9)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.85, 0.65, 0.4, 0.11)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mat.no_depth_test = false
    q.material = mat
    p.mesh = q
    p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    p.position = Vector3(0, 3, -10)
    cam.add_child(p)
    p.emitting = true

# ---------------------------------------------------------------- cars
func _spawn_cars() -> void:
    var total := 1 + int(arena["bots"])
    var sel := int(Save.get_in("garage.selected", 0)) % CarScript.MODELS.size()
    player = CarScript.new()
    add_child(player)
    player.set_model(sel)
    player.apply_stats(sel)
    player.racer_name = "YOU"
    player.rcolor = GREEN
    player.sfx_vol = Audio.sfx_volume()
    player.sound_on = float(Save.get_in("settings.audio_master", 1.0)) > 0.0
    _register(player, "YOU", sel)
    var names: Array = BOT_NAMES.duplicate()
    names.shuffle()
    for i in range(1, total):
        var b = CarScript.new()
        add_child(b)
        var mi := (sel + i) % CarScript.MODELS.size()
        var hue := fmod(float(i) * 0.137 + 0.05, 1.0)
        b.set_model(mi, hue)
        b.apply_stats(mi)
        var sk := float(arena["skill"]) * randf_range(0.92, 1.05)
        b.max_speed *= (0.6 + 0.4 * clampf(sk, 0.0, 1.05))
        b.accel *= (0.7 + 0.3 * clampf(sk, 0.0, 1.05))
        b.racer_name = str(names[i % names.size()])
        b.rcolor = Color.from_hsv(hue, 0.8, 1.0)
        b.sound_on = false
        for p in b.sfx.values():
            (p as AudioStreamPlayer).stop()
        _register(b, b.racer_name, mi)
        (st[b] as Dictionary)["skill"] = clampf(sk, 0.3, 1.05)
    for i in cars.size():
        var a := TAU * float(i) / float(cars.size()) + 0.3
        var c = cars[i]
        c.position = Vector3(sin(a) * R * 0.55, 0.5, cos(a) * R * 0.55)
        c.rotation.y = a
    cam = Camera3D.new()
    cam.far = 900.0
    cam.near = 0.1
    add_child(cam)
    cam.current = true

func _register(c, nm: String, model_i: int) -> void:
    cars.append(c)
    alive.append(c)
    var s := {"dur": MAX_DUR, "stage": 0, "name": nm, "alive": true, "hit_cd": 0.0, "last_by": null,
        "target": null, "retarget": 0.0, "stuck": 0.0, "rev_t": 0.0, "rev_steer": 1.0, "skill": 0.7,
        "base_max": c.max_speed, "base_acc": c.accel, "lights": [], "tag": null}
    # headlight meshes (they go dark as the car is damaged)
    var lmat := StandardMaterial3D.new()
    lmat.albedo_color = Color(1.0, 0.95, 0.8)
    lmat.emission_enabled = true
    lmat.emission = Color(1.0, 0.95, 0.75)
    lmat.emission_energy_multiplier = 2.0
    lmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    var lm := BoxMesh.new()
    lm.size = Vector3(0.4, 0.15, 0.06)
    lm.material = lmat
    for sx in [-0.65, 0.65]:
        var l := MeshInstance3D.new()
        l.mesh = lm
        l.position = Vector3(sx, 0.55, -2.1)
        l.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        c.add_child(l)
        (s["lights"] as Array).append(l)
    # scratch / paint-damage overlay (alpha grows with each damage stage)
    var om := StandardMaterial3D.new()
    om.albedo_color = Color(0.04, 0.03, 0.02, 0.0)
    om.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    om.roughness = 1.0
    s["overlay"] = om
    if c.model != null:
        for n in c.model.find_children("*", "MeshInstance3D", true, false):
            (n as MeshInstance3D).material_overlay = om
    # damage smoke / fire
    var dm := CPUParticles3D.new()
    dm.amount = 24
    dm.lifetime = 1.4
    dm.local_coords = false
    dm.direction = Vector3(0, 1, 0)
    dm.spread = 20.0
    dm.initial_velocity_min = 1.5
    dm.initial_velocity_max = 3.5
    dm.gravity = Vector3(0, 1.0, 0)
    dm.scale_amount_min = 0.8
    dm.scale_amount_max = 2.0
    var sm := SphereMesh.new()
    sm.radius = 0.3
    sm.height = 0.6
    sm.radial_segments = 6
    sm.rings = 3
    var smat := StandardMaterial3D.new()
    smat.albedo_color = Color(0.1, 0.1, 0.1, 0.55)
    smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    sm.material = smat
    dm.mesh = sm
    dm.position = Vector3(0, 0.9, -1.4)
    dm.emitting = false
    dm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    c.add_child(dm)
    s["dsmoke"] = dm
    st[c] = s
    c.crashed.connect(_on_crashed.bind(c))
    if c != player:
        var tag := Label3D.new()
        tag.font_size = 56
        tag.pixel_size = 0.012
        tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        tag.outline_modulate = Color(0, 0, 0, 0.9)
        tag.outline_size = 12
        tag.position = Vector3(0, 2.3, 0)
        tag.visibility_range_end = 120.0
        tag.modulate = c.rcolor
        c.add_child(tag)
        s["tag"] = tag
        _refresh_tag(c)

func _refresh_tag(c) -> void:
    var s: Dictionary = st[c]
    var tag: Label3D = s["tag"]
    if tag == null:
        return
    tag.text = "%s  %d%%" % [s["name"], int(ceilf(float(s["dur"])))]

# ---------------------------------------------------------------- damage system
func _stage_for(dur: float) -> int:
    if dur <= 0.0:
        return 4
    var r := dur / MAX_DUR
    if r > 0.75:
        return 0
    if r > 0.5:
        return 1
    if r > 0.25:
        return 2
    return 3

func _hurt(c, amount: float, attacker) -> void:
    var s: Dictionary = st[c]
    if not bool(s["alive"]) or state != "fight":
        return
    var mult := float(arena["player_dmg"]) if c == player else 1.0
    s["dur"] = maxf(float(s["dur"]) - amount * mult, 0.0)
    if attacker != null:
        s["last_by"] = attacker
    _apply_visual(c)
    _refresh_tag(c)
    if float(s["dur"]) <= 0.0:
        _eliminate(c)

func _apply_visual(c) -> void:
    var s: Dictionary = st[c]
    var dur := float(s["dur"])
    var stage := _stage_for(dur)
    c.damage = 1.0 - dur / MAX_DUR              # car.gd already slows a damaged car (-25% top speed, -20% accel)
    var extra := 1.0 - 0.1 * float(maxi(mini(stage, 3) - 1, 0))   # stage 2 and 3 cost extra performance
    c.max_speed = float(s["base_max"]) * extra
    c.accel = float(s["base_acc"]) * extra
    if stage <= int(s["stage"]):
        return
    s["stage"] = stage
    var k := mini(stage, 3)
    var om: StandardMaterial3D = s["overlay"]
    om.albedo_color.a = [0.0, 0.2, 0.4, 0.62][k]
    if c.model != null:
        var sgn := 1.0 if (int(hash(s["name"])) % 2 == 0) else -1.0
        c.model.scale = Vector3.ONE * CarScript.MODEL_SCALE * Vector3(1.0 - 0.035 * float(k), 1.0 - 0.03 * float(k), 1.0 + 0.012 * float(k))
        c.model.rotation = Vector3(0.012 * float(k) * sgn, -PI / 2.0, 0.022 * float(k) * sgn)
    var lights: Array = s["lights"]
    if stage >= 3 and lights.size() > 0:
        (lights[0] as MeshInstance3D).visible = false
    if stage >= 4:
        for l in lights:
            (l as MeshInstance3D).visible = false
    if stage >= 2:
        (s["dsmoke"] as CPUParticles3D).emitting = true
    if stage >= 2 and stage <= 3:
        _debris(c.global_position, 3 + stage)
    if c == player and stage <= 3:
        hud.toast("%s  (%d/3)" % [Tr.t(STAGE_NAMES[stage]), stage], Color(1.0, 0.7, 0.2) if stage < 3 else RED)

func _eliminate(c) -> void:
    var s: Dictionary = st[c]
    s["alive"] = false
    alive.erase(c)
    c.throttle = 0.0
    c.braking = false
    c.drift = false
    c.boosting = false
    c.steer = 0.0
    c.speed = 0.0
    c.lateral = 0.0
    c.collision_layer = 0
    c.collision_mask = 0
    c.smoke.emitting = true
    c.set_physics_process(false)             # wreck stays where it stopped (engine + movement disabled)
    _debris(c.global_position, 8)
    _puff(c.global_position)
    var tag = s["tag"]
    if tag != null:
        (tag as Label3D).text = "%s  %s" % [s["name"], Tr.t("DISABLED")]
        (tag as Label3D).modulate = Color(0.6, 0.6, 0.6)
    var fire := CPUParticles3D.new()
    fire.amount = 18
    fire.lifetime = 0.9
    fire.local_coords = false
    fire.direction = Vector3(0, 1, 0)
    fire.spread = 15.0
    fire.initial_velocity_min = 1.5
    fire.initial_velocity_max = 3.0
    var fm := SphereMesh.new()
    fm.radius = 0.22
    fm.height = 0.44
    fm.radial_segments = 6
    fm.rings = 3
    var fmat := StandardMaterial3D.new()
    fmat.albedo_color = Color(1.0, 0.45, 0.1, 0.7)
    fmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    fmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    fm.material = fmat
    fire.mesh = fm
    fire.position = Vector3(0, 0.9, -1.4)
    fire.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    c.add_child(fire)
    fire.emitting = true
    if c == player:
        hud.toast(Tr.t("YOU ARE DISABLED"), RED)
        _finish("lost")
        return
    if s["last_by"] == player:
        kos += 1
        hud.toast("%s  %s" % [s["name"], Tr.t("ELIMINATED")], GREEN)
    else:
        hud.toast("%s  %s" % [s["name"], Tr.t("ELIMINATED")], Color(1.0, 0.8, 0.2))
    if player.sound_on:
        player._play_crash(14.0)

func _on_crashed(force: float, c) -> void:
    var s: Dictionary = st[c]
    if float(s["hit_cd"]) > 0.0 or not bool(s["alive"]):
        return
    if force > 6.0:
        s["hit_cd"] = 0.25
        _hurt(c, minf(force * 0.45, 14.0), null)
        _puff(c.global_position)
    if c == player:
        shake = clampf(force * 0.02, 0.1, 0.8)
        if bool(Save.get_in("settings.vibration", true)):
            Input.vibrate_handheld(clampi(int(force * 8.0), 30, 200))

func _vel(c) -> Vector3:
    var f: Vector3 = -c.global_transform.basis.z
    var r: Vector3 = c.global_transform.basis.x
    return f * float(c.speed) + r * float(c.lateral)

# car-vs-car impacts: damage by closing speed (the rammer takes less, the one hit takes more), knockback, dust, debris
func _check_pairs() -> void:
    var snap: Array = alive.duplicate()     # cars can be eliminated mid-loop
    var n := snap.size()
    for i in n:
        for j in range(i + 1, n):
            var a = snap[i]
            var b = snap[j]
            var sa: Dictionary = st[a]
            var sb: Dictionary = st[b]
            if not bool(sa["alive"]) or not bool(sb["alive"]):
                continue
            if float(sa["hit_cd"]) > 0.0 or float(sb["hit_cd"]) > 0.0:
                continue
            var d: Vector3 = a.global_position - b.global_position
            d.y = 0.0
            var dist := d.length()
            if dist > 4.3 or dist < 0.01:
                continue
            var nrm: Vector3 = d / dist           # from b to a
            var va: Vector3 = _vel(a)
            var vb: Vector3 = _vel(b)
            var closing := -(va - vb).dot(nrm)
            if closing < 3.0:
                continue
            var ca := maxf(va.dot(-nrm), 0.0)     # a drives into b
            var cb := maxf(vb.dot(nrm), 0.0)      # b drives into a
            var tot := ca + cb + 0.1
            var base := closing * 0.8
            sa["hit_cd"] = 0.4
            sb["hit_cd"] = 0.4
            _hurt(a, base * (0.35 + 0.65 * cb / tot), b)
            _hurt(b, base * (0.35 + 0.65 * ca / tot), a)
            var imp := clampf(closing * 0.35, 2.0, 10.0)
            for pair in [[a, nrm], [b, -nrm]]:
                var c = pair[0]
                var dir: Vector3 = pair[1]
                c.lateral += dir.dot(c.global_transform.basis.x) * imp
                c.speed += dir.dot(-c.global_transform.basis.z) * imp * 0.5
                c.global_position += dir * 0.3
                c.sparks.restart()
                c.sparks.emitting = true
            var mid: Vector3 = (a.global_position + b.global_position) * 0.5
            _puff(mid)
            if closing > 8.0:
                _debris(mid, 2)
            if a == player or b == player:
                shake = clampf(closing * 0.03, 0.15, 0.9)
                if player.sound_on:
                    player._play_crash(closing)
                if bool(Save.get_in("settings.vibration", true)):
                    Input.vibrate_handheld(clampi(int(closing * 8.0), 30, 200))

# ---------------------------------------------------------------- AI
func _drive_bot(c, delta: float) -> void:
    var s: Dictionary = st[c]
    if state != "fight":
        c.throttle = 0.0
        c.braking = false
        c.steer = 0.0
        return
    if float(s["rev_t"]) > 0.0:
        s["rev_t"] = float(s["rev_t"]) - delta
        c.braking = true
        c.throttle = 0.0
        c.steer = float(s["rev_steer"])
        return
    s["retarget"] = float(s["retarget"]) - delta
    var tgt = s["target"]
    if tgt == null or not bool(st[tgt]["alive"]) or float(s["retarget"]) <= 0.0:
        s["retarget"] = randf_range(0.8, 1.6)
        var best = null
        var best_d := INF
        for o in alive:
            if o == c:
                continue
            var dd: float = c.global_position.distance_to(o.global_position)
            if o == player:
                dd *= 0.8                     # bots lean toward the player
            if dd < best_d:
                best_d = dd
                best = o
        tgt = best
        s["target"] = tgt
    if tgt == null:
        c.throttle = 0.0
        c.braking = false
        return
    var pos: Vector3 = c.global_position
    var aim: Vector3 = tgt.global_position + _vel(tgt) * 0.35
    if Vector2(pos.x, pos.z).length() > R - 10.0:
        aim = Vector3.ZERO                    # near the wall: head back toward the middle
    var to: Vector3 = aim - pos
    to.y = 0.0
    var dist := to.length()
    if dist < 0.1:
        return
    var dir: Vector3 = to / dist
    var fwd: Vector3 = -c.global_transform.basis.z
    var right: Vector3 = c.global_transform.basis.x
    var side := dir.dot(right)
    var ahead := dir.dot(fwd)
    var want := clampf(side * 2.6, -1.0, 1.0)
    if ahead < 0.0:
        want = 1.0 if side >= 0.0 else -1.0
    c.steer = move_toward(float(c.steer), want, 5.0 * delta)
    c.throttle = 1.0
    c.braking = false
    c.drift = false
    c.boosting = ahead > 0.92 and dist > 25.0 and float(s["skill"]) > 0.8
    if absf(float(c.speed)) < 2.0:
        s["stuck"] = float(s["stuck"]) + delta
    else:
        s["stuck"] = 0.0
    if float(s["stuck"]) > 1.0:
        s["stuck"] = 0.0
        s["rev_t"] = 0.9
        s["rev_steer"] = 1.0 if randf() < 0.5 else -1.0

# ---------------------------------------------------------------- frame loop
func _physics_process(delta: float) -> void:
    state_time += delta
    for c in cars:
        var s: Dictionary = st[c]
        s["hit_cd"] = maxf(float(s["hit_cd"]) - delta, 0.0)
    match state:
        "countdown":
            var t := state_time - 1.2
            var step := int(floorf(t))
            if t >= 0.0 and step != cd_step:
                cd_step = step
                if step <= 2:
                    hud.big(str(3 - step), Color(1.0, 0.9, 0.2))
                    _beep("lo")
                else:
                    hud.big(Tr.t("FIGHT!"), RED)
                    hud.hide_big(0.9)
                    _beep("hi")
                    state = "fight"
                    state_time = 0.0
        "fight":
            fight_time += delta
            _check_pairs()
            _check_end()
    for c in alive:
        if c != player:
            _drive_bot(c, delta)

func _check_end() -> void:
    if state != "fight":
        return
    var bots_left := alive.size() - (1 if bool(st[player]["alive"]) else 0)
    if bool(st[player]["alive"]):
        if bots_left <= 0:
            _finish("won")
        elif str(arena["mode"]) == "survive" and fight_time >= float(arena["time"]):
            _finish("won")

func _finish(result: String) -> void:
    if state == "won" or state == "lost" or state == "results":
        return
    state = result
    state_time = 0.0
    hud.set_buttons_visible(false)
    player.throttle = 0.0
    player.braking = false
    player.boosting = false
    player.drift = false
    player.steer = 0.0
    hud.big(Tr.t("VICTORY!") if result == "won" else Tr.t("DEFEAT"), GREEN if result == "won" else RED)

func _process(delta: float) -> void:
    _read_input(delta)
    _update_debris(delta)
    _update_camera(delta)
    _update_hud(delta)
    if (state == "won" or state == "lost") and state_time > 2.6:
        _show_results()

func _update_debris(delta: float) -> void:
    for d in debris:
        var life := float(d["life"])
        if life <= 0.0:
            continue
        var node: MeshInstance3D = d["n"]
        life -= delta
        d["life"] = life
        if life <= 0.0:
            node.visible = false
            continue
        var v: Vector3 = d["v"]
        v.y -= 16.0 * delta
        node.global_position += v * delta
        if node.global_position.y < 0.1:
            node.global_position.y = 0.1
            v = Vector3.ZERO
        node.rotation += Vector3(3.0, 2.0, 1.0) * delta * (1.0 if v != Vector3.ZERO else 0.0)
        d["v"] = v

# ---------------------------------------------------------------- input
func _input(e: InputEvent) -> void:
    if hud == null:
        return
    if e is InputEventScreenTouch:
        if e.pressed:
            touches[e.index] = e.position
            _tap(e.position)
        else:
            touches.erase(e.index)
    elif e is InputEventScreenDrag:
        touches[e.index] = e.position

func _hit(id: String, pos: Vector2) -> bool:
    return (hud.btns[id] as Control).get_global_rect().has_point(pos)

func _tap(pos: Vector2) -> void:
    if _hit("pause", pos):
        _pause()
    elif _hit("cam", pos):
        cam_mode = (cam_mode + 1) % CAM_OFFSETS.size()
    elif _hit("snd", pos):
        player.sound_on = not player.sound_on
        Save.set_in("settings.audio_master", 1.0 if player.sound_on else 0.0)
    elif _hit("tilt", pos):
        use_tilt = not use_tilt
        Save.set_in("settings.control_scheme", "tilt" if use_tilt else "buttons")
        hud.toast(Tr.t("TILT STEERING ON") if use_tilt else Tr.t("BUTTON STEERING"), Color(0.9, 0.5, 1.0))

func _read_input(delta: float) -> void:
    for id in hud.btns:
        held[id] = false
    for p in touches.values():
        for id in hud.btns:
            if _hit(id, p):
                held[id] = true
    for id in hud.btns:
        (hud.btns[id] as Control).modulate = Color(1.7, 1.7, 1.7) if held[id] else Color.WHITE
    var gas: bool = held["gas"] or Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)
    var brk: bool = held["brake"] or Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN)
    var left: bool = held["left"] or Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT)
    var right: bool = held["right"] or Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)
    var target := 0.0
    if use_tilt:
        target = clampf(Input.get_accelerometer().y / 4.0 * steer_sens, -1.0, 1.0)
        if absf(target) < 0.08:
            target = 0.0
    else:
        target = (1.0 if right else 0.0) - (1.0 if left else 0.0)
    steer_smooth = move_toward(steer_smooth, target, 6.0 * steer_sens * delta)
    if state == "fight" and bool(st[player]["alive"]):
        player.steer = steer_smooth
        player.throttle = 1.0 if gas else 0.0
        player.braking = brk
        player.drift = held["drift"] or Input.is_key_pressed(KEY_SPACE)
        player.boosting = held["nitro"] or Input.is_key_pressed(KEY_SHIFT)
    else:
        player.steer = 0.0
        player.throttle = 0.0
        player.drift = false
        player.boosting = false
        player.braking = false

# ---------------------------------------------------------------- camera / HUD
func _update_camera(delta: float) -> void:
    if state == "won" or state == "lost" or state == "results":
        finish_angle += delta * 0.6
        var c: Vector3 = player.global_position
        var orbit := c + Vector3(cos(finish_angle) * 11.0, 4.0, sin(finish_angle) * 11.0)
        cam.global_position = cam.global_position.lerp(orbit, clampf(3.0 * delta, 0.0, 1.0))
        cam.look_at(c + Vector3.UP, Vector3.UP)
        cam.h_offset = 0.0
        cam.v_offset = 0.0
        return
    var off: Vector3 = CAM_OFFSETS[cam_mode]
    var target_pos: Vector3 = player.global_transform * off
    cam.global_position = target_pos if (cam_mode == 2 or cam_snap) else cam.global_position.lerp(target_pos, clampf(8.0 * delta, 0.0, 1.0))
    cam_snap = false
    var fwd: Vector3 = -player.global_transform.basis.z
    cam.look_at(player.global_position + fwd * 10.0 + Vector3.UP, Vector3.UP)
    var boost_fov := 9.0 if (player.boosting and player.nitro > 0.0 and player.throttle > 0.0) else 0.0
    cam.fov = lerpf(cam.fov, 70.0 + absf(float(player.speed)) * 0.25 + boost_fov, clampf(5.0 * delta, 0.0, 1.0))
    shake = move_toward(shake, 0.0, delta * 2.0)
    cam.h_offset = randf_range(-1.0, 1.0) * shake
    cam.v_offset = randf_range(-1.0, 1.0) * shake

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    hud = HudScript.new()
    var sz := get_viewport().get_visible_rect().size
    var ins := UIUtil.safe_insets(get_viewport())
    hud.build(layer, sz, ins)
    var line: Array[Vector2] = []
    for i in 49:
        var a := TAU * float(i) / 48.0
        line.append(Vector2(sin(a) * R, cos(a) * R))
    hud.setup_minimap(line)
    hud.time_label.visible = false
    hud.dist_label.visible = false
    for l in hud.board_labels:
        (l as Label).visible = false
    hud.pos_label.visible = false
    hud.use_mph = str(Save.get_in("settings.speed_unit", "kmh")) == "mph"
    use_tilt = str(Save.get_in("settings.control_scheme", "buttons")) == "tilt"
    steer_sens = float(Save.get_in("settings.steer_sensitivity", 1.0))
    # durability bar + objective (top centre)
    var w := 420.0
    var x := sz.x * 0.5 - w * 0.5
    dur_label = UIUtil.make_label(Tr.t("DURABILITY"), 24, Color.WHITE)
    dur_label.position = Vector2(x, ins.y - 4.0)
    hud.root.add_child(dur_label)
    dur_bar = ProgressBar.new()
    dur_bar.show_percentage = false
    dur_bar.max_value = MAX_DUR
    dur_bar.value = MAX_DUR
    dur_bar.position = Vector2(x, ins.y + 30.0)
    dur_bar.size = Vector2(w, 24)
    dur_bar.add_theme_stylebox_override("background", UIUtil.box(Color(0.05, 0.06, 0.1, 0.8), Color(1, 1, 1, 0.6), 2))
    dur_bar.add_theme_stylebox_override("fill", UIUtil.box(GREEN, GREEN, 0))
    hud.root.add_child(dur_bar)
    stage_label = UIUtil.make_label("", 22, Color(1.0, 0.8, 0.2))
    stage_label.position = Vector2(x, ins.y + 58.0)
    hud.root.add_child(stage_label)
    obj_label = UIUtil.make_label("", 40, Color.WHITE)
    obj_label.position = Vector2(ins.x, ins.y)
    hud.root.add_child(obj_label)

func _update_hud(delta: float) -> void:
    var kmh := absf(float(player.speed)) * 3.6
    hud.set_speed(kmh, player.nitro, clampf((kmh - 140.0) / 160.0, 0.0, 0.7))
    hud.set_damage(player.damage)
    var d := float(st[player]["dur"])
    dur_bar.value = d
    var col := GREEN if d > 50.0 else (Color(1.0, 0.75, 0.15) if d > 25.0 else RED)
    (dur_bar.get_theme_stylebox("fill") as StyleBoxFlat).bg_color = col
    stage_label.text = Tr.t(STAGE_NAMES[_stage_for(d)]) if _stage_for(d) > 0 else ""
    var bots_left := alive.size() - (1 if bool(st[player]["alive"]) else 0)
    if str(arena["mode"]) == "survive":
        var left := maxf(float(arena["time"]) - fight_time, 0.0)
        obj_label.text = "%s  %d s   |   %s  %d" % [Tr.t("SURVIVE"), int(ceilf(left)), Tr.t("ENEMIES"), bots_left]
    else:
        obj_label.text = "%s  %d" % [Tr.t("ENEMIES"), bots_left]
    tag_timer -= delta
    if tag_timer <= 0.0:
        tag_timer = 0.2
        hud.set_minimap_dots(alive, player)
    Save.add_stat("playtime", delta)

# ---------------------------------------------------------------- results + rewards
func _show_results() -> void:
    var won := state == "won"
    state = "results"
    hud.hide_big(0.1)
    var first_clear := won and not BD.is_cleared(idx)
    var reward := 0
    var notes: Array = []
    if won:
        reward = int(arena["reward"]) if first_clear else int(float(arena["reward"]) * 0.4)
    reward += kos * (150 if won else 50)
    Save.set_in("profile.money", int(Save.get_in("profile.money", 0)) + reward)
    if won:
        Save.set_in("progress.battle_clear.%d" % idx, true)
        var ob := BD.best_time(idx)
        if ob <= 0.0 or fight_time < ob:
            Save.set_in("progress.battle_best.%d" % idx, snappedf(fight_time, 0.01))
        if idx + 1 > int(Save.get_in("progress.battle_unlocked", 0)) and idx + 1 < BD.COUNT:
            Save.set_in("progress.battle_unlocked", idx + 1)
            notes.append(Tr.t("NEW ARENA UNLOCKED!"))
        if first_clear:
            notes.append(Tr.t("ARENA CLEARED") + ": " + str(arena["name"]))
            var uc := int(arena["unlock_car"])
            if uc >= 0 and not Save.owns(uc):
                var owned: Array = (Save.get_in("garage.owned", [0]) as Array).duplicate()
                owned.append(uc)
                Save.set_in("garage.owned", owned)
                notes.append(Tr.t("VEHICLE UNLOCKED") + ": " + str(CarScript.STATS[uc]["name"]))
            var up := str(arena["bonus_up"])
            if up != "":
                var sel := int(Save.get_in("garage.selected", 0))
                var lvl := Save.upgrade_level(sel, up)
                if lvl < 5:
                    Save.set_in("garage.upgrades.%d.%s" % [sel, up], lvl + 1)
                    notes.append(Tr.t("FREE UPGRADE") + ": " + Tr.t(up.to_upper()) + " " + str(lvl + 1) + "/5")
        Save.add_stat("battle_wins", 1.0)
    Save.add_stat("battle_kos", float(kos))
    Save.save()
    result_panel = Control.new()
    result_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
    result_panel.process_mode = Node.PROCESS_MODE_ALWAYS
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.72)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    result_panel.add_child(dim)
    hud.root.add_child(result_panel)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 12)
    col.set_anchors_preset(Control.PRESET_CENTER)
    col.grow_horizontal = Control.GROW_DIRECTION_BOTH
    col.grow_vertical = Control.GROW_DIRECTION_BOTH
    col.alignment = BoxContainer.ALIGNMENT_CENTER
    result_panel.add_child(col)
    var t := UIUtil.make_label(Tr.t("VICTORY!") if won else Tr.t("DEFEAT"), 72, GREEN if won else RED)
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(t)
    var info := "%s  %d     %s  %02d:%05.2f\n%s  +%d" % [Tr.t("KOS"), kos, Tr.t("TIME"), int(fight_time / 60.0), fmod(fight_time, 60.0), Tr.t("PRIZE"), reward]
    for n in notes:
        info += "\n" + str(n)
    var il := UIUtil.make_label(info, 30, Color.WHITE)
    il.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(il)
    if won and idx + 1 < BD.COUNT:
        var nb := UIUtil.make_button(Tr.t("NEXT"), GREEN, Vector2(380, 76))
        nb.pressed.connect(func():
            Save.battle_stage = idx + 1
            get_tree().reload_current_scene())
        nb.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
        col.add_child(nb)
    var rb := UIUtil.make_button(Tr.t("RETRY"), Color(1.0, 0.7, 0.2), Vector2(380, 76))
    rb.pressed.connect(func(): get_tree().reload_current_scene())
    rb.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    col.add_child(rb)
    var mb := UIUtil.make_button(Tr.t("MENU"), RED, Vector2(380, 76))
    mb.pressed.connect(_to_menu)
    mb.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    col.add_child(mb)

func _pause() -> void:
    if state == "results" or get_tree().paused:
        return
    touches.clear()
    get_tree().paused = true
    hud.show_pause(_resume, _restart, _to_menu)

func _resume() -> void:
    hud.hide_pause()
    get_tree().paused = false

func _restart() -> void:
    get_tree().paused = false
    Save.save()
    get_tree().reload_current_scene()

func _to_menu() -> void:
    get_tree().paused = false
    Save.save()
    get_tree().change_scene_to_file("res://scenes/battle_select.tscn")

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
        if hud != null and state != "results":
            _pause()

# ---------------------------------------------------------------- sound + quality
func _build_sounds() -> void:
    for k in ["lo", "hi"]:
        var p := AudioStreamPlayer.new()
        p.stream = _make_beep(440.0 if k == "lo" else 880.0, 0.18 if k == "lo" else 0.5)
        p.volume_db = -4.0
        add_child(p)
        beeps[k] = p
    var res = load("res://audio/wind.wav")
    if res != null:
        var w: AudioStreamWAV = res.duplicate()
        w.loop_mode = AudioStreamWAV.LOOP_FORWARD
        w.loop_begin = 0
        w.loop_end = w.data.size() >> 1
        var wp := AudioStreamPlayer.new()
        wp.stream = w
        var amb := 0.25 + 0.5 * float(arena["dust"])
        wp.volume_db = linear_to_db(maxf(amb * Audio.sfx_volume(), 0.0001)) - 6.0
        add_child(wp)
        wp.play()

func _make_beep(freq: float, dur: float) -> AudioStreamWAV:
    var rate := 22050
    var n := int(float(rate) * dur)
    var data := PackedByteArray()
    data.resize(n * 2)
    for i in n:
        var env := 1.0 - float(i) / float(n)
        var v := int(sin(TAU * freq * float(i) / float(rate)) * 12000.0 * env)
        data.encode_s16(i * 2, v)
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.data = data
    return w

func _beep(k: String) -> void:
    if beeps.has(k) and player.sound_on:
        (beeps[k] as AudioStreamPlayer).play()

func _apply_quality() -> void:
    var q := str(Save.get_in("settings.graphics_preset", "auto"))
    if q == "auto":
        q = "medium" if OS.has_feature("mobile") else "high"
    quality = q
    var vp := get_viewport()
    match q:
        "low":
            vp.msaa_3d = Viewport.MSAA_DISABLED
            vp.scaling_3d_scale = 0.7
            sun.shadow_enabled = false
            cam.far = 500.0
        "medium":
            vp.msaa_3d = Viewport.MSAA_DISABLED
            vp.scaling_3d_scale = 0.9
            cam.far = 700.0
        _:
            vp.msaa_3d = Viewport.MSAA_2X
            vp.scaling_3d_scale = 1.0
            cam.far = 900.0
    Engine.max_fps = int(Save.get_in("settings.fps_limit", 60))
