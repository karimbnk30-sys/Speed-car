extends Node
## Settings: graphics preset, fps limit, controls, steering sensitivity, audio, units, vibration, language.
const ShowroomScript := preload("res://scripts/showroom.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const Tr := preload("res://scripts/tr.gd")

const PRESETS := ["auto", "low", "medium", "high"]
const FPS_VALUES := [30, 60, 90, 120]
const SENS_VALUES := [0.6, 0.8, 1.0, 1.2, 1.4, 1.6]
const VOL_VALUES := [0.0, 0.25, 0.5, 0.75, 1.0]
const OPTIONS := ["graphics", "fps", "controls", "steer", "music", "sfx", "unit", "vibration", "language", "tutorial"]

var buttons := {}

func _ready() -> void:
    Audio.play_music("music_menu")
    var sr := ShowroomScript.new()
    sr.model_index = int(Save.get_in("garage.selected", 0))
    sr.orbit_speed = 0.1
    add_child(sr)
    var layer := CanvasLayer.new()
    add_child(layer)
    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.03, 0.7)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(dim)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var sz := get_viewport().get_visible_rect().size
    var ins := UIUtil.safe_insets(get_viewport())

    var title := UIUtil.make_label(Tr.t("SETTINGS"), 60, Color(0.1, 1.0, 0.35))
    title.position = Vector2(ins.x, ins.y)
    root.add_child(title)

    var grid := GridContainer.new()
    grid.columns = 2
    grid.add_theme_constant_override("h_separation", 20)
    grid.add_theme_constant_override("v_separation", 12)
    grid.position = Vector2(ins.x, ins.y + 90.0)
    root.add_child(grid)
    var bw := (sz.x - ins.x - ins.z - 20.0) / 2.0
    for o in OPTIONS:
        var b := UIUtil.make_button("", Color(0.1, 1.0, 0.35), Vector2(bw, 70))
        b.add_theme_font_size_override("font_size", 26)
        var key: String = o
        b.pressed.connect(func(): _cycle(key))
        grid.add_child(b)
        buttons[o] = b

    var back := UIUtil.make_button(Tr.t("BACK"), Color(1.0, 0.3, 0.35), Vector2(220, 76))
    back.position = Vector2(ins.x, sz.y - ins.w - 76.0)
    back.pressed.connect(func():
        Save.save()
        get_tree().change_scene_to_file("res://scenes/menu.tscn"))
    root.add_child(back)
    _refresh()

func _next_in(values: Array, current: Variant) -> Variant:
    var best := 0
    var best_d := INF
    for i in values.size():
        var d := absf(float(values[i]) - float(current))
        if d < best_d:
            best_d = d
            best = i
    return values[(best + 1) % values.size()]

func _cycle(key: String) -> void:
    match key:
        "graphics":
            var cur := str(Save.get_in("settings.graphics_preset", "auto"))
            var i := PRESETS.find(cur)
            Save.set_in("settings.graphics_preset", PRESETS[(i + 1) % PRESETS.size()])
        "fps":
            var v = _next_in(FPS_VALUES, Save.get_in("settings.fps_limit", 60))
            Save.set_in("settings.fps_limit", int(v))
            Engine.max_fps = int(v)
        "controls":
            var cur := str(Save.get_in("settings.control_scheme", "buttons"))
            Save.set_in("settings.control_scheme", "tilt" if cur == "buttons" else "buttons")
        "steer":
            Save.set_in("settings.steer_sensitivity", float(_next_in(SENS_VALUES, Save.get_in("settings.steer_sensitivity", 1.0))))
        "music":
            Save.set_in("settings.audio_music", float(_next_in(VOL_VALUES, Save.get_in("settings.audio_music", 0.7))))
            Audio.refresh()
        "sfx":
            Save.set_in("settings.audio_sfx", float(_next_in(VOL_VALUES, Save.get_in("settings.audio_sfx", 1.0))))
        "unit":
            var cur := str(Save.get_in("settings.speed_unit", "kmh"))
            Save.set_in("settings.speed_unit", "mph" if cur == "kmh" else "kmh")
        "vibration":
            var on := bool(Save.get_in("settings.vibration", true))
            Save.set_in("settings.vibration", not on)
            if not on:
                Input.vibrate_handheld(60)
        "language":
            var cur := Tr.lang()
            var i := Tr.LANGS.find(cur)
            Save.set_in("settings.language", Tr.LANGS[(i + 1) % Tr.LANGS.size()])
            Save.save()
            get_tree().reload_current_scene()
            return
        "tutorial":
            Save.set_in("settings.tutorial_done", false)
    _refresh()

func _refresh() -> void:
    var g := str(Save.get_in("settings.graphics_preset", "auto"))
    _set("graphics", Tr.t("GRAPHICS"), Tr.t(g.to_upper()))
    _set("fps", Tr.t("FPS LIMIT"), str(int(Save.get_in("settings.fps_limit", 60))))
    var scheme := str(Save.get_in("settings.control_scheme", "buttons"))
    _set("controls", Tr.t("CONTROLS"), Tr.t("TILT") if scheme == "tilt" else Tr.t("BUTTONS"))
    _set("steer", Tr.t("STEERING"), "%.1f" % float(Save.get_in("settings.steer_sensitivity", 1.0)))
    _set("music", Tr.t("MUSIC"), "%d%%" % int(round(float(Save.get_in("settings.audio_music", 0.7)) * 100.0)))
    _set("sfx", Tr.t("SOUND FX"), "%d%%" % int(round(float(Save.get_in("settings.audio_sfx", 1.0)) * 100.0)))
    var unit := str(Save.get_in("settings.speed_unit", "kmh"))
    _set("unit", Tr.t("SPEED UNIT"), Tr.t("MPH") if unit == "mph" else Tr.t("KM/H"))
    _set("vibration", Tr.t("VIBRATION"), Tr.t("ON") if bool(Save.get_in("settings.vibration", true)) else Tr.t("OFF"))
    _set("language", Tr.t("LANGUAGE"), str(Tr.LANG_NAMES[Tr.lang()]))
    var done := bool(Save.get_in("settings.tutorial_done", false))
    _set("tutorial", Tr.t("REPLAY TUTORIAL"), "" if not done else "<")

func _set(key: String, label: String, value: String) -> void:
    var b: Button = buttons[key]
    b.text = label if value == "" else "%s:  %s" % [label, value]
