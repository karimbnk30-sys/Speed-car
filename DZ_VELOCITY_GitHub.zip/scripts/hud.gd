extends RefCounted
## Builds and updates the race HUD (touch buttons, position, leaderboard, minimap, overlays).
const UIUtil := preload("res://scripts/ui_util.gd")
const Tr := preload("res://scripts/tr.gd")

const SPEED_FX := """shader_type canvas_item;
uniform float amount = 0.0;
uniform vec4 tint : source_color = vec4(0.6, 0.9, 1.0, 1.0);
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void fragment() {
    vec2 uv = UV - vec2(0.5);
    float r = length(uv) * 2.0;
    float a = atan(uv.y, uv.x);
    float line = hash(vec2(floor(a * 60.0), floor(TIME * 18.0)));
    float streak = step(0.86, line) * smoothstep(0.45, 1.1, r);
    float vig = smoothstep(0.75, 1.5, r) * 0.5;
    COLOR = vec4(tint.rgb, (streak * 0.55 + vig) * amount);
}
"""

# ---- minimap (drawn by hand) ----
class Mini extends Control:
    var line := PackedVector2Array()
    var dots: Array = []          # [{p: Vector2, c: Color, me: bool}]
    func _draw() -> void:
        draw_rect(Rect2(Vector2.ZERO, size), Color(0.03, 0.04, 0.08, 0.6), true)
        draw_rect(Rect2(Vector2.ZERO, size), Color(0.1, 1.0, 0.35, 0.8), false, 2.0)
        if line.size() > 1:
            draw_polyline(line, Color(0.85, 0.9, 1.0, 0.9), 3.0, true)
        for d in dots:
            var r := 7.0 if d["me"] else 4.5
            draw_circle(d["p"], r + 1.5, Color.BLACK)
            draw_circle(d["p"], r, d["c"])

var root: Control
var btns := {}
var pos_label: Label
var time_label: Label
var speed_label: Label
var unit_label: Label
var dist_label: Label
var board_labels: Array = []
var nitro_bar: ProgressBar
var big_label: Label
var toast_label: Label
var wrong_label: Label
var fx_mat: ShaderMaterial
var mini: Mini
var mini_origin := Vector2.ZERO
var mini_scale := 1.0
var pause_panel: Control
var tut_panel: Control
var use_mph := false
var damage_bar: ProgressBar
var drift_label: Label
var slip_label: Label
var flash_rect: ColorRect
var result_panel: Control
var _toast_tween: Tween

func build(layer: CanvasLayer, sz: Vector2, ins: Vector4) -> void:
    root = Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var L := ins.x
    var R := sz.x - ins.z
    var T := ins.y
    var B := sz.y - ins.w

    # speed lines overlay (under everything else)
    var fx := ColorRect.new()
    fx.set_anchors_preset(Control.PRESET_FULL_RECT)
    fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var sh := Shader.new()
    sh.code = SPEED_FX
    fx_mat = ShaderMaterial.new()
    fx_mat.shader = sh
    fx.material = fx_mat
    root.add_child(fx)

    # driving buttons
    _btn("left", "<", Vector2(L, B - 150), Vector2(150, 150))
    _btn("right", ">", Vector2(L + 170, B - 150), Vector2(150, 150))
    _btn("gas", "GAS", Vector2(R - 160, B - 170), Vector2(160, 170), Color(0.2, 1, 0.4))
    _btn("brake", "BRAKE", Vector2(R - 330, B - 120), Vector2(150, 120), Color(1, 0.2, 0.3))
    _btn("nitro", "NITRO", Vector2(R - 160, B - 300), Vector2(160, 110), Color(0.3, 0.6, 1.0))
    _btn("drift", "DRIFT", Vector2(R - 330, B - 250), Vector2(150, 110), Color(1, 0.6, 0.1))
    # small top-right buttons
    _btn("pause", "II", Vector2(R - 90, T), Vector2(90, 56), Color(1, 1, 1), 30)
    _btn("cam", "CAM", Vector2(R - 200, T), Vector2(100, 56), Color(0.9, 0.3, 1), 22)
    _btn("tilt", "TILT", Vector2(R - 310, T), Vector2(100, 56), Color(0.9, 0.3, 1), 22)
    _btn("snd", "SND", Vector2(R - 420, T), Vector2(100, 56), Color(0.9, 0.3, 1), 22)

    # position / timer / distance
    pos_label = UIUtil.make_label("8/8", 84, Color(1.0, 0.85, 0.2))
    pos_label.position = Vector2(L, T - 8)
    root.add_child(pos_label)
    time_label = UIUtil.make_label("00:00.00", 44, Color.WHITE)
    time_label.position = Vector2(sz.x / 2.0 - 110, T)
    root.add_child(time_label)
    dist_label = UIUtil.make_label("", 24, Color(0.8, 0.9, 1.0))
    dist_label.position = Vector2(sz.x / 2.0 - 110, T + 54)
    root.add_child(dist_label)

    # leaderboard
    for i in 8:
        var l := UIUtil.make_label("", 22, Color.WHITE)
        l.position = Vector2(L, T + 102 + i * 30)
        l.add_theme_constant_override("outline_size", 6)
        root.add_child(l)
        board_labels.append(l)

    # minimap
    mini = Mini.new()
    mini.position = Vector2(R - 210, T + 66)
    mini.size = Vector2(210, 210)
    mini.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(mini)

    # speed + nitro (bottom centre)
    speed_label = UIUtil.make_label("0", 72, Color(0.1, 1.0, 0.35))
    speed_label.custom_minimum_size = Vector2(220, 0)
    speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    speed_label.position = Vector2(sz.x / 2.0 - 110, B - 130)
    root.add_child(speed_label)
    unit_label = UIUtil.make_label("KM/H", 22, Color.WHITE)
    unit_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    unit_label.custom_minimum_size = Vector2(220, 0)
    unit_label.position = Vector2(sz.x / 2.0 - 110, B - 46)
    root.add_child(unit_label)
    nitro_bar = ProgressBar.new()
    nitro_bar.show_percentage = false
    nitro_bar.max_value = 1.0
    nitro_bar.position = Vector2(sz.x / 2.0 - 130, B - 18)
    nitro_bar.size = Vector2(260, 12)
    nitro_bar.add_theme_stylebox_override("background", UIUtil.box(Color(0.05, 0.06, 0.1, 0.8), Color(0.2, 0.4, 0.8), 2))
    nitro_bar.add_theme_stylebox_override("fill", UIUtil.box(Color(0.3, 0.65, 1.0), Color(0.3, 0.65, 1.0), 0))
    root.add_child(nitro_bar)

    # big centre text, toast, wrong way
    big_label = UIUtil.make_label("", 160, Color(1.0, 0.9, 0.2))
    big_label.position = Vector2(0.0, sz.y * 0.5 - 230.0)
    big_label.size = Vector2(sz.x, 220.0)
    big_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    big_label.add_theme_constant_override("outline_size", 16)
    root.add_child(big_label)
    toast_label = UIUtil.make_label("", 40, Color(0.2, 1.0, 0.5))
    toast_label.position = Vector2(0.0, T + 120.0)
    toast_label.size = Vector2(sz.x, 60.0)
    toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast_label.modulate.a = 0.0
    root.add_child(toast_label)
    wrong_label = UIUtil.make_label(Tr.t("WRONG WAY!"), 70, Color(1.0, 0.2, 0.2))
    wrong_label.position = Vector2(0.0, sz.y * 0.5 + 30.0)
    wrong_label.size = Vector2(sz.x, 90.0)
    wrong_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    wrong_label.visible = false
    root.add_child(wrong_label)

    # damage bar (above the steering buttons)
    var dl := UIUtil.make_label(Tr.t("DAMAGE"), 20, Color(1.0, 0.5, 0.4))
    dl.add_theme_constant_override("outline_size", 5)
    dl.position = Vector2(L, B - 206)
    root.add_child(dl)
    damage_bar = ProgressBar.new()
    damage_bar.show_percentage = false
    damage_bar.max_value = 1.0
    damage_bar.position = Vector2(L, B - 172)
    damage_bar.size = Vector2(240, 12)
    damage_bar.add_theme_stylebox_override("background", UIUtil.box(Color(0.05, 0.06, 0.1, 0.8), Color(0.6, 0.25, 0.2), 2))
    damage_bar.add_theme_stylebox_override("fill", UIUtil.box(Color(1.0, 0.35, 0.25), Color(1.0, 0.35, 0.25), 0))
    root.add_child(damage_bar)

    # drift score + slipstream notices
    drift_label = UIUtil.make_label("", 56, Color(1.0, 0.85, 0.2))
    drift_label.position = Vector2(0.0, sz.y * 0.5 + 120.0)
    drift_label.size = Vector2(sz.x, 70.0)
    drift_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    drift_label.visible = false
    root.add_child(drift_label)
    slip_label = UIUtil.make_label(Tr.t("SLIPSTREAM"), 36, Color(0.4, 0.9, 1.0))
    slip_label.position = Vector2(0.0, sz.y * 0.5 + 190.0)
    slip_label.size = Vector2(sz.x, 50.0)
    slip_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    slip_label.visible = false
    root.add_child(slip_label)

    # white flash (speed trap camera)
    flash_rect = ColorRect.new()
    flash_rect.color = Color(1, 1, 1, 0.0)
    flash_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
    flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(flash_rect)

func _btn(id: String, text: String, pos: Vector2, size: Vector2, color := Color(0.1, 1.0, 0.35), font := 28) -> void:
    var p := Panel.new()
    p.position = pos
    p.size = size
    p.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.05, 0.06, 0.1, 0.55)
    sb.border_color = color
    sb.set_border_width_all(3)
    sb.set_corner_radius_all(18)
    p.add_theme_stylebox_override("panel", sb)
    var l := Label.new()
    l.text = text
    l.set_anchors_preset(Control.PRESET_FULL_RECT)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.add_theme_font_size_override("font_size", font)
    l.add_theme_color_override("font_color", color)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    p.add_child(l)
    root.add_child(p)
    btns[id] = p

# ---- per-frame updates ----
func set_speed(kmh: float, nitro: float, fx_amount: float) -> void:
    speed_label.text = str(int(kmh * (0.621371 if use_mph else 1.0)))
    unit_label.text = Tr.t("MPH" if use_mph else "KM/H")
    nitro_bar.value = nitro
    fx_mat.set_shader_parameter("amount", clampf(fx_amount, 0.0, 1.0))

func set_time(t: float) -> void:
    time_label.text = fmt_time(t)

static func fmt_time(t: float) -> String:
    var m := int(t / 60.0)
    var s := fmod(t, 60.0)
    return "%02d:%05.2f" % [m, s]

func set_progress(place: int, total: int, remaining_m: float) -> void:
    pos_label.text = "%d/%d" % [place, total]
    pos_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.2) if place > 1 else Color(0.3, 1.0, 0.4))
    if use_mph:
        dist_label.text = Tr.t("%.2f mi left") % (maxf(remaining_m, 0.0) / 1609.34)
    else:
        dist_label.text = Tr.t("%.2f km left") % (maxf(remaining_m, 0.0) / 1000.0)

# board: sorted array of racers (first = leader)
func set_board(order: Array, player) -> void:
    for i in board_labels.size():
        var l: Label = board_labels[i]
        if i >= order.size():
            l.text = ""
            continue
        var r = order[i]
        var mark := ("  " + Tr.t("FIN")) if r.finished else ""
        l.text = "%d  #%d %s%s" % [i + 1, r.number, r.racer_name, mark]
        l.add_theme_color_override("font_color", Color(1.0, 0.9, 0.2) if r == player else Color(1, 1, 1, 0.85))

# fit the stage line into the minimap square (north-up)
func setup_minimap(line_pts: Array[Vector2]) -> void:
    var mn := Vector2(INF, INF)
    var mx := Vector2(-INF, -INF)
    for p in line_pts:
        mn = mn.min(p)
        mx = mx.max(p)
    var span := mx - mn
    var inner := mini.size - Vector2(24, 24)
    mini_scale = minf(inner.x / maxf(span.x, 1.0), inner.y / maxf(span.y, 1.0))
    mini_origin = mini.size * 0.5 - (mn + span * 0.5) * mini_scale
    var pl := PackedVector2Array()
    var step := maxi(line_pts.size() / 120, 1)
    for i in range(0, line_pts.size(), step):
        pl.append(line_pts[i] * mini_scale + mini_origin)
    pl.append(line_pts[line_pts.size() - 1] * mini_scale + mini_origin)
    mini.line = pl

func set_minimap_dots(racers: Array, player) -> void:
    var dots: Array = []
    for r in racers:
        var n: Node3D = r
        var p := Vector2(n.global_position.x, n.global_position.z) * mini_scale + mini_origin
        dots.append({"p": p, "c": r.rcolor, "me": r == player})
    # player drawn last (on top)
    dots.sort_custom(func(a, b): return (not a["me"]) and b["me"])
    mini.dots = dots
    mini.queue_redraw()

func set_wrong_way(on: bool) -> void:
    wrong_label.visible = on

func set_damage(d: float) -> void:
    damage_bar.value = d

func set_drift(points: int, combo: int) -> void:
    if points <= 0:
        drift_label.visible = false
        return
    drift_label.visible = true
    drift_label.text = "%s  %d   x%d" % [Tr.t("DRIFT"), points, combo]

func set_slipstream(on: bool) -> void:
    slip_label.visible = on

func flash() -> void:
    flash_rect.color.a = 0.75
    var t := flash_rect.create_tween()
    t.tween_property(flash_rect, "color:a", 0.0, 0.25)

func big(text: String, color := Color(1.0, 0.9, 0.2)) -> void:
    big_label.text = text
    big_label.add_theme_color_override("font_color", color)
    big_label.pivot_offset = big_label.size / 2.0
    big_label.scale = Vector2(1.4, 1.4)
    big_label.modulate.a = 1.0
    var t := big_label.create_tween()
    t.tween_property(big_label, "scale", Vector2.ONE, 0.25)

func hide_big(fade := 0.4) -> void:
    var t := big_label.create_tween()
    t.tween_property(big_label, "modulate:a", 0.0, fade)

func toast(text: String, color := Color(0.2, 1.0, 0.5)) -> void:
    toast_label.text = text
    toast_label.add_theme_color_override("font_color", color)
    if _toast_tween != null:
        _toast_tween.kill()
    toast_label.modulate.a = 1.0
    _toast_tween = toast_label.create_tween()
    _toast_tween.tween_interval(1.2)
    _toast_tween.tween_property(toast_label, "modulate:a", 0.0, 0.5)

func set_buttons_visible(on: bool) -> void:
    for id in ["left", "right", "gas", "brake", "nitro", "drift"]:
        (btns[id] as Control).visible = on

# ---- overlays (these use real Buttons; they keep working while the tree is paused) ----
func _overlay(color: Color) -> Control:
    var o := Control.new()
    o.set_anchors_preset(Control.PRESET_FULL_RECT)
    o.process_mode = Node.PROCESS_MODE_ALWAYS
    var dim := ColorRect.new()
    dim.color = color
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    o.add_child(dim)
    root.add_child(o)
    return o

func _column(parent: Control, width: float) -> VBoxContainer:
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 14)
    v.set_anchors_preset(Control.PRESET_CENTER)
    v.grow_horizontal = Control.GROW_DIRECTION_BOTH
    v.grow_vertical = Control.GROW_DIRECTION_BOTH
    v.custom_minimum_size = Vector2(width, 0)
    v.alignment = BoxContainer.ALIGNMENT_CENTER
    parent.add_child(v)
    return v

func show_pause(on_resume: Callable, on_restart: Callable, on_quit: Callable, on_garage: Callable = Callable()) -> void:
    hide_pause()
    pause_panel = _overlay(Color(0, 0, 0, 0.7))
    var col := _column(pause_panel, 420)
    var t := UIUtil.make_label(Tr.t("PAUSED"), 72, Color(0.1, 1.0, 0.35))
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(t)
    var b1 := UIUtil.make_button(Tr.t("RESUME"), Color(0.2, 1.0, 0.4))
    b1.pressed.connect(on_resume)
    col.add_child(b1)
    var b2 := UIUtil.make_button(Tr.t("RESTART"), Color(1.0, 0.7, 0.2))
    b2.pressed.connect(on_restart)
    col.add_child(b2)
    if on_garage.is_valid():
        var bg := UIUtil.make_button(Tr.t("GARAGE"), Color(1.0, 1.0, 1.0))
        bg.pressed.connect(on_garage)
        col.add_child(bg)
    var b3 := UIUtil.make_button(Tr.t("QUIT TO MENU"), Color(1.0, 0.3, 0.35))
    b3.pressed.connect(on_quit)
    col.add_child(b3)

func hide_pause() -> void:
    if pause_panel != null:
        pause_panel.queue_free()
        pause_panel = null

# rows: sorted racers; info: {title, prize, time, new_unlock, can_next}
func show_results(rows: Array, player, info: Dictionary, on_next: Callable, on_retry: Callable, on_menu: Callable) -> void:
    result_panel = _overlay(Color(0.01, 0.02, 0.05, 0.86))
    result_panel.process_mode = Node.PROCESS_MODE_ALWAYS
    var col := _column(result_panel, 760)
    var place := rows.find(player) + 1
    var head := Tr.t("VICTORY!") if place == 1 else (Tr.t("PODIUM  P%d") % place if place <= 3 else Tr.t("FINISHED  P%d") % place)
    var t := UIUtil.make_label(head, 70, Color(1.0, 0.85, 0.2) if place <= 3 else Color(0.1, 1.0, 0.35))
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(t)
    for i in rows.size():
        var r = rows[i]
        var tm: String = fmt_time(r.finish_time) if r.finished else "DNF"
        var txt := "%d.   #%d   %s   -   %s" % [i + 1, r.number, r.racer_name, tm]
        var l := UIUtil.make_label(txt, 26, Color(1.0, 0.9, 0.2) if r == player else Color.WHITE)
        l.add_theme_constant_override("outline_size", 6)
        col.add_child(l)
    var prize := UIUtil.make_label("%s  +%d    %s  %s" % [Tr.t("PRIZE"), int(info["prize"]), Tr.t("YOUR TIME"), fmt_time(float(info["time"]))], 30, Color(0.3, 1.0, 0.5))
    prize.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(prize)
    if int(info.get("bonus", 0)) > 0:
        var bl := UIUtil.make_label("%s  +%d" % [Tr.t("BONUS"), int(info["bonus"])], 28, Color(0.4, 0.9, 1.0))
        bl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        col.add_child(bl)
    if bool(info.get("record", false)):
        var rl := UIUtil.make_label(Tr.t("NEW RECORD!"), 34, Color(1.0, 0.85, 0.2))
        rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        col.add_child(rl)
    if bool(info.get("new_unlock", false)):
        var u := UIUtil.make_label(Tr.t("NEW STAGE UNLOCKED!"), 34, Color(1.0, 0.6, 0.1))
        u.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        col.add_child(u)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 16)
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_child(row)
    if bool(info.get("can_next", false)):
        var bn := UIUtil.make_button(Tr.t("NEXT"), Color(0.2, 1.0, 0.4), Vector2(220, 80))
        bn.pressed.connect(on_next)
        row.add_child(bn)
    var br := UIUtil.make_button(Tr.t("RETRY"), Color(1.0, 0.7, 0.2), Vector2(220, 80))
    br.pressed.connect(on_retry)
    row.add_child(br)
    var bm := UIUtil.make_button(Tr.t("MENU"), Color(1.0, 0.3, 0.35), Vector2(220, 80))
    bm.pressed.connect(on_menu)
    row.add_child(bm)

# first-run tutorial (the tree is paused while it is shown)
func show_tutorial(on_close: Callable) -> void:
    hide_tutorial()
    tut_panel = _overlay(Color(0, 0, 0, 0.8))
    var col := _column(tut_panel, 1000)
    var t := UIUtil.make_label(Tr.t("HOW TO PLAY"), 64, Color(0.1, 1.0, 0.35))
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(t)
    for line in [
        "GAS / BRAKE: right side of the screen",
        "< >: steer (or use TILT)",
        "NITRO: boost, the bar refills over time",
        "DRIFT: slide through corners for score and money",
        "Drive behind other cars for a slipstream boost",
        "Speed traps pay bonus money. Crashes cost you speed."]:
        var l := UIUtil.make_label(Tr.t(line), 30, Color.WHITE)
        l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        col.add_child(l)
    var b := UIUtil.make_button(Tr.t("GOT IT"), Color(0.2, 1.0, 0.4), Vector2(320, 88))
    b.pressed.connect(on_close)
    col.add_child(b)

func hide_tutorial() -> void:
    if tut_panel != null:
        tut_panel.queue_free()
        tut_panel = null
