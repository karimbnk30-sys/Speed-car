extends Node
## Autoload "Save": one JSON save file for progress, garage, settings and stats.
## Migrates the V3 save (user://save.cfg) on first run. Never deletes the old file.
signal changed

const PATH := "user://neonracer_v4.json"
const TMP_PATH := "user://neonracer_v4.json.tmp"
const LEGACY_PATH := "user://save.cfg"
const VERSION := 4

var data: Dictionary = {}
var warm: Array = []   # resources preloaded by the boot screen (keeps them cached)
var next_stage := 0     # stage chosen on the stage-select screen (not persisted)
var mode := "race"      # race | free (not persisted)
var free_theme := "day" # day | sunset | dusk | night (Free Drive, not persisted)
var free_rain := false  # Free Drive weather (not persisted)
var battle_stage := 0   # Car Battle arena chosen on its select screen (not persisted)
var _dirty := false

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    load_data()
    # Landscape only (both landscape directions, never portrait).
    if OS.has_feature("mobile"):
        DisplayServer.screen_set_orientation(DisplayServer.SCREEN_SENSOR_LANDSCAPE)

func defaults() -> Dictionary:
    return {
        "version": VERSION,
        "profile": {"name": "Player", "money": 0},
        "garage": {"selected": 0, "owned": [0], "colors": {}, "damage": {}, "upgrades": {}},
        "progress": {"unlocked_areas": [1], "completed_missions": [], "area_percent": {}, "stage_unlocked": 0, "best_place": {}, "best_time": {}, "ghost": {}},
        "stats": {"best_speed": 0.0, "best_dist": 0.0, "total_distance": 0.0, "playtime": 0.0, "best_drift": 0.0},
        "settings": {
            "language": "en", "ui_scale": 1.0, "autosave": true, "vibration": true, "subtitles": false,
            "graphics_preset": "auto", "shadow_quality": 2, "texture_quality": 2, "reflection_quality": 1,
            "effects_quality": 2, "draw_distance": 2, "anti_aliasing": 1, "fps_limit": 60,
            "audio_master": 1.0, "audio_music": 0.7, "audio_sfx": 1.0, "tutorial_done": false, "audio_engine": 1.0, "audio_environment": 1.0, "audio_traffic": 1.0,
            "audio_tires": 1.0, "audio_collisions": 1.0, "audio_menu": 1.0,
            "control_scheme": "buttons", "steer_sensitivity": 1.0, "button_layout": {},
            "transmission": "auto", "assist": true, "camera_sensitivity": 1.0, "speed_unit": "kmh",
            "traffic_density": 2, "weather": "clear", "time_of_day": "evening", "fuel_enabled": false,
        },
    }

func _merge(base: Dictionary, over: Dictionary) -> Dictionary:
    var out: Dictionary = base.duplicate(true)
    for k in over:
        if out.has(k) and out[k] is Dictionary and over[k] is Dictionary:
            out[k] = _merge(out[k], over[k])
        else:
            out[k] = over[k]
    return out

func load_data() -> void:
    data = defaults()
    var src := ""
    if FileAccess.file_exists(PATH):
        src = PATH
    elif FileAccess.file_exists(TMP_PATH):
        src = TMP_PATH
    if src != "":
        var txt := FileAccess.get_file_as_string(src)
        var parsed: Variant = JSON.parse_string(txt)
        if parsed is Dictionary:
            data = _merge(defaults(), parsed)
            return
        # corrupt file: keep a copy, start clean
        push_warning("Save file unreadable, keeping a .corrupt copy")
        DirAccess.copy_absolute(src, PATH + ".corrupt")
    _migrate_legacy()

func _migrate_legacy() -> void:
    var cf := ConfigFile.new()
    if cf.load(LEGACY_PATH) != OK:
        return
    data["stats"]["best_dist"] = float(cf.get_value("stats", "best_dist", 0.0))
    data["stats"]["best_speed"] = float(cf.get_value("stats", "best_speed", 0.0))
    data["garage"]["selected"] = int(cf.get_value("car", "color", 0)) % 4
    save()

func get_in(path: String, default: Variant = null) -> Variant:
    var cur: Variant = data
    for part in path.split("."):
        if cur is Dictionary and cur.has(part):
            cur = cur[part]
        else:
            return default
    return cur

func set_in(path: String, value: Variant) -> void:
    var parts := path.split(".")
    var cur: Dictionary = data
    for i in parts.size() - 1:
        if not (cur.get(parts[i]) is Dictionary):
            cur[parts[i]] = {}
        cur = cur[parts[i]]
    cur[parts[parts.size() - 1]] = value
    _dirty = true
    changed.emit()

func add_stat(key: String, amount: float) -> void:
    data["stats"][key] = float(data["stats"].get(key, 0.0)) + amount
    _dirty = true

func max_stat(key: String, value: float) -> void:
    if value > float(data["stats"].get(key, 0.0)):
        data["stats"][key] = value
        _dirty = true

func save() -> void:
    var f := FileAccess.open(TMP_PATH, FileAccess.WRITE)
    if f == null:
        push_warning("Cannot write save file")
        return
    f.store_string(JSON.stringify(data, "\t"))
    f.close()
    if FileAccess.file_exists(PATH):
        DirAccess.remove_absolute(PATH)
    DirAccess.rename_absolute(TMP_PATH, PATH)
    _dirty = false

func owns(car: int) -> bool:
    var owned: Array = get_in("garage.owned", [0])
    for o in owned:
        if int(o) == car:
            return true
    return false

func buy_car(car: int, price: int) -> bool:
    if owns(car):
        return true
    var money := int(get_in("profile.money", 0))
    if money < price:
        return false
    var owned: Array = get_in("garage.owned", [0])
    owned = owned.duplicate()
    owned.append(car)
    set_in("garage.owned", owned)
    set_in("profile.money", money - price)
    save()
    return true

func upgrade_level(car: int, key: String) -> int:
    return int(get_in("garage.upgrades.%d.%s" % [car, key], 0))

func upgrade_cost(car: int, key: String) -> int:
    return 800 * (upgrade_level(car, key) + 1)

func buy_upgrade(car: int, key: String) -> bool:
    var lvl := upgrade_level(car, key)
    if lvl >= 5:
        return false
    var cost := upgrade_cost(car, key)
    var money := int(get_in("profile.money", 0))
    if money < cost:
        return false
    set_in("profile.money", money - cost)
    set_in("garage.upgrades.%d.%s" % [car, key], lvl + 1)
    save()
    return true

func save_if_dirty() -> void:
    if _dirty:
        save()

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
        save()
