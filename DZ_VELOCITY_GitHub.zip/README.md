# DZ VELOCITY

Arcade racing in Algiers, Algeria. Godot 4.7 (Mobile renderer), Android landscape.
Formerly "Neon Racer V7"; the old name no longer appears in anything the player sees.

| Mode | What it is |
|---|---|
| **Career** | The original 8 stages (Port Sprint ... Night Grand Prix), 8-car point-to-point races, garage, upgrades, ghost car. |
| **Free Drive** *(new)* | No countdown, no opponents, no timer, no finish line. Drive the whole Algiers route with traffic. Pick DAY / SUNSET / NIGHT and rain on or off. Pause menu has *Garage*. Drifting pays credits straight away. |
| **Car Battle - Desert Arena** *(new)* | 5 arenas, AI bots, durability bar, 4 visual damage stages, knockback, dust and debris, rewards. |

## Put it on GitHub

1. Create an empty repository.
2. Unzip this archive and upload **the contents** so that `project.godot` and `.github/` are at the repository root.
3. Open the **Actions** tab. **DZ VELOCITY - Android Build** runs on every push and produces a **debug APK** artifact.
4. For a signed release APK + AAB, add three secrets (Settings > Secrets and variables > Actions):
   `ANDROID_KEYSTORE_BASE64` (`base64 -w0 release.keystore`), `ANDROID_KEYSTORE_USER`, `ANDROID_KEYSTORE_PASSWORD`,
   then push a tag such as `v1.0.0` (or run the workflow by hand with *release* ticked). A tag also creates a GitHub Release.

The workflow also parse-checks every GDScript file (informational, does not block the APK) and verifies that the
built APK's Android label is `DZ VELOCITY`.

## Branding

* Name: `config/name`, Android `package/name`, boot splash, main menu, loading screen, pause, credits: **DZ VELOCITY**.
* Icon: made from the exact image supplied (`96024.png`), only cropped (3 % black corner margin removed) and scaled, never redrawn.
  `icon.png` (512), `branding/main_192.png`, adaptive icon `branding/adaptive_fg_432.png` (the image at 76 %) +
  `branding/adaptive_bg_432.png` (the same image, blurred). The boot splash is the image on black.
* Palette: black / neon green / white / red.
* The Android package id is still `com.neonracer.game` on purpose: changing it makes Android treat the game as a
  different app and players would lose their saves. For a fresh Play Store listing, change `package/unique_name`
  in all three presets of `export_presets.cfg`.
* The save file is still `user://neonracer_v4.json`, so existing progress carries over.

## Car Battle details

Arenas (`scripts/battle_data.gd`): Desert Training (survive 60 s), Sandstorm Arena (low visibility), Rocky Battlefield,
Extreme Arena, Last Car Standing. Each unlocks after clearing the previous one.

* Damage stages by durability: >75 % clean, 75-50 % minor (scratches, slight deformation), 50-25 % moderate (more
  deformation, smoke, flying parts), 25-0 % severe (darkened paint, one headlight out, top speed/accel penalty),
  0 % disabled (engine off, collision off, marked eliminated, leaves the fight).
* Visual damage is done with a paint overlay, small model deformation, smoke/fire particles and pooled debris, not mesh destruction.
* Rewards use the normal economy: credits (first clear full, replays 40 %, +150 per knock-out), car unlocks
  (arena 3 -> INTERCEPTOR, arena 5 -> PHANTOM ZZ), free engine / handling / nitro upgrade levels, "cleared" flags.
* The arena floor is flat on purpose (car.gd pins cars to a fixed height); rocks, walls and decorative dunes provide the layout.

## Project layout

`scripts/` game code (`main.gd` race + Free Drive, `battle.gd` arena, `car.gd` physics, `menu.gd`, ...),
`scenes/`, `maps/algiers.json` (OpenStreetMap data), `branding/`, `docs/history/` old readmes.
See `CHANGELOG.md` and `docs/STATUS.md` for what is done, untested, and not done.
