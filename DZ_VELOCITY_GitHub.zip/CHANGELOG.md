# Changelog

## 1.0.0 - DZ VELOCITY (rebrand of Neon Racer V7)

### Added
- Free Drive mode (menu setup for time of day + rain, no race rules, traffic, minimap, speedo, pause with Garage).
- Car Battle - Desert Arena: 5 arenas, AI bots, durability, 4 damage stages, knockback, dust/debris pools, rewards, unlocks.
- Credits screen, arena select screen, results screen for battles.
- Seven-entry main menu: Career, Free Drive, Car Battle, Garage, Settings, Credits, Exit.
- Arabic and French strings for all new text.
- GitHub Actions workflow (debug APK, signed release APK + AAB, release publishing, parse check, APK label check).
- Export presets: Android (debug), Android Release, Android AAB.

### Changed
- Name, icon (from the supplied image), boot splash, Android app name and version (1.0.0, code 10).
- UI accent colour cyan -> neon green; red for battle/exit.
- Pause menu can show a Garage button (used by Free Drive).
- Old readmes moved to `docs/history/`.

### Kept
- All 8 stages, vehicles, garage, upgrades, AI, saves, ghost cars, weather, languages.
