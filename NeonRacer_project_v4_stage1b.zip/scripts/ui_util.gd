extends RefCounted
## Shared UI helpers: safe-area insets and neon-styled buttons.

# Returns Vector4(left, top, right, bottom) insets in viewport units (cutouts, rounded corners).
static func safe_insets(vp: Viewport) -> Vector4:
    var base := 24.0
    if not OS.has_feature("mobile"):
        return Vector4(base, base, base, base)
    var win := Vector2(DisplayServer.window_get_size())
    var vs := vp.get_visible_rect().size
    var sa := DisplayServer.get_display_safe_area()
    if win.x <= 0.0 or win.y <= 0.0 or sa.size.x <= 0:
        return Vector4(base, base, base, base)
    var sx := vs.x / win.x
    var sy := vs.y / win.y
    return Vector4(
        maxf(base, sa.position.x * sx),
        maxf(base, sa.position.y * sy),
        maxf(base, (win.x - sa.end.x) * sx),
        maxf(base, (win.y - sa.end.y) * sy))

static func box(bg: Color, border: Color, bw: int) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = bg
    sb.border_color = border
    sb.set_border_width_all(bw)
    sb.set_corner_radius_all(18)
    return sb

static func make_button(text: String, color: Color, size: Vector2 = Vector2(380, 88)) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = size
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", 38)
    b.add_theme_color_override("font_color", color)
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    b.add_theme_stylebox_override("normal", box(Color(0.04, 0.05, 0.09, 0.72), color, 3))
    b.add_theme_stylebox_override("hover", box(Color(0.08, 0.12, 0.18, 0.85), color, 4))
    b.add_theme_stylebox_override("pressed", box(color.darkened(0.55), color, 4))
    b.pivot_offset = size / 2.0
    b.button_down.connect(func(): b.create_tween().tween_property(b, "scale", Vector2(0.96, 0.96), 0.06))
    b.button_up.connect(func(): b.create_tween().tween_property(b, "scale", Vector2.ONE, 0.1))
    return b

static func make_label(text: String, size: int, color: Color) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
    l.add_theme_constant_override("outline_size", 8)
    return l
