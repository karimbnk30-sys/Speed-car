extends Node3D
## Cinematic showroom: dark studio, glossy floor, neon ring, camera orbiting a car.
const CarScript := preload("res://scripts/car.gd")

var model_index := 0
var orbit_speed := 0.35
var radius := 6.8
var height := 1.5
var angle := 0.6
var cam: Camera3D

func _ready() -> void:
    _build_environment()
    _build_stage()
    _build_car()
    cam = Camera3D.new()
    cam.fov = 45.0
    cam.near = 0.1
    cam.far = 200.0
    add_child(cam)
    cam.current = true
    _update_cam(0.0)

func _process(delta: float) -> void:
    angle += orbit_speed * delta
    _update_cam(delta)

func _update_cam(_delta: float) -> void:
    var bob := sin(angle * 1.7) * 0.18
    cam.position = Vector3(cos(angle) * radius, height + bob, sin(angle) * radius)
    cam.look_at(Vector3(0, 0.6, 0), Vector3.UP)

func _build_environment() -> void:
    var env := Environment.new()
    var sky := Sky.new()
    var tex = load("res://sky/evening_ldr.jpg")
    if tex != null:
        var pano := PanoramaSkyMaterial.new()
        pano.panorama = tex
        sky.sky_material = pano
    else:
        sky.sky_material = ProceduralSkyMaterial.new()
    env.sky = sky
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.01, 0.01, 0.02)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.35
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_ACES
    env.glow_enabled = true
    env.glow_intensity = 0.7
    env.glow_hdr_threshold = 1.0
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)

func _build_stage() -> void:
    var floor_mesh := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(60, 60)
    floor_mesh.mesh = pm
    var fm := StandardMaterial3D.new()
    fm.albedo_color = Color(0.03, 0.03, 0.045)
    fm.metallic = 0.7
    fm.roughness = 0.18
    floor_mesh.material_override = fm
    add_child(floor_mesh)
    var ring := MeshInstance3D.new()
    var tm := TorusMesh.new()
    tm.inner_radius = 3.6
    tm.outer_radius = 3.75
    ring.mesh = tm
    var rm := StandardMaterial3D.new()
    rm.albedo_color = Color(0.0, 0.9, 1.0)
    rm.emission_enabled = true
    rm.emission = Color(0.0, 0.9, 1.0)
    rm.emission_energy_multiplier = 2.0
    ring.material_override = rm
    ring.position.y = 0.02
    add_child(ring)
    var key := SpotLight3D.new()
    key.position = Vector3(0, 6.5, 0)
    key.rotation_degrees = Vector3(-90, 0, 0)
    key.spot_range = 16.0
    key.spot_angle = 42.0
    key.light_energy = 6.0
    key.shadow_enabled = true
    add_child(key)
    var cyan := OmniLight3D.new()
    cyan.position = Vector3(-5, 1.6, -3)
    cyan.omni_range = 11.0
    cyan.light_energy = 2.0
    cyan.light_color = Color(0.0, 0.85, 1.0)
    add_child(cyan)
    var magenta := OmniLight3D.new()
    magenta.position = Vector3(5, 1.6, 3)
    magenta.omni_range = 11.0
    magenta.light_energy = 2.0
    magenta.light_color = Color(1.0, 0.2, 0.8)
    add_child(magenta)

func _build_car() -> void:
    var path: String = CarScript.MODELS[model_index % CarScript.MODELS.size()]
    var ps = load(path)
    if ps == null:
        push_warning("Showroom car model not found: %s" % path)
        return
    var m: Node3D = ps.instantiate()
    m.scale = Vector3.ONE * CarScript.MODEL_SCALE
    add_child(m)
