extends CharacterBody3D
## Arcade car physics: throttle, brake, reverse, steering, drift, collisions.
signal crashed(force: float)

var throttle := 0.0
var braking := false
var steer := 0.0
var drift := false

var speed := 0.0      # m/s along heading
var lateral := 0.0    # m/s sideways (drift)
var max_speed := 70.0
var accel := 22.0
var brake_force := 45.0
var turn_rate := 1.9
var grip := 8.0

const MODELS := [
    "res://models/Car_1_B.gltf",
    "res://models/Car_10_ZZ.gltf",
    "res://models/Car_Police_1_A_1.gltf",
    "res://models/Car_Police_4_A_1.gltf",
]
const MODEL_SCALE := 1.12
var model: Node3D
var wheels := {}
var wheel_spin := 0.0
var smoke: CPUParticles3D
var sfx := {}
var crash_player: AudioStreamPlayer
var sound_on := true

func _ready() -> void:
    motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(1.9, 0.9, 4.2)
    cs.shape = bs
    cs.position.y = 0.2
    add_child(cs)

    set_model(0)
    _setup_audio()

    smoke = CPUParticles3D.new()
    smoke.amount = 40
    smoke.lifetime = 1.2
    smoke.local_coords = false
    smoke.direction = Vector3(0, 1, 0.5)
    smoke.spread = 25.0
    smoke.initial_velocity_min = 1.0
    smoke.initial_velocity_max = 3.0
    smoke.gravity = Vector3(0, 0.5, 0)
    smoke.scale_amount_min = 1.0
    smoke.scale_amount_max = 2.5
    var sm := SphereMesh.new()
    sm.radius = 0.3
    sm.height = 0.6
    var smat := StandardMaterial3D.new()
    smat.albedo_color = Color(0.85, 0.85, 0.85, 0.45)
    smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    sm.material = smat
    smoke.mesh = sm
    smoke.position = Vector3(0, -0.1, 1.5)
    smoke.emitting = false
    add_child(smoke)

func set_model(i: int) -> void:
    if model != null:
        model.queue_free()
        model = null
    var ps = load(MODELS[i % MODELS.size()])
    if ps == null:
        push_warning("Car model not found: %s" % MODELS[i % MODELS.size()])
        return
    model = ps.instantiate()
    model.rotation.y = -PI / 2.0   # models face -X, the game drives toward -Z
    model.scale = Vector3.ONE * MODEL_SCALE
    model.position = Vector3(0, -0.236, 0)
    add_child(model)
    wheels.clear()
    for n in ["FL", "FR", "RL", "RR"]:
        var w = model.find_child(n, true, false)
        if w != null:
            wheels[n] = w

func _physics_process(delta: float) -> void:
    if throttle > 0.0 and not braking:
        speed += accel * throttle * (1.0 - clampf(speed / max_speed, 0.0, 1.0)) * delta
    if braking:
        if speed > 0.5:
            speed = move_toward(speed, 0.0, brake_force * delta)
        else:
            speed = move_toward(speed, -12.0, 14.0 * delta)
    elif throttle <= 0.0:
        speed = move_toward(speed, 0.0, 4.0 * delta)

    var s := clampf(speed / 12.0, -1.0, 1.0)
    rotation.y -= steer * turn_rate * s / (1.0 + absf(speed) / 60.0) * delta

    var g := grip * (0.25 if drift else 1.0)
    if drift:
        lateral -= steer * speed * 0.25 * delta
        speed = move_toward(speed, 0.0, absf(lateral) * 0.25 * delta)
    lateral = lerpf(lateral, 0.0, clampf(g * delta, 0.0, 1.0))

    var fwd := -global_transform.basis.z
    var right := global_transform.basis.x
    velocity = fwd * speed + right * lateral
    var before := speed
    move_and_slide()
    if get_slide_collision_count() > 0:
        speed = velocity.dot(fwd)
        lateral = velocity.dot(right)
        var impact := absf(before - speed)
        speed *= 0.98
        if impact > 3.0:
            crashed.emit(impact)
            _play_crash(impact)
    position.y = 0.5
    smoke.emitting = absf(lateral) > 2.5 and speed > 10.0
    wheel_spin += speed / (0.25 * MODEL_SCALE) * delta
    for n in wheels:
        var w: Node3D = wheels[n]
        w.rotation = Vector3(0.0, (-steer * 0.5) if n.begins_with("F") else 0.0, wheel_spin)
    _update_audio()

func _setup_audio() -> void:
    for n in ["engine", "skid", "road", "wind"]:
        var res = load("res://audio/%s.wav" % n)
        if res == null:
            continue
        var st: AudioStreamWAV = res.duplicate()
        st.loop_mode = AudioStreamWAV.LOOP_FORWARD
        st.loop_begin = 0
        st.loop_end = st.data.size() / 2
        var p := AudioStreamPlayer.new()
        p.stream = st
        p.volume_db = -80.0
        add_child(p)
        p.play()
        sfx[n] = p
    var cr = load("res://audio/crash.wav")
    if cr != null:
        crash_player = AudioStreamPlayer.new()
        crash_player.stream = cr
        add_child(crash_player)

func _set_sfx(n: String, vol: float, pitch: float) -> void:
    if not sfx.has(n):
        return
    var p: AudioStreamPlayer = sfx[n]
    p.volume_db = linear_to_db(maxf(vol, 0.0001)) if sound_on else -80.0
    p.pitch_scale = maxf(pitch, 0.1)

func _update_audio() -> void:
    var sp := absf(speed)
    _set_sfx("engine", 0.35 + (0.25 if throttle > 0.0 else 0.0), 0.55 + sp / 70.0 * 2.2)
    _set_sfx("skid", clampf((absf(lateral) - 1.5) / 5.0, 0.0, 1.0) * 0.6 + (0.35 if (braking and sp > 25.0) else 0.0), 1.0)
    _set_sfx("road", clampf(sp / 60.0, 0.0, 1.0) * 0.5, 0.7 + sp / 90.0)
    _set_sfx("wind", pow(clampf(sp / 70.0, 0.0, 1.0), 2.0) * 0.6, 1.0)

func _play_crash(f: float) -> void:
    if crash_player == null or not sound_on:
        return
    crash_player.volume_db = linear_to_db(clampf(f / 14.0, 0.25, 1.0))
    crash_player.play()
