extends Node3D
## NEON RACER V4 (stage 1): Algiers-only driving scene. Builds world, HUD and touch controls in code.
const CarScript := preload("res://scripts/car.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const TILT_SIGN := 1.0   # change to -1.0 if tilt steering is reversed on your phone
const CAM_OFFSETS := [Vector3(0, 3.2, 8.0), Vector3(0, 5.5, 13.0), Vector3(0, 1.2, 0.3)]
const NUM_MODELS := 4

var car
var cam: Camera3D
const AlgiersScript := preload("res://scripts/algiers.gd")
var algiers: Node3D
var cam_snap := false
var touches := {}
var btns := {}
var held := {}
var use_tilt := false
var cam_mode := 0
var color_idx := 0
var steer_smooth := 0.0
var shake := 0.0
var speed_label: Label
var info_label: Label
var save_timer := 0.0
var sky_is_morning := false
var map_ok := false

func _ready() -> void:
    randomize()
    _setup_environment()
    _spawn_car()
    _build_ui()
    _load_settings()
    algiers = AlgiersScript.new()
    add_child(algiers)
    algiers.build()
    map_ok = algiers.pts.size() > 1
    if not map_ok:
        push_error("Algiers map failed to load (maps/algiers.json)")
    _respawn()

func _respawn() -> void:
    car.speed = 0.0
    car.lateral = 0.0
    if map_ok:
        car.position = Vector3(algiers.pts[0].x, 0.5, algiers.pts[0].y)
        car.rotation.y = algiers.yaw0
    else:
        car.position = Vector3(0, 0.5, 0)
        car.rotation.y = 0.0
    cam_snap = true

# ---------- World ----------
func _setup_environment() -> void:
    var we := WorldEnvironment.new()
    var env := Environment.new()
    var sky := Sky.new()
    sky.sky_material = _make_sky_material()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.9
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_ACES
    env.tonemap_exposure = 1.0
    env.tonemap_white = 6.0
    env.glow_enabled = true
    env.glow_intensity = 0.6
    env.glow_bloom = 0.05
    env.glow_hdr_threshold = 1.1
    env.adjustment_enabled = true
    env.adjustment_contrast = 1.08
    env.adjustment_saturation = 1.1
    env.fog_enabled = true
    env.fog_light_color = Color(0.62, 0.70, 0.82)
    env.fog_density = 0.0009
    env.fog_sky_affect = 0.4
    env.fog_sun_scatter = 0.25
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-26, 180, 0)
    sun.light_color = Color(1.0, 0.82, 0.62)
    sun.light_energy = 1.6
    if sky_is_morning:
        # Aim the sun where the HDRI's sun sits (u=0.58 of the panorama -> 0.5 rad from centre),
        # raised to 24 degrees so shadows stay short and readable while driving.
        var az := 0.5
        var el := deg_to_rad(24.0)
        var to_sun := Vector3(sin(az) * cos(el), sin(el), -cos(az) * cos(el))
        sun.basis = Basis.looking_at(-to_sun, Vector3.UP)
        sun.light_color = Color(1.0, 0.9, 0.78)
        sun.light_energy = 1.5
        env.ambient_light_energy = 0.8
    sun.shadow_enabled = true
    sun.shadow_bias = 0.04
    sun.shadow_normal_bias = 1.2
    sun.shadow_blur = 1.5
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
    sun.directional_shadow_max_distance = 220.0
    add_child(sun)

func _make_sky_material() -> Material:
    for path in ["res://sky/puresky_morning_2k.hdr", "res://sky/evening_hdr.exr", "res://sky/evening_ldr.jpg"]:
        var tex = load(path)
        if tex != null:
            var pano := PanoramaSkyMaterial.new()
            pano.panorama = tex
            sky_is_morning = path.contains("puresky")
            return pano
    var pm := ProceduralSkyMaterial.new()
    pm.sky_top_color = Color(0.20, 0.40, 0.78)
    pm.sky_horizon_color = Color(0.72, 0.82, 0.92)
    pm.ground_horizon_color = Color(0.72, 0.78, 0.84)
    return pm

func _spawn_car() -> void:
    car = CarScript.new()
    car.position = Vector3(0, 0.5, 0)
    add_child(car)
    for hx in [-0.65, 0.65]:
        var hl := SpotLight3D.new()
        hl.position = Vector3(hx, 0.55, -2.0)
        hl.spot_range = 45.0
        hl.spot_angle = 30.0
        hl.light_energy = 2.0
        hl.light_color = Color(1.0, 0.95, 0.85)
        car.add_child(hl)
    car.crashed.connect(func(f: float): shake = clampf(f * 0.02, 0.1, 0.8))
    cam = Camera3D.new()
    cam.far = 1500.0
    cam.near = 0.1
    add_child(cam)
    cam.current = true

# ---------- UI ----------
func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var sz := get_viewport().get_visible_rect().size
    var ins := UIUtil.safe_insets(get_viewport())
    var L := ins.x
    var R := sz.x - ins.z
    var T := ins.y
    var B := sz.y - ins.w
    var W := sz.x
    _btn(layer, "left", "<", Vector2(L, B - 150), Vector2(150, 150))
    _btn(layer, "right", ">", Vector2(L + 170, B - 150), Vector2(150, 150))
    _btn(layer, "gas", "GAS", Vector2(R - 160, B - 170), Vector2(160, 170), Color(0.2, 1, 0.4))
    _btn(layer, "brake", "BRAKE", Vector2(R - 340, B - 130), Vector2(150, 130), Color(1, 0.2, 0.3))
    _btn(layer, "drift", "DRIFT", Vector2(R - 340, B - 270), Vector2(150, 110), Color(1, 0.6, 0.1))
    _btn(layer, "color", "CAR", Vector2(R - 460, T), Vector2(140, 60), Color(0.9, 0.3, 1))
    _btn(layer, "tilt", "TILT", Vector2(R - 310, T), Vector2(140, 60), Color(0.9, 0.3, 1))
    _btn(layer, "cam", "CAM", Vector2(R - 160, T), Vector2(140, 60), Color(0.9, 0.3, 1))
    _btn(layer, "menu", "MENU", Vector2(R - 610, T), Vector2(140, 60), Color(0.9, 0.3, 1))
    _btn(layer, "snd", "SND", Vector2(R - 760, T), Vector2(140, 60), Color(0.9, 0.3, 1))
    speed_label = Label.new()
    speed_label.position = Vector2(W / 2 - 150, B - 90)
    speed_label.size = Vector2(300, 80)
    speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    speed_label.add_theme_font_size_override("font_size", 56)
    speed_label.add_theme_color_override("font_color", Color(0.0, 0.95, 1.0))
    speed_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
    speed_label.add_theme_constant_override("outline_size", 10)
    layer.add_child(speed_label)
    info_label = Label.new()
    info_label.position = Vector2(L, T)
    info_label.add_theme_font_size_override("font_size", 26)
    info_label.add_theme_color_override("font_color", Color.WHITE)
    info_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
    info_label.add_theme_constant_override("outline_size", 8)
    layer.add_child(info_label)

func _btn(layer: Node, id: String, text: String, pos: Vector2, size: Vector2, color := Color(0.0, 0.9, 1.0)) -> void:
    var p := Panel.new()
    p.position = pos
    p.size = size
    p.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.05, 0.06, 0.1, 0.55)
    sb.border_color = color
    sb.set_border_width_all(3)
    sb.set_corner_radius_all(18)
    p.add_theme_stylebox_override("panel", sb)
    var l := Label.new()
    l.text = text
    l.set_anchors_preset(Control.PRESET_FULL_RECT)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.add_theme_font_size_override("font_size", 28)
    l.add_theme_color_override("font_color", color)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    p.add_child(l)
    layer.add_child(p)
    btns[id] = p

# ---------- Input (multi-touch) ----------
func _input(e: InputEvent) -> void:
    if e is InputEventScreenTouch:
        if e.pressed:
            touches[e.index] = e.position
            _tap(e.position)
        else:
            touches.erase(e.index)
    elif e is InputEventScreenDrag:
        touches[e.index] = e.position

func _tap(pos: Vector2) -> void:
    if btns["cam"].get_global_rect().has_point(pos):
        cam_mode = (cam_mode + 1) % CAM_OFFSETS.size()
    elif btns["menu"].get_global_rect().has_point(pos):
        Save.save()
        get_tree().change_scene_to_file("res://scenes/menu.tscn")
    elif btns["snd"].get_global_rect().has_point(pos):
        car.sound_on = not car.sound_on
        Save.set_in("settings.audio_master", 1.0 if car.sound_on else 0.0)
    elif btns["tilt"].get_global_rect().has_point(pos):
        use_tilt = not use_tilt
        Save.set_in("settings.control_scheme", "tilt" if use_tilt else "buttons")
    elif btns["color"].get_global_rect().has_point(pos):
        color_idx = (color_idx + 1) % NUM_MODELS
        car.set_model(color_idx)
        Save.set_in("garage.selected", color_idx)

func _process(delta: float) -> void:
    for id in btns:
        held[id] = false
    for p in touches.values():
        for id in btns:
            if btns[id].get_global_rect().has_point(p):
                held[id] = true
    for id in btns:
        btns[id].modulate = Color(1.7, 1.7, 1.7) if held[id] else Color.WHITE

    var gas: bool = held["gas"] or Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)
    var brk: bool = held["brake"] or Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN)
    var left: bool = held["left"] or Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT)
    var right: bool = held["right"] or Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)
    var target := 0.0
    if use_tilt:
        target = clampf(Input.get_accelerometer().y * TILT_SIGN / 4.0, -1.0, 1.0)
        if absf(target) < 0.08:
            target = 0.0
    else:
        target = (1.0 if right else 0.0) - (1.0 if left else 0.0)
    steer_smooth = move_toward(steer_smooth, target, 6.0 * delta)
    car.steer = steer_smooth
    car.throttle = 1.0 if gas else 0.0
    car.braking = brk
    car.drift = held["drift"] or Input.is_key_pressed(KEY_SPACE)

    # camera
    var off: Vector3 = CAM_OFFSETS[cam_mode]
    var target_pos: Vector3 = car.global_transform * off
    cam.global_position = target_pos if (cam_mode == 2 or cam_snap) else cam.global_position.lerp(target_pos, clampf(8.0 * delta, 0.0, 1.0))
    cam_snap = false
    var fwd: Vector3 = -car.global_transform.basis.z
    cam.look_at(car.global_position + fwd * 10.0 + Vector3.UP, Vector3.UP)
    cam.fov = 70.0 + absf(car.speed) * 0.25
    shake = move_toward(shake, 0.0, delta * 2.0)
    cam.h_offset = randf_range(-1.0, 1.0) * shake
    cam.v_offset = randf_range(-1.0, 1.0) * shake

    # HUD + stats
    var kmh := absf(car.speed) * 3.6
    var dist: float = car.position.length()
    if map_ok and Vector2(car.position.x, car.position.z).distance_to(algiers.end_point) < 40.0:
        _respawn()
    Save.max_stat("best_speed", kmh)
    Save.max_stat("best_dist", dist)
    Save.add_stat("total_distance", absf(car.speed) * delta)
    Save.add_stat("playtime", delta)
    speed_label.text = "%d KM/H" % int(kmh)
    if map_ok:
        info_label.text = "DIST %d m   BEST %d m   TOP %d km/h" % [int(dist), int(float(Save.get_in("stats.best_dist", 0.0))), int(float(Save.get_in("stats.best_speed", 0.0)))]
    else:
        info_label.text = "MAP FILE MISSING: maps/algiers.json"
    save_timer += delta
    if save_timer > 3.0:
        save_timer = 0.0
        Save.save_if_dirty()

# ---------- Settings (stored by the Save autoload) ----------
func _load_settings() -> void:
    color_idx = int(Save.get_in("garage.selected", 0)) % NUM_MODELS
    car.set_model(color_idx)
    use_tilt = str(Save.get_in("settings.control_scheme", "buttons")) == "tilt"
    car.sound_on = float(Save.get_in("settings.audio_master", 1.0)) > 0.0
