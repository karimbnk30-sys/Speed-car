extends Node
## Startup: black fade-in, logo, cinematic car, real loading bar, Skip button.
const ShowroomScript := preload("res://scripts/showroom.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const MIN_TIME := 3.2
const NEXT_SCENE := "res://scenes/menu.tscn"
const PRELOAD := [
    "res://scenes/menu.tscn", "res://scenes/main.tscn",
    "res://models/Car_1_B.gltf", "res://models/Car_10_ZZ.gltf",
    "res://models/Car_Police_1_A_1.gltf", "res://models/Car_Police_4_A_1.gltf",
    "res://textures/terrain_color.jpg", "res://sky/evening_ldr.jpg",
]

var started := false
var leaving := false
var elapsed := 0.0
var shown := 0.0
var bar: ProgressBar
var fade: ColorRect
var logo: Label
var sub: Label

func _ready() -> void:
    _build_ui()
    await get_tree().process_frame   # let the black frame render before heavy work
    var sr := ShowroomScript.new()
    sr.model_index = 1
    add_child(sr)
    move_child(sr, 0)
    for p in PRELOAD:
        ResourceLoader.load_threaded_request(p)
    started = true
    create_tween().tween_property(fade, "color:a", 0.0, 1.0)
    var t := create_tween()
    t.tween_interval(0.6)
    t.tween_property(logo, "modulate:a", 1.0, 1.2)
    t.parallel().tween_property(sub, "modulate:a", 1.0, 1.6)

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 10
    add_child(layer)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var ins := UIUtil.safe_insets(get_viewport())
    logo = UIUtil.make_label("NEON RACER", 104, Color(0.0, 0.95, 1.0))
    logo.set_anchors_preset(Control.PRESET_CENTER_TOP)
    logo.grow_horizontal = Control.GROW_DIRECTION_BOTH
    logo.position.y = ins.y + 20.0
    logo.modulate.a = 0.0
    root.add_child(logo)
    sub = UIUtil.make_label("ALGIERS  -  ALGERIA", 30, Color(1, 1, 1))
    sub.set_anchors_preset(Control.PRESET_CENTER_TOP)
    sub.grow_horizontal = Control.GROW_DIRECTION_BOTH
    sub.position.y = ins.y + 150.0
    sub.modulate.a = 0.0
    root.add_child(sub)
    bar = ProgressBar.new()
    bar.show_percentage = false
    bar.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    bar.offset_left = ins.x + 120.0
    bar.offset_right = -(ins.z + 120.0)
    bar.offset_top = -(ins.w + 44.0)
    bar.offset_bottom = -(ins.w + 28.0)
    bar.max_value = 100.0
    bar.add_theme_stylebox_override("background", UIUtil.box(Color(0.05, 0.06, 0.1, 0.8), Color(0.0, 0.5, 0.6), 2))
    bar.add_theme_stylebox_override("fill", UIUtil.box(Color(0.0, 0.9, 1.0), Color(0.0, 0.9, 1.0), 0))
    root.add_child(bar)
    var skip := UIUtil.make_button("SKIP", Color(1, 1, 1), Vector2(170, 64))
    skip.add_theme_font_size_override("font_size", 28)
    skip.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    skip.offset_left = -(ins.z + 170.0)
    skip.offset_right = -ins.z
    skip.offset_top = ins.y
    skip.offset_bottom = ins.y + 64.0
    skip.pressed.connect(_go)
    root.add_child(skip)
    fade = ColorRect.new()
    fade.color = Color.BLACK
    fade.set_anchors_preset(Control.PRESET_FULL_RECT)
    fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(fade)

func _process(delta: float) -> void:
    if not started or leaving:
        return
    elapsed += delta
    var total := 0.0
    for p in PRELOAD:
        var prog: Array = []
        var st := ResourceLoader.load_threaded_get_status(p, prog)
        if st == ResourceLoader.THREAD_LOAD_IN_PROGRESS and prog.size() > 0:
            total += float(prog[0])
        else:
            total += 1.0   # loaded, or failed (reported when collected)
    var target := minf(total / PRELOAD.size(), elapsed / MIN_TIME)
    shown = move_toward(shown, target, delta * 0.9)
    bar.value = shown * 100.0
    if shown >= 0.999:
        _go()

func _go() -> void:
    if leaving:
        return
    leaving = true
    for p in PRELOAD:
        var st := ResourceLoader.load_threaded_get_status(p)
        if st == ResourceLoader.THREAD_LOAD_LOADED:
            Save.warm.append(ResourceLoader.load_threaded_get(p))
        elif st == ResourceLoader.THREAD_LOAD_FAILED:
            push_warning("Boot: failed to preload %s" % p)
    get_tree().change_scene_to_file(NEXT_SCENE)
