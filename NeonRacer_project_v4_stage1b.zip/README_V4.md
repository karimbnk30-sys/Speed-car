# NEON RACER V4 - Stage 1 (Foundation)
Built on V3. Original V3 zip kept separately as NeonRacer_project_v3_ORIGINAL_BACKUP.zip.

## Done in Stage 1 (written, NOT yet run in Godot)
- Save autoload (scripts/save.gd): one JSON file (user://neonracer_v4.json) holding profile, money, owned vehicles,
  selected vehicle, unlocked areas, completed missions, stats and all planned settings. Missing keys are filled with
  defaults, a corrupt file is copied to .corrupt, V3 save.cfg is migrated (and never deleted). Autosaves every 3 s
  when changed and on pause/close.
- Landscape only: project orientation = sensor landscape, plus runtime lock on mobile.
- Boot screen -> menu: black fade-in, logo, orbiting 3D car, real loading bar (preloads menu, game, cars), SKIP button.
- Menu: PLAY and EXIT only (other entries come with their screens in Stage 2).
- Algiers only: the desert test track and the MAP toggle are removed from the game scene. No pyramid assets existed.
- Safe-area insets applied to boot, menu and driving HUD.
- Game: persists selected car, tilt/buttons, sound, stats. MENU button returns to the menu.

## Known gaps / changes
- Old desert-track traffic is gone; traffic returns on the Algiers route in Stage 5.
- Desktop: mouse no longer emulates touch (needed so UI buttons work on phones); drive with W/A/S/D + Space.
- Not yet done: everything from Stages 2-5 in the brief.

## Asset integration (stage 1b) - written, NOT yet run in Godot
- Sidewalks use ambientCG PavingStones142 (color, normal GL, roughness at 1K) via scripts/algiers.gd (_paving_mat).
- Daytime sky: Poly Haven puresky as 2K Radiance HDR (sky/puresky_morning_2k.hdr); the sun light in main.gd is aimed
  at the HDRI sun (azimuth assumes Godot's panorama centre faces -Z - check visually) and raised to 24 degrees.
  The V3 evening sky stays in the project as fallback.
- Not imported: AO, displacement, DX normal, .blend/.usdc/.mtlx/.tres from the paving pack; the 4K EXR (70 MB, too heavy).
- The pack has no asphalt, buildings, trees, streetlights or signs, so those are unchanged.
- Textures are VRAM-compressed (ETC2/ASTC) on import because the project enables import_etc2_astc; confirm in Godot's Import tab.
