extends Node3D
## Builds the world, HUD and touch controls procedurally (no external assets).
const CarScript := preload("res://scripts/car.gd")
const SEG_LEN := 100.0
const SEG_COUNT := 6
const TILT_SIGN := 1.0   # change to -1.0 if tilt steering is reversed on your phone
const CAM_OFFSETS := [Vector3(0, 3.2, 8.0), Vector3(0, 5.5, 13.0), Vector3(0, 1.2, 0.3)]
const NUM_MODELS := 4

var car
var cam: Camera3D
var segs: Array = []
var traffic: Array = []
const AlgiersScript := preload("res://scripts/algiers.gd")
var algiers: Node3D
var map_mode := 1
var cam_snap := false
var touches := {}
var btns := {}
var held := {}
var use_tilt := false
var cam_mode := 0
var color_idx := 0
var steer_smooth := 0.0
var shake := 0.0
var speed_label: Label
var info_label: Label
var best_speed := 0.0
var best_dist := 0.0
var save_timer := 0.0

func _ready() -> void:
    randomize()
    _setup_environment()
    _build_road()
    _spawn_car()
    _spawn_traffic()
    _build_ui()
    _load_save()
    algiers = AlgiersScript.new()
    add_child(algiers)
    algiers.build()
    _set_map(1 if algiers.pts.size() > 1 else 0)

# ---------- World ----------
func _setup_environment() -> void:
    var we := WorldEnvironment.new()
    var env := Environment.new()
    var sky := Sky.new()
    sky.sky_material = _make_sky_material()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.9
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_ACES
    env.tonemap_exposure = 1.0
    env.tonemap_white = 6.0
    env.glow_enabled = true
    env.glow_intensity = 0.6
    env.glow_bloom = 0.05
    env.glow_hdr_threshold = 1.1
    env.adjustment_enabled = true
    env.adjustment_contrast = 1.08
    env.adjustment_saturation = 1.1
    env.fog_enabled = true
    env.fog_light_color = Color(0.62, 0.70, 0.82)
    env.fog_density = 0.0009
    env.fog_sky_affect = 0.4
    env.fog_sun_scatter = 0.25
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-26, 180, 0)
    sun.light_color = Color(1.0, 0.82, 0.62)
    sun.light_energy = 1.6
    sun.shadow_enabled = true
    sun.shadow_bias = 0.04
    sun.shadow_normal_bias = 1.2
    sun.shadow_blur = 1.5
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
    sun.directional_shadow_max_distance = 220.0
    add_child(sun)

func _make_sky_material() -> Material:
    for path in ["res://sky/evening_hdr.exr", "res://sky/evening_ldr.jpg"]:
        var tex = load(path)
        if tex != null:
            var pano := PanoramaSkyMaterial.new()
            pano.panorama = tex
            return pano
    var pm := ProceduralSkyMaterial.new()
    pm.sky_top_color = Color(0.20, 0.40, 0.78)
    pm.sky_horizon_color = Color(0.72, 0.82, 0.92)
    pm.ground_horizon_color = Color(0.72, 0.78, 0.84)
    return pm

func _add_box(parent: Node, size: Vector3, color: Color, pos: Vector3, emissive := false) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = size
    m.mesh = b
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    if emissive:
        mat.emission_enabled = true
        mat.emission = color
    m.material_override = mat
    m.position = pos
    parent.add_child(m)
    return m

func _build_road() -> void:
    for i in SEG_COUNT:
        var s := Node3D.new()
        s.position.z = -i * SEG_LEN
        add_child(s)
        segs.append(s)
        _add_box(s, Vector3(300, 0.2, SEG_LEN), Color(0.76, 0.62, 0.38), Vector3(0, -0.1, 0))
        _add_box(s, Vector3(12, 0.1, SEG_LEN), Color(0.12, 0.12, 0.14), Vector3(0, -0.03, 0))
        for k in 10:
            for x in [-2.0, 2.0]:
                _add_box(s, Vector3(0.2, 0.02, 3), Color.WHITE, Vector3(x, 0.03, -SEG_LEN / 2 + 5 + k * 10))
        for x in [-6.3, 6.3]:
            var body := StaticBody3D.new()
            body.position = Vector3(x, 0.5, 0)
            s.add_child(body)
            _add_box(body, Vector3(0.6, 1.0, SEG_LEN), Color(0.0, 0.9, 1.0), Vector3.ZERO, true)
            var cs := CollisionShape3D.new()
            var bs := BoxShape3D.new()
            bs.size = Vector3(0.6, 1.0, SEG_LEN)
            cs.shape = bs
            body.add_child(cs)
        for j in 3:
            var mt := MeshInstance3D.new()
            var cm := CylinderMesh.new()
            cm.top_radius = 0.0
            cm.bottom_radius = randf_range(15, 30)
            cm.height = randf_range(25, 50)
            mt.mesh = cm
            var mm := StandardMaterial3D.new()
            mm.albedo_color = Color(0.45, 0.35, 0.3)
            mt.material_override = mm
            var side := -1.0 if randf() < 0.5 else 1.0
            mt.position = Vector3(side * randf_range(60, 120), cm.height / 2.0, randf_range(-SEG_LEN / 2, SEG_LEN / 2))
            s.add_child(mt)

func _spawn_car() -> void:
    car = CarScript.new()
    car.position = Vector3(0, 0.5, 0)
    add_child(car)
    for hx in [-0.65, 0.65]:
        var hl := SpotLight3D.new()
        hl.position = Vector3(hx, 0.55, -2.0)
        hl.spot_range = 45.0
        hl.spot_angle = 30.0
        hl.light_energy = 2.0
        hl.light_color = Color(1.0, 0.95, 0.85)
        car.add_child(hl)
    car.crashed.connect(func(f: float): shake = clampf(f * 0.02, 0.1, 0.8))
    cam = Camera3D.new()
    cam.far = 1500.0
    cam.near = 0.1
    add_child(cam)
    cam.current = true

func _spawn_traffic() -> void:
    for i in 8:
        var t := AnimatableBody3D.new()
        add_child(t)
        _traffic_model(t, i + 1)
        var cs := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = Vector3(1.9, 1.1, 4.2)
        cs.shape = bs
        cs.position.y = 0.2
        t.add_child(cs)
        _place_traffic(t)
        traffic.append(t)

func _traffic_model(t: Node3D, i: int) -> void:
    var ps = load(CarScript.MODELS[i % CarScript.MODELS.size()])
    if ps == null:
        _add_box(t, Vector3(1.9, 0.7, 4.2), Color(0.5, 0.5, 0.5), Vector3.ZERO)
        return
    var m: Node3D = ps.instantiate()
    m.rotation.y = -PI / 2.0
    m.scale = Vector3.ONE * CarScript.MODEL_SCALE
    m.position = Vector3(0, -0.336, 0)
    t.add_child(m)

func _place_traffic(t: Node3D) -> void:
    var lanes := [-4.0, 0.0, 4.0]
    t.position = Vector3(lanes[randi() % 3], 0.6, car.position.z - 80.0 - randf() * 300.0)

func _set_map(mp: int) -> void:
    map_mode = mp
    for s in segs:
        s.position.y = -1000.0 if mp == 1 else 0.0
    algiers.position.y = 0.0 if mp == 1 else -1000.0
    for t in traffic:
        t.visible = (mp == 0)
        if mp == 0:
            _place_traffic(t)
        else:
            t.position = Vector3(0, -500, 0)
    car.speed = 0.0
    car.lateral = 0.0
    if mp == 1:
        car.position = Vector3(algiers.pts[0].x, 0.5, algiers.pts[0].y)
        car.rotation.y = algiers.yaw0
    else:
        car.position = Vector3(0, 0.5, 0)
        car.rotation.y = 0.0
    cam_snap = true

func _physics_process(delta: float) -> void:
    if map_mode == 1:
        return
    for t in traffic:
        t.position.z -= 15.0 * delta
        if t.position.z > car.position.z + 40.0:
            _place_traffic(t)

# ---------- UI ----------
func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var sz := get_viewport().get_visible_rect().size
    var W := sz.x
    var H := sz.y
    _btn(layer, "left", "<", Vector2(40, H - 190), Vector2(150, 150))
    _btn(layer, "right", ">", Vector2(210, H - 190), Vector2(150, 150))
    _btn(layer, "gas", "GAS", Vector2(W - 200, H - 210), Vector2(160, 170), Color(0.2, 1, 0.4))
    _btn(layer, "brake", "BRAKE", Vector2(W - 380, H - 170), Vector2(150, 130), Color(1, 0.2, 0.3))
    _btn(layer, "drift", "DRIFT", Vector2(W - 380, H - 310), Vector2(150, 110), Color(1, 0.6, 0.1))
    _btn(layer, "color", "CAR", Vector2(W - 470, 20), Vector2(140, 60), Color(0.9, 0.3, 1))
    _btn(layer, "tilt", "TILT", Vector2(W - 320, 20), Vector2(140, 60), Color(0.9, 0.3, 1))
    _btn(layer, "cam", "CAM", Vector2(W - 170, 20), Vector2(140, 60), Color(0.9, 0.3, 1))
    _btn(layer, "map", "MAP", Vector2(W - 620, 20), Vector2(140, 60), Color(0.9, 0.3, 1))
    _btn(layer, "snd", "SND", Vector2(W - 770, 20), Vector2(140, 60), Color(0.9, 0.3, 1))
    speed_label = Label.new()
    speed_label.position = Vector2(W / 2 - 150, H - 120)
    speed_label.size = Vector2(300, 80)
    speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    speed_label.add_theme_font_size_override("font_size", 56)
    speed_label.add_theme_color_override("font_color", Color(0.0, 0.95, 1.0))
    speed_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
    speed_label.add_theme_constant_override("outline_size", 10)
    layer.add_child(speed_label)
    info_label = Label.new()
    info_label.position = Vector2(30, 20)
    info_label.add_theme_font_size_override("font_size", 26)
    info_label.add_theme_color_override("font_color", Color.WHITE)
    info_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
    info_label.add_theme_constant_override("outline_size", 8)
    layer.add_child(info_label)

func _btn(layer: Node, id: String, text: String, pos: Vector2, size: Vector2, color := Color(0.0, 0.9, 1.0)) -> void:
    var p := Panel.new()
    p.position = pos
    p.size = size
    p.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.05, 0.06, 0.1, 0.55)
    sb.border_color = color
    sb.set_border_width_all(3)
    sb.set_corner_radius_all(18)
    p.add_theme_stylebox_override("panel", sb)
    var l := Label.new()
    l.text = text
    l.set_anchors_preset(Control.PRESET_FULL_RECT)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.add_theme_font_size_override("font_size", 28)
    l.add_theme_color_override("font_color", color)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    p.add_child(l)
    layer.add_child(p)
    btns[id] = p

# ---------- Input (multi-touch) ----------
func _input(e: InputEvent) -> void:
    if e is InputEventScreenTouch:
        if e.pressed:
            touches[e.index] = e.position
            _tap(e.position)
        else:
            touches.erase(e.index)
    elif e is InputEventScreenDrag:
        touches[e.index] = e.position

func _tap(pos: Vector2) -> void:
    if btns["cam"].get_global_rect().has_point(pos):
        cam_mode = (cam_mode + 1) % CAM_OFFSETS.size()
    elif btns["map"].get_global_rect().has_point(pos):
        _set_map(1 - map_mode)
    elif btns["snd"].get_global_rect().has_point(pos):
        car.sound_on = not car.sound_on
    elif btns["tilt"].get_global_rect().has_point(pos):
        use_tilt = not use_tilt
    elif btns["color"].get_global_rect().has_point(pos):
        color_idx = (color_idx + 1) % NUM_MODELS
        car.set_model(color_idx)

func _process(delta: float) -> void:
    for id in btns:
        held[id] = false
    for p in touches.values():
        for id in btns:
            if btns[id].get_global_rect().has_point(p):
                held[id] = true
    for id in btns:
        btns[id].modulate = Color(1.7, 1.7, 1.7) if held[id] else Color.WHITE

    var gas: bool = held["gas"] or Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)
    var brk: bool = held["brake"] or Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN)
    var left: bool = held["left"] or Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT)
    var right: bool = held["right"] or Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)
    var target := 0.0
    if use_tilt:
        target = clampf(Input.get_accelerometer().y * TILT_SIGN / 4.0, -1.0, 1.0)
        if absf(target) < 0.08:
            target = 0.0
    else:
        target = (1.0 if right else 0.0) - (1.0 if left else 0.0)
    steer_smooth = move_toward(steer_smooth, target, 6.0 * delta)
    car.steer = steer_smooth
    car.throttle = 1.0 if gas else 0.0
    car.braking = brk
    car.drift = held["drift"] or Input.is_key_pressed(KEY_SPACE)

    for s in segs:
        if s.position.z > car.position.z + 150.0:
            s.position.z -= SEG_LEN * SEG_COUNT

    # camera
    var off: Vector3 = CAM_OFFSETS[cam_mode]
    var target_pos: Vector3 = car.global_transform * off
    cam.global_position = target_pos if (cam_mode == 2 or cam_snap) else cam.global_position.lerp(target_pos, clampf(8.0 * delta, 0.0, 1.0))
    cam_snap = false
    var fwd: Vector3 = -car.global_transform.basis.z
    cam.look_at(car.global_position + fwd * 10.0 + Vector3.UP, Vector3.UP)
    cam.fov = 70.0 + absf(car.speed) * 0.25
    shake = move_toward(shake, 0.0, delta * 2.0)
    cam.h_offset = randf_range(-1.0, 1.0) * shake
    cam.v_offset = randf_range(-1.0, 1.0) * shake

    # HUD + stats
    var kmh := absf(car.speed) * 3.6
    var dist: float = car.position.length() if map_mode == 1 else maxf(0.0, -car.position.z)
    if map_mode == 1 and Vector2(car.position.x, car.position.z).distance_to(algiers.end_point) < 40.0:
        _set_map(1)
    best_speed = maxf(best_speed, kmh)
    best_dist = maxf(best_dist, dist)
    speed_label.text = "%d KM/H" % int(kmh)
    info_label.text = "DIST %d m   BEST %d m   TOP %d km/h" % [int(dist), int(best_dist), int(best_speed)]
    save_timer += delta
    if save_timer > 3.0:
        save_timer = 0.0
        _save()

# ---------- Save ----------
func _load_save() -> void:
    var cf := ConfigFile.new()
    if cf.load("user://save.cfg") == OK:
        best_dist = cf.get_value("stats", "best_dist", 0.0)
        best_speed = cf.get_value("stats", "best_speed", 0.0)
        color_idx = cf.get_value("car", "color", 0)
        car.set_model(color_idx % NUM_MODELS)

func _save() -> void:
    var cf := ConfigFile.new()
    cf.set_value("stats", "best_dist", best_dist)
    cf.set_value("stats", "best_speed", best_speed)
    cf.set_value("car", "color", color_idx)
    cf.save("user://save.cfg")

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
        _save()
