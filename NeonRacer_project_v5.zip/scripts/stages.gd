extends RefCounted
## Stage list. Every stage is a point-to-point race over a slice of the Algiers route.
## a / b are indices into maps/algiers.json "r" (about 6 m apart). If b < a the stage is driven in reverse.
## ai = AI skill (1.0 = as fast as the player's best car), theme = look of the sky/light.

const COUNT := 8

const LIST := [
    {"name": "PORT SPRINT",      "a": 20,   "b": 600,  "ai": 0.78, "theme": "day",    "prize": [1500, 900, 600, 400, 250, 150, 100, 50]},
    {"name": "CASBAH RUN",       "a": 600,  "b": 1200, "ai": 0.82, "theme": "day",    "prize": [2000, 1200, 800, 500, 300, 200, 100, 50]},
    {"name": "HILLTOP RUSH",     "a": 1200, "b": 2000, "ai": 0.86, "theme": "sunset", "prize": [2500, 1500, 1000, 600, 400, 250, 150, 75]},
    {"name": "RETURN: SUMMIT",   "a": 2000, "b": 1300, "ai": 0.89, "theme": "sunset", "prize": [3000, 1800, 1200, 800, 500, 300, 200, 100]},
    {"name": "RETURN: BAY",      "a": 1300, "b": 600,  "ai": 0.92, "theme": "dusk",   "prize": [3500, 2100, 1400, 900, 600, 350, 200, 100]},
    {"name": "RETURN: PORT",     "a": 600,  "b": 20,   "ai": 0.94, "theme": "dusk",   "prize": [4000, 2400, 1600, 1000, 700, 400, 250, 125]},
    {"name": "NIGHT CASBAH",     "a": 300,  "b": 1100, "ai": 0.96, "theme": "night",  "prize": [5000, 3000, 2000, 1200, 800, 500, 300, 150]},
    {"name": "NIGHT GRAND PRIX", "a": 1500, "b": 300,  "ai": 0.99, "theme": "night",  "prize": [8000, 4800, 3200, 2000, 1200, 800, 500, 250]},
]

# sky / light presets applied by main.gd
const THEMES := {
    "day":    {"sky": 1.0,  "sun": 1.5,  "sun_col": Color(1.0, 0.9, 0.78),  "amb": 0.8,  "fog": Color(0.62, 0.70, 0.82), "fog_d": 0.0009, "exp": 1.0,  "lamps": false},
    "sunset": {"sky": 0.75, "sun": 1.6,  "sun_col": Color(1.0, 0.62, 0.35), "amb": 0.7,  "fog": Color(0.85, 0.62, 0.50), "fog_d": 0.0012, "exp": 1.0,  "lamps": false},
    "dusk":   {"sky": 0.35, "sun": 0.8,  "sun_col": Color(0.95, 0.5, 0.45), "amb": 0.55, "fog": Color(0.35, 0.28, 0.42), "fog_d": 0.0016, "exp": 1.05, "lamps": true},
    "night":  {"sky": 0.08, "sun": 0.25, "sun_col": Color(0.45, 0.55, 1.0),  "amb": 0.35, "fog": Color(0.05, 0.07, 0.14), "fog_d": 0.0022, "exp": 1.2,  "lamps": true},
}

static func get_stage(i: int) -> Dictionary:
    return LIST[clampi(i, 0, COUNT - 1)]

static func length_m(i: int) -> float:
    var s: Dictionary = get_stage(i)
    return absf(float(int(s["b"]) - int(s["a"]))) * 6.0   # ~6 m per route point

static func is_unlocked(i: int) -> bool:
    return i <= int(Save.get_in("progress.stage_unlocked", 0))

static func best_place(i: int) -> int:
    return int(Save.get_in("progress.best_place.%d" % i, 0))   # 0 = never finished
