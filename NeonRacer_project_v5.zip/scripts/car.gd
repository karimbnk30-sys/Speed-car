extends CharacterBody3D
## Arcade car physics: throttle, brake, reverse, steering, drift, collisions.
signal crashed(force: float)

var throttle := 0.0
var braking := false
var steer := 0.0
var drift := false

var speed := 0.0      # m/s along heading
var lateral := 0.0    # m/s sideways (drift)
var max_speed := 70.0
var accel := 22.0
var brake_force := 45.0
var turn_rate := 1.9
var grip := 8.0
var nitro := 1.0          # 0..1 boost tank
var boosting := false
var model_index := 0
# race bookkeeping (shared field names with ai_car.gd)
var rs := 0.0            # distance along the stage line
var rd := 0.0            # lateral offset from the centre line
var finished := false
var finish_time := 0.0
var racer_name := "YOU"
var number := 0
var rcolor := Color(0.0, 0.95, 1.0)
var is_ai := false

const MODELS := [
    "res://models/Car_1_B.gltf",
    "res://models/Car_10_ZZ.gltf",
    "res://models/Car_Police_1_A_1.gltf",
    "res://models/Car_Police_4_A_1.gltf",
]
const MODEL_SCALE := 1.12
# per model: top speed (m/s), acceleration, turn rate, display name
const STATS := [
    {"max": 70.0, "acc": 22.0, "turn": 1.90, "name": "VELOCE"},
    {"max": 76.0, "acc": 20.0, "turn": 1.75, "name": "PHANTOM ZZ"},
    {"max": 68.0, "acc": 25.0, "turn": 2.05, "name": "INTERCEPTOR"},
    {"max": 72.0, "acc": 23.0, "turn": 1.85, "name": "PURSUIT"},
]
const HUE_SHADER := """shader_type spatial;
uniform sampler2D albedo_tex : source_color, filter_linear_mipmap, repeat_enable;
uniform float hue_shift = 0.0;
uniform float metallic_v = 0.35;
uniform float rough_v = 0.45;
vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
void fragment() {
    vec3 c = texture(albedo_tex, UV).rgb;
    vec3 h = rgb2hsv(c);
    h.x = fract(h.x + hue_shift);
    ALBEDO = hsv2rgb(h);
    METALLIC = metallic_v;
    ROUGHNESS = rough_v;
}
"""
var model: Node3D
var wheels := {}
var wheel_spin := 0.0
var smoke: CPUParticles3D
var sfx := {}
var crash_player: AudioStreamPlayer
var sound_on := true

func _ready() -> void:
    motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(1.9, 0.9, 4.2)
    cs.shape = bs
    cs.position.y = 0.2
    add_child(cs)

    set_model(0)
    _setup_audio()

    smoke = CPUParticles3D.new()
    smoke.amount = 40
    smoke.lifetime = 1.2
    smoke.local_coords = false
    smoke.direction = Vector3(0, 1, 0.5)
    smoke.spread = 25.0
    smoke.initial_velocity_min = 1.0
    smoke.initial_velocity_max = 3.0
    smoke.gravity = Vector3(0, 0.5, 0)
    smoke.scale_amount_min = 1.0
    smoke.scale_amount_max = 2.5
    var sm := SphereMesh.new()
    sm.radius = 0.3
    sm.height = 0.6
    var smat := StandardMaterial3D.new()
    smat.albedo_color = Color(0.85, 0.85, 0.85, 0.45)
    smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    sm.material = smat
    smoke.mesh = sm
    smoke.position = Vector3(0, -0.1, 1.5)
    smoke.emitting = false
    add_child(smoke)

# Applies the model's handling stats (player cars; AI cars set their own values after).
func apply_stats(i: int) -> void:
    var st: Dictionary = STATS[i % STATS.size()]
    max_speed = float(st["max"])
    accel = float(st["acc"])
    turn_rate = float(st["turn"])

# Re-colours the palette-atlas body paint by shifting hue (tyres/glass stay neutral).
static func tint_model(root: Node, hue: float) -> void:
    if absf(hue) < 0.001:
        return
    var sh := Shader.new()
    sh.code = HUE_SHADER
    for n in root.find_children("*", "MeshInstance3D", true, false):
        var mi: MeshInstance3D = n
        if mi.mesh == null:
            continue
        for s in mi.mesh.get_surface_count():
            var m: Material = mi.mesh.surface_get_material(s)
            if m is StandardMaterial3D:
                var sm: StandardMaterial3D = m
                var tex: Texture2D = sm.albedo_texture
                if tex != null and tex.resource_path.ends_with("atlas.png"):
                    var mat := ShaderMaterial.new()
                    mat.shader = sh
                    mat.set_shader_parameter("albedo_tex", tex)
                    mat.set_shader_parameter("hue_shift", hue)
                    mat.set_shader_parameter("metallic_v", sm.metallic)
                    mat.set_shader_parameter("rough_v", sm.roughness)
                    mi.set_surface_override_material(s, mat)

func set_model(i: int, hue := 0.0) -> void:
    if model != null:
        model.queue_free()
        model = null
    model_index = i % MODELS.size()
    var ps = load(MODELS[model_index])
    if ps == null:
        push_warning("Car model not found: %s" % MODELS[model_index])
        return
    model = ps.instantiate()
    tint_model(model, hue)
    model.rotation.y = -PI / 2.0   # models face -X, the game drives toward -Z
    model.scale = Vector3.ONE * MODEL_SCALE
    model.position = Vector3(0, -0.236, 0)
    add_child(model)
    wheels.clear()
    for n in ["FL", "FR", "RL", "RR"]:
        var w = model.find_child(n, true, false)
        if w != null:
            wheels[n] = w

func _physics_process(delta: float) -> void:
    var eff_max := max_speed
    var eff_acc := accel
    if boosting and nitro > 0.0 and throttle > 0.0:
        eff_max = max_speed * 1.18
        eff_acc = accel * 2.4
        nitro = maxf(nitro - 0.3 * delta, 0.0)
    else:
        boosting = false
        nitro = minf(nitro + (0.05 + (0.12 if absf(lateral) > 2.5 else 0.0)) * delta, 1.0)
    if throttle > 0.0 and not braking:
        speed += eff_acc * throttle * (1.0 - clampf(speed / eff_max, 0.0, 1.0)) * delta
    if speed > eff_max:
        speed = move_toward(speed, eff_max, 12.0 * delta)
    if braking:
        if speed > 0.5:
            speed = move_toward(speed, 0.0, brake_force * delta)
        else:
            speed = move_toward(speed, -12.0, 14.0 * delta)
    elif throttle <= 0.0:
        speed = move_toward(speed, 0.0, 4.0 * delta)

    var s := clampf(speed / 12.0, -1.0, 1.0)
    rotation.y -= steer * turn_rate * s / (1.0 + absf(speed) / 60.0) * delta

    var g := grip * (0.25 if drift else 1.0)
    if drift:
        lateral -= steer * speed * 0.25 * delta
        speed = move_toward(speed, 0.0, absf(lateral) * 0.25 * delta)
    lateral = lerpf(lateral, 0.0, clampf(g * delta, 0.0, 1.0))

    var fwd := -global_transform.basis.z
    var right := global_transform.basis.x
    velocity = fwd * speed + right * lateral
    var before := speed
    move_and_slide()
    if get_slide_collision_count() > 0:
        speed = velocity.dot(fwd)
        lateral = velocity.dot(right)
        var impact := absf(before - speed)
        speed *= 0.98
        if impact > 3.0:
            crashed.emit(impact)
            _play_crash(impact)
    position.y = 0.5
    smoke.emitting = absf(lateral) > 2.5 and speed > 10.0
    wheel_spin += speed / (0.25 * MODEL_SCALE) * delta
    for n in wheels:
        var w: Node3D = wheels[n]
        w.rotation = Vector3(0.0, (-steer * 0.5) if n.begins_with("F") else 0.0, wheel_spin)
    _update_audio()

func _setup_audio() -> void:
    for n in ["engine", "skid", "road", "wind"]:
        var res = load("res://audio/%s.wav" % n)
        if res == null:
            continue
        var st: AudioStreamWAV = res.duplicate()
        st.loop_mode = AudioStreamWAV.LOOP_FORWARD
        st.loop_begin = 0
        st.loop_end = st.data.size() / 2
        var p := AudioStreamPlayer.new()
        p.stream = st
        p.volume_db = -80.0
        add_child(p)
        p.play()
        sfx[n] = p
    var cr = load("res://audio/crash.wav")
    if cr != null:
        crash_player = AudioStreamPlayer.new()
        crash_player.stream = cr
        add_child(crash_player)

func _set_sfx(n: String, vol: float, pitch: float) -> void:
    if not sfx.has(n):
        return
    var p: AudioStreamPlayer = sfx[n]
    p.volume_db = linear_to_db(maxf(vol, 0.0001)) if sound_on else -80.0
    p.pitch_scale = maxf(pitch, 0.1)

func _update_audio() -> void:
    var sp := absf(speed)
    _set_sfx("engine", 0.35 + (0.25 if throttle > 0.0 else 0.0), 0.55 + sp / 70.0 * 2.2)
    _set_sfx("skid", clampf((absf(lateral) - 1.5) / 5.0, 0.0, 1.0) * 0.6 + (0.35 if (braking and sp > 25.0) else 0.0), 1.0)
    _set_sfx("road", clampf(sp / 60.0, 0.0, 1.0) * 0.5, 0.7 + sp / 90.0)
    _set_sfx("wind", pow(clampf(sp / 70.0, 0.0, 1.0), 2.0) * 0.6, 1.0)

func _play_crash(f: float) -> void:
    if crash_player == null or not sound_on:
        return
    crash_player.volume_db = linear_to_db(clampf(f / 14.0, 0.25, 1.0))
    crash_player.play()
