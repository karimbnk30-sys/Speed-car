extends Node3D
## NEON RACER V5: 8-car point-to-point races on the Algiers map (player + 7 AI), 8 stages.
const CarScript := preload("res://scripts/car.gd")
const AICarScript := preload("res://scripts/ai_car.gd")
const AlgiersScript := preload("res://scripts/algiers.gd")
const RouteScript := preload("res://scripts/route.gd")
const HudScript := preload("res://scripts/hud.gd")
const StagesScript := preload("res://scripts/stages.gd")
const UIUtil := preload("res://scripts/ui_util.gd")
const TILT_SIGN := 1.0   # change to -1.0 if tilt steering is reversed on your phone
const CAM_OFFSETS := [Vector3(0, 3.2, 8.0), Vector3(0, 5.5, 13.0), Vector3(0, 1.2, 0.3)]
const FIELD_SIZE := 8
const PLAYER_SLOT := 5          # starts 6th of 8
const AI_NAMES := ["KARIM", "YACINE", "SOFIANE", "AMINE", "NADIR", "WALID", "RAYAN", "SAMIR"]
const AI_HUES := [0.0, 0.12, 0.27, 0.42, 0.58, 0.72, 0.86]
const COUNTDOWN_START := 1.2    # seconds before "3"

var stage_idx := 0
var stage: Dictionary
var theme: Dictionary
var car
var cam: Camera3D
var algiers: Node3D
var route
var hud
var racers: Array = []
var ais: Array = []
var state := "countdown"        # countdown | race | finished | results
var state_time := 0.0
var race_time := 0.0
var cd_step := -1
var touches := {}
var held := {}
var use_tilt := false
var cam_mode := 0
var cam_snap := false
var steer_smooth := 0.0
var shake := 0.0
var sky_is_morning := false
var sky_mat: PanoramaSkyMaterial
var last_place := FIELD_SIZE
var board_timer := 0.0
var stuck_timer := 0.0
var fps_acc := 0.0
var fps_frames := 0
var play_time := 0.0
var beeps := {}

func _ready() -> void:
    randomize()
    stage_idx = clampi(Save.next_stage, 0, StagesScript.COUNT - 1)
    stage = StagesScript.get_stage(stage_idx)
    theme = StagesScript.THEMES[stage["theme"]]
    _setup_environment()
    algiers = AlgiersScript.new()
    add_child(algiers)
    algiers.build()
    if algiers.pts.size() < 2:
        push_error("Algiers map failed to load (maps/algiers.json)")
        return
    algiers.set_night(bool(theme["lamps"]))
    route = RouteScript.new()
    route.setup(algiers.pts, int(stage["a"]), int(stage["b"]))
    algiers.add_gantry(route.point_at(route.start_s), route.tangent_at(route.start_s), "START", Color(0.2, 1.0, 0.4))
    algiers.add_gantry(route.point_at(route.finish_s), route.tangent_at(route.finish_s), "FINISH", Color(1.0, 0.3, 0.3))
    _spawn_player()
    _spawn_field()
    _build_ui()
    _build_sounds()
    _load_settings()
    _place_on_grid()
    state = "countdown"
    state_time = 0.0
    hud.toast("STAGE %d  -  %s" % [stage_idx + 1, stage["name"]], Color(0.0, 0.95, 1.0))
    get_tree().paused = false

# ---------- World ----------
func _setup_environment() -> void:
    var we := WorldEnvironment.new()
    var env := Environment.new()
    var sky := Sky.new()
    sky.sky_material = _make_sky_material()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = float(theme["amb"])
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_ACES
    env.tonemap_exposure = float(theme["exp"])
    env.tonemap_white = 6.0
    env.glow_enabled = true
    env.glow_intensity = 0.7 if bool(theme["lamps"]) else 0.6
    env.glow_bloom = 0.05
    env.glow_hdr_threshold = 1.0 if bool(theme["lamps"]) else 1.1
    env.adjustment_enabled = true
    env.adjustment_contrast = 1.08
    env.adjustment_saturation = 1.1
    env.fog_enabled = true
    env.fog_light_color = theme["fog"]
    env.fog_density = float(theme["fog_d"])
    env.fog_sky_affect = 0.4
    env.fog_sun_scatter = 0.25
    we.environment = env
    add_child(we)
    if sky_mat != null:
        sky_mat.energy_multiplier = float(theme["sky"])
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-26, 180, 0)
    if sky_is_morning:
        # aim the sun where the HDRI's sun sits, raised to 24 degrees so shadows stay short
        var az := 0.5
        var el := deg_to_rad(24.0)
        var to_sun := Vector3(sin(az) * cos(el), sin(el), -cos(az) * cos(el))
        sun.basis = Basis.looking_at(-to_sun, Vector3.UP)
    sun.light_color = theme["sun_col"]
    sun.light_energy = float(theme["sun"])
    sun.shadow_enabled = true
    sun.shadow_bias = 0.04
    sun.shadow_normal_bias = 1.2
    sun.shadow_blur = 1.5
    var mobile := OS.has_feature("mobile")
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS if mobile else DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
    sun.directional_shadow_max_distance = 150.0 if mobile else 220.0
    add_child(sun)

func _make_sky_material() -> Material:
    for path in ["res://sky/puresky_morning_2k.hdr", "res://sky/evening_hdr.exr", "res://sky/evening_ldr.jpg"]:
        var tex = load(path)
        if tex != null:
            sky_mat = PanoramaSkyMaterial.new()
            sky_mat.panorama = tex
            sky_is_morning = path.contains("puresky")
            return sky_mat
    var pm := ProceduralSkyMaterial.new()
    pm.sky_top_color = Color(0.20, 0.40, 0.78)
    pm.sky_horizon_color = Color(0.72, 0.82, 0.92)
    pm.ground_horizon_color = Color(0.72, 0.78, 0.84)
    return pm

# ---------- Racers ----------
func _spawn_player() -> void:
    car = CarScript.new()
    add_child(car)
    var sel := int(Save.get_in("garage.selected", 0)) % CarScript.MODELS.size()
    car.set_model(sel)
    car.apply_stats(sel)
    car.racer_name = "YOU"
    car.rcolor = Color(0.0, 0.95, 1.0)
    var night := bool(theme["lamps"])
    for hx in [-0.65, 0.65]:
        var hl := SpotLight3D.new()
        hl.position = Vector3(hx, 0.55, -2.0)
        hl.spot_range = 60.0 if night else 45.0
        hl.spot_angle = 32.0
        hl.light_energy = 5.0 if night else 2.0
        hl.light_color = Color(1.0, 0.95, 0.85)
        car.add_child(hl)
    car.crashed.connect(func(f: float): shake = clampf(f * 0.02, 0.1, 0.8))
    cam = Camera3D.new()
    cam.far = 1500.0
    cam.near = 0.1
    add_child(cam)
    cam.current = true
    racers.append(car)

func _spawn_field() -> void:
    var skill_base := float(stage["ai"])
    var name_pool: Array = AI_NAMES.duplicate()
    name_pool.shuffle()
    var number := 1
    var ai_i := 0
    for slot in FIELD_SIZE:
        if slot == PLAYER_SLOT:
            car.number = number
            number += 1
            continue
        var ai = AICarScript.new()
        ai.route = route
        ai.player = car
        ai.field = racers
        ai.skill = clampf(skill_base * randf_range(0.94, 1.03), 0.5, 1.02)
        ai.corner_skill = clampf(0.88 + skill_base * 0.1 + randf_range(-0.04, 0.04), 0.8, 1.02)
        ai.racer_name = name_pool[ai_i % name_pool.size()]
        ai.number = number
        number += 1
        var hue: float = AI_HUES[ai_i % AI_HUES.size()]
        add_child(ai)
        ai.setup_car((ai_i + 1 + randi() % 3) % CarScript.MODELS.size(), hue, Color.from_hsv(hue, 0.7, 1.0))
        ai.set_meta("slot", slot)
        ai.set_meta("delay", randf_range(0.0, 0.45))
        ais.append(ai)
        racers.append(ai)
        ai_i += 1
    # the player always keeps its own slot number too
    car.set_meta("slot", PLAYER_SLOT)

func _place_on_grid() -> void:
    for r in racers:
        var slot: int = r.get_meta("slot")
        var s: float = route.start_s - 8.0 - float(slot >> 1) * 9.0
        var d: float = -2.6 if (slot & 1) == 0 else 2.6
        if r == car:
            car.speed = 0.0
            car.lateral = 0.0
            car.rs = s
            car.rd = d
            car.position = route.world_pos(s, d)
            car.rotation.y = route.yaw_at(s)
        else:
            r.place(s, d)
    cam_snap = true

func _reset_player() -> void:
    var s: float = maxf(car.rs - 2.0, 0.0)
    car.speed = 0.0
    car.lateral = 0.0
    car.rs = s
    car.rd = 0.0
    car.position = route.world_pos(s, 0.0)
    car.rotation.y = route.yaw_at(s)
    stuck_timer = 0.0
    cam_snap = true

# ---------- UI ----------
func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    hud = HudScript.new()
    var sz := get_viewport().get_visible_rect().size
    hud.build(layer, sz, UIUtil.safe_insets(get_viewport()))
    var line: Array[Vector2] = []
    var i0: int = route._idx(route.start_s)
    var i1: int = route._idx(route.finish_s)
    for i in range(i0, i1 + 1):
        line.append(route.pts[i])
    hud.setup_minimap(line)

func _build_sounds() -> void:
    for k in ["lo", "hi"]:
        var p := AudioStreamPlayer.new()
        p.stream = _make_beep(440.0 if k == "lo" else 880.0, 0.18 if k == "lo" else 0.5)
        p.volume_db = -4.0
        add_child(p)
        beeps[k] = p

func _make_beep(freq: float, dur: float) -> AudioStreamWAV:
    var rate := 22050
    var n := int(rate * dur)
    var bytes := PackedByteArray()
    bytes.resize(n * 2)
    for i in n:
        var env := minf(1.0, float(n - i) / (rate * 0.06)) * minf(1.0, float(i) / (rate * 0.005))
        bytes.encode_s16(i * 2, int(sin(TAU * freq * float(i) / float(rate)) * 0.5 * env * 32767.0))
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.stereo = false
    w.data = bytes
    return w

func _beep(k: String) -> void:
    var p: AudioStreamPlayer = beeps[k]
    if car.sound_on:
        p.play()

# ---------- Input (multi-touch) ----------
func _input(e: InputEvent) -> void:
    if e is InputEventScreenTouch:
        if e.pressed:
            touches[e.index] = e.position
            _tap(e.position)
        else:
            touches.erase(e.index)
    elif e is InputEventScreenDrag:
        touches[e.index] = e.position

func _hit(id: String, pos: Vector2) -> bool:
    return (hud.btns[id] as Control).get_global_rect().has_point(pos)

func _tap(pos: Vector2) -> void:
    if _hit("pause", pos):
        _pause()
    elif _hit("cam", pos):
        cam_mode = (cam_mode + 1) % CAM_OFFSETS.size()
    elif _hit("snd", pos):
        car.sound_on = not car.sound_on
        for a in ais:
            a.sound_on = car.sound_on
        Save.set_in("settings.audio_master", 1.0 if car.sound_on else 0.0)
    elif _hit("tilt", pos):
        use_tilt = not use_tilt
        Save.set_in("settings.control_scheme", "tilt" if use_tilt else "buttons")
        hud.toast("TILT STEERING ON" if use_tilt else "BUTTON STEERING", Color(0.9, 0.5, 1.0))

func _pause() -> void:
    if state == "results" or get_tree().paused:
        return
    touches.clear()
    get_tree().paused = true
    hud.show_pause(_resume, _restart, _to_menu)

func _resume() -> void:
    hud.hide_pause()
    get_tree().paused = false

func _restart() -> void:
    get_tree().paused = false
    Save.save()
    get_tree().reload_current_scene()

func _to_menu() -> void:
    get_tree().paused = false
    Save.save()
    get_tree().change_scene_to_file("res://scenes/menu.tscn")

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
        if hud != null and state != "results":
            _pause()

# ---------- Frame ----------
func _process(delta: float) -> void:
    if route == null or hud == null:
        return
    state_time += delta
    play_time += delta
    _read_input(delta)
    _update_progress()
    _update_state(delta)
    _update_camera(delta)
    _update_hud(delta)
    _adapt_quality(delta)

func _read_input(delta: float) -> void:
    for id in hud.btns:
        held[id] = false
    for p in touches.values():
        for id in hud.btns:
            if _hit(id, p):
                held[id] = true
    for id in hud.btns:
        (hud.btns[id] as Control).modulate = Color(1.7, 1.7, 1.7) if held[id] else Color.WHITE
    var driving := state == "race"
    var gas: bool = held["gas"] or Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)
    var brk: bool = held["brake"] or Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN)
    var left: bool = held["left"] or Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT)
    var right: bool = held["right"] or Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)
    var target := 0.0
    if use_tilt:
        target = clampf(Input.get_accelerometer().y * TILT_SIGN / 4.0, -1.0, 1.0)
        if absf(target) < 0.08:
            target = 0.0
    else:
        target = (1.0 if right else 0.0) - (1.0 if left else 0.0)
    steer_smooth = move_toward(steer_smooth, target, 6.0 * delta)
    if driving:
        car.steer = steer_smooth
        car.throttle = 1.0 if gas else 0.0
        car.braking = brk
        car.drift = held["drift"] or Input.is_key_pressed(KEY_SPACE)
        car.boosting = held["nitro"] or Input.is_key_pressed(KEY_SHIFT)
        # stuck against a wall: put the car back on the road
        if (gas or brk) and absf(car.speed) < 1.5:
            stuck_timer += delta
            if stuck_timer > 2.5:
                _reset_player()
                hud.toast("BACK ON TRACK", Color(1.0, 0.8, 0.2))
        else:
            stuck_timer = 0.0
    else:
        car.steer = 0.0
        car.throttle = 0.0
        car.drift = false
        car.boosting = false
        car.braking = state != "countdown"   # roll to a stop after the finish

func _update_progress() -> void:
    var sd: Vector2 = route.project(Vector2(car.global_position.x, car.global_position.z), car.rs)
    car.rs = sd.x
    car.rd = sd.y

func _update_state(delta: float) -> void:
    match state:
        "countdown":
            var t := state_time - COUNTDOWN_START
            var step := int(floorf(t))   # 0->"3", 1->"2", 2->"1", 3->"GO"
            if t >= 0.0 and step != cd_step:
                cd_step = step
                if step <= 2:
                    hud.big(str(3 - step), Color(1.0, 0.9, 0.2))
                    _beep("lo")
                else:
                    hud.big("GO!", Color(0.3, 1.0, 0.4))
                    hud.hide_big(0.9)
                    _beep("hi")
                    state = "race"
                    race_time = 0.0
        "race":
            race_time += delta
            for a in ais:
                if not a.racing and race_time >= float(a.get_meta("delay")):
                    a.racing = true
            _check_finishes()
            # wrong way warning
            var fwd: Vector3 = -car.global_transform.basis.z
            var t3: Vector2 = route.tangent_at(car.rs)
            var dotv := fwd.x * t3.x + fwd.z * t3.y
            hud.set_wrong_way(dotv < -0.35 and car.speed > 4.0)
        "finished":
            hud.set_wrong_way(false)
            race_time += delta
            _check_finishes()
            if state_time > 2.8:
                _show_results()

func _check_finishes() -> void:
    for r in racers:
        if r.finished or r.rs < route.finish_s:
            continue
        r.finished = true
        var over: float = (r.rs - route.finish_s) / maxf(absf(r.speed), 8.0)
        r.finish_time = maxf(race_time - over, 0.1)
        if r == car:
            state = "finished"
            state_time = 0.0
            var pl := _order().find(car) + 1
            hud.big("FINISH!  P%d" % pl, Color(1.0, 0.85, 0.2) if pl <= 3 else Color(0.0, 0.95, 1.0))
            hud.set_buttons_visible(false)
            _beep("hi")

func _sort_racers(a, b) -> bool:
    if a.finished != b.finished:
        return a.finished
    if a.finished:
        return a.finish_time < b.finish_time
    return a.rs > b.rs

func _order() -> Array:
    var o: Array = racers.duplicate()
    o.sort_custom(_sort_racers)
    return o

func _show_results() -> void:
    state = "results"
    for a in ais:
        if not a.finished:
            # estimate the time the car would have needed to finish
            a.finish_time = race_time + maxf(route.finish_s - a.rs, 0.0) / maxf(a.speed, 25.0)
            a.finished = true
        a.racing = false
    var order := _order()
    var place := order.find(car) + 1
    var prizes: Array = stage["prize"]
    var prize := int(prizes[clampi(place - 1, 0, prizes.size() - 1)])
    Save.set_in("profile.money", int(Save.get_in("profile.money", 0)) + prize)
    var best := StagesScript.best_place(stage_idx)
    if best == 0 or place < best:
        Save.set_in("progress.best_place.%d" % stage_idx, place)
    var unlocked := int(Save.get_in("progress.stage_unlocked", 0))
    var new_unlock := false
    if place <= 3 and stage_idx + 1 > unlocked and stage_idx + 1 < StagesScript.COUNT:
        Save.set_in("progress.stage_unlocked", stage_idx + 1)
        new_unlock = true
    Save.add_stat("races", 1.0)
    if place == 1:
        Save.add_stat("wins", 1.0)
    Save.save()
    var can_next := place <= 3 and stage_idx + 1 < StagesScript.COUNT
    var info := {"prize": prize, "time": car.finish_time, "new_unlock": new_unlock, "can_next": can_next}
    hud.show_results(order, car, info, _next_stage, _restart, _to_menu)

func _next_stage() -> void:
    Save.next_stage = mini(stage_idx + 1, StagesScript.COUNT - 1)
    Save.save()
    get_tree().reload_current_scene()

# ---------- Camera / HUD ----------
func _update_camera(delta: float) -> void:
    var off: Vector3 = CAM_OFFSETS[cam_mode]
    var target_pos: Vector3 = car.global_transform * off
    cam.global_position = target_pos if (cam_mode == 2 or cam_snap) else cam.global_position.lerp(target_pos, clampf(8.0 * delta, 0.0, 1.0))
    cam_snap = false
    var fwd: Vector3 = -car.global_transform.basis.z
    cam.look_at(car.global_position + fwd * 10.0 + Vector3.UP, Vector3.UP)
    var boost_fov := 9.0 if (car.boosting and car.nitro > 0.0 and car.throttle > 0.0) else 0.0
    cam.fov = lerpf(cam.fov, 70.0 + absf(car.speed) * 0.25 + boost_fov, clampf(5.0 * delta, 0.0, 1.0))
    shake = move_toward(shake, 0.0, delta * 2.0)
    cam.h_offset = randf_range(-1.0, 1.0) * shake
    cam.v_offset = randf_range(-1.0, 1.0) * shake

func _update_hud(delta: float) -> void:
    var kmh := absf(car.speed) * 3.6
    var fx := clampf((kmh - 140.0) / 160.0, 0.0, 0.7) + (0.3 if (car.boosting and car.nitro > 0.0) else 0.0)
    hud.set_speed(kmh, car.nitro, fx)
    hud.set_time(race_time if state != "countdown" else 0.0)
    var order := _order()
    var place := order.find(car) + 1
    hud.set_progress(place, racers.size(), route.finish_s - car.rs)
    if state == "race" and place < last_place:
        hud.toast("OVERTAKE!  P%d" % place, Color(0.3, 1.0, 0.5))
    last_place = place
    board_timer -= delta
    if board_timer <= 0.0:
        board_timer = 0.2
        hud.set_board(order, car)
        hud.set_minimap_dots(racers, car)
    Save.max_stat("best_speed", kmh)
    Save.add_stat("total_distance", absf(car.speed) * delta)
    Save.add_stat("playtime", delta)

# adaptive 3D resolution: keeps phones near 60 fps without touching the UI sharpness
func _adapt_quality(delta: float) -> void:
    fps_acc += delta
    fps_frames += 1
    if fps_acc < 2.0:
        return
    var fps := float(fps_frames) / fps_acc
    fps_acc = 0.0
    fps_frames = 0
    if play_time < 5.0:
        return
    var vp := get_viewport()
    var sc := vp.scaling_3d_scale
    if fps < 42.0 and sc > 0.66:
        vp.scaling_3d_scale = maxf(sc - 0.08, 0.66)
    elif fps > 57.0 and sc < 1.0:
        vp.scaling_3d_scale = minf(sc + 0.04, 1.0)

# ---------- Settings ----------
func _load_settings() -> void:
    use_tilt = str(Save.get_in("settings.control_scheme", "buttons")) == "tilt"
    car.sound_on = float(Save.get_in("settings.audio_master", 1.0)) > 0.0
    for a in ais:
        a.sound_on = car.sound_on
