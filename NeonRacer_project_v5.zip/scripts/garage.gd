extends Node
## Garage: browse the 4 cars, compare handling stats, pick the one you race with.
const ShowroomScript := preload("res://scripts/showroom.gd")
const CarScript := preload("res://scripts/car.gd")
const UIUtil := preload("res://scripts/ui_util.gd")

var idx := 0
var showroom
var name_label: Label
var sel_btn: Button
var bars := {}

func _ready() -> void:
    idx = int(Save.get_in("garage.selected", 0)) % CarScript.MODELS.size()
    showroom = ShowroomScript.new()
    showroom.model_index = idx
    showroom.orbit_speed = 0.3
    add_child(showroom)
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(root)
    var sz := get_viewport().get_visible_rect().size
    var ins := UIUtil.safe_insets(get_viewport())

    var title := UIUtil.make_label("GARAGE", 60, Color(0.0, 0.95, 1.0))
    title.position = Vector2(ins.x, ins.y)
    root.add_child(title)
    name_label = UIUtil.make_label("", 48, Color.WHITE)
    name_label.position = Vector2(ins.x, ins.y + 90.0)
    root.add_child(name_label)

    # stat bars
    var y := ins.y + 170.0
    for k in ["SPEED", "ACCEL", "HANDLING"]:
        var l := UIUtil.make_label(k, 26, Color(0.8, 0.9, 1.0))
        l.position = Vector2(ins.x, y)
        root.add_child(l)
        var pb := ProgressBar.new()
        pb.show_percentage = false
        pb.max_value = 1.0
        pb.position = Vector2(ins.x + 170.0, y + 8.0)
        pb.size = Vector2(300, 18)
        pb.add_theme_stylebox_override("background", UIUtil.box(Color(0.05, 0.06, 0.1, 0.8), Color(0.0, 0.5, 0.6), 2))
        pb.add_theme_stylebox_override("fill", UIUtil.box(Color(0.0, 0.9, 1.0), Color(0.0, 0.9, 1.0), 0))
        root.add_child(pb)
        bars[k] = pb
        y += 48.0

    var prev := UIUtil.make_button("<", Color(0.9, 0.3, 1.0), Vector2(110, 110))
    prev.position = Vector2(ins.x, sz.y * 0.5 - 20.0)
    prev.pressed.connect(func(): _step(-1))
    root.add_child(prev)
    var nxt := UIUtil.make_button(">", Color(0.9, 0.3, 1.0), Vector2(110, 110))
    nxt.position = Vector2(sz.x - ins.z - 110.0, sz.y * 0.5 - 20.0)
    nxt.pressed.connect(func(): _step(1))
    root.add_child(nxt)

    sel_btn = UIUtil.make_button("SELECT", Color(0.2, 1.0, 0.4), Vector2(300, 84))
    sel_btn.position = Vector2(sz.x * 0.5 - 150.0, sz.y - ins.w - 84.0)
    sel_btn.pressed.connect(_choose)
    root.add_child(sel_btn)
    var back := UIUtil.make_button("BACK", Color(1.0, 0.3, 0.35), Vector2(220, 76))
    back.position = Vector2(ins.x, sz.y - ins.w - 76.0)
    back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/menu.tscn"))
    root.add_child(back)
    _refresh()

func _step(dir: int) -> void:
    var n := CarScript.MODELS.size()
    idx = (idx + dir + n) % n
    showroom.set_model(idx)
    _refresh()

func _choose() -> void:
    Save.set_in("garage.selected", idx)
    Save.save()
    _refresh()

func _refresh() -> void:
    var st: Dictionary = CarScript.STATS[idx]
    name_label.text = str(st["name"])
    (bars["SPEED"] as ProgressBar).value = (float(st["max"]) - 60.0) / 20.0
    (bars["ACCEL"] as ProgressBar).value = (float(st["acc"]) - 16.0) / 12.0
    (bars["HANDLING"] as ProgressBar).value = (float(st["turn"]) - 1.4) / 0.8
    var chosen := int(Save.get_in("garage.selected", 0)) == idx
    sel_btn.text = "SELECTED" if chosen else "SELECT"
    sel_btn.disabled = chosen
