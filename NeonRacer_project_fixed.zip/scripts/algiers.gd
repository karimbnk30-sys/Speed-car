extends Node3D
## Algiers map built from OpenStreetMap data (c) OpenStreetMap contributors.
const TW := 7.0
var pts: Array[Vector2] = []
var nrm: Array[Vector2] = []
var yaw0 := 0.0
var end_point := Vector2.ZERO

func build() -> void:
    var f := FileAccess.open("res://maps/algiers.json", FileAccess.READ)
    if f == null:
        push_warning("maps/algiers.json not found")
        return
    var d: Dictionary = JSON.parse_string(f.get_as_text())
    for p in d["r"]:
        pts.append(Vector2(p[0], p[1]))
    var n := pts.size()
    for i in n:
        var a := pts[maxi(i - 1, 0)]
        var b := pts[mini(i + 1, n - 1)]
        var t := (b - a).normalized()
        nrm.append(Vector2(-t.y, t.x))
    var t0 := (pts[1] - pts[0]).normalized()
    yaw0 = atan2(-t0.x, -t0.y)
    end_point = pts[n - 1]
    _ribbon(-TW, 0.02, TW, 0.02, Color(0.16, 0.16, 0.19), false, false, false)
    _ribbon(-0.12, 0.04, 0.12, 0.04, Color.WHITE, false, true, false)
    for s in [-1.0, 1.0]:
        _ribbon(s * (TW + 0.25), 0.0, s * (TW + 0.25), 1.1, Color(0.0, 0.94, 1.0), true, false, true)
    _buildings(d["b"])
    _sea(d["sea"])
    var g := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(30000, 30000)
    g.mesh = pm
    g.material_override = _mat(Color(0.64, 0.61, 0.53), false)
    g.position = Vector3(2500, -0.3, -2500)
    add_child(g)

func _mat(c: Color, emissive: bool) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 0.85
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    if emissive:
        m.emission_enabled = true
        m.emission = c
    return m

func _ribbon(oa: float, ya: float, ob: float, yb: float, color: Color, emissive: bool, dashed: bool, collide: bool) -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var faces := PackedVector3Array()
    for i in pts.size() - 1:
        if dashed and i % 3 != 0:
            continue
        var a0 := Vector3(pts[i].x + nrm[i].x * oa, ya, pts[i].y + nrm[i].y * oa)
        var b0 := Vector3(pts[i].x + nrm[i].x * ob, yb, pts[i].y + nrm[i].y * ob)
        var a1 := Vector3(pts[i + 1].x + nrm[i + 1].x * oa, ya, pts[i + 1].y + nrm[i + 1].y * oa)
        var b1 := Vector3(pts[i + 1].x + nrm[i + 1].x * ob, yb, pts[i + 1].y + nrm[i + 1].y * ob)
        for v in [a0, b0, a1, b0, b1, a1]:
            st.add_vertex(v)
            faces.append(v)
    st.generate_normals()
    var mi := MeshInstance3D.new()
    mi.mesh = st.commit()
    mi.material_override = _mat(color, emissive)
    add_child(mi)
    if collide:
        var body := StaticBody3D.new()
        var cs := CollisionShape3D.new()
        var sh := ConcavePolygonShape3D.new()
        sh.set_faces(faces)
        sh.backface_collision = true
        cs.shape = sh
        body.add_child(cs)
        add_child(body)

func _buildings(list: Array) -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    st.set_smooth_group(-1)
    var cols := [Color("f2eee4"), Color("e8dfcf"), Color("dcd3c4"), Color("f7f4ee"), Color("d9c8b0")]
    var roof := Color(0.55, 0.56, 0.57)
    for bi in list.size():
        var b: Array = list[bi]
        var h: float = b[0]
        var poly := PackedVector2Array()
        for i in range(1, b.size(), 2):
            poly.append(Vector2(b[i], b[i + 1]))
        var col: Color = cols[bi % cols.size()]
        var m := poly.size()
        for i in m:
            var p := poly[i]
            var q := poly[(i + 1) % m]
            for v in [Vector3(p.x, 0, p.y), Vector3(q.x, 0, q.y), Vector3(q.x, h, q.y), Vector3(p.x, 0, p.y), Vector3(q.x, h, q.y), Vector3(p.x, h, p.y)]:
                st.set_color(col)
                st.add_vertex(v)
        for k in Geometry2D.triangulate_polygon(poly):
            st.set_color(roof)
            st.add_vertex(Vector3(poly[k].x, h, poly[k].y))
    st.generate_normals()
    var mi := MeshInstance3D.new()
    mi.mesh = st.commit()
    var mat := StandardMaterial3D.new()
    mat.vertex_color_use_as_albedo = true
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.roughness = 0.9
    mi.material_override = mat
    add_child(mi)

func _sea(flat: Array) -> void:
    var poly := PackedVector2Array()
    for i in range(0, flat.size(), 2):
        poly.append(Vector2(flat[i], flat[i + 1]))
    var tri := Geometry2D.triangulate_polygon(poly)
    if tri.is_empty():
        push_warning("sea polygon could not be triangulated")
        return
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for k in tri:
        st.add_vertex(Vector3(poly[k].x, -0.2, poly[k].y))
    st.generate_normals()
    var mi := MeshInstance3D.new()
    mi.mesh = st.commit()
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(0.18, 0.5, 0.75)
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    mi.material_override = m
    add_child(mi)
